(function(root){
 'use strict';
 const copy=v=>v==null?v:JSON.parse(JSON.stringify(v));
 const entities=s=>new Map((s?.map?.entities||[]).filter(e=>!e.cityentity_id?.includes('Impediment')).map(e=>[e.id,e]));
 function changes(before,after){
  const a=entities(before),b=entities(after),out=[];
  for(const [id,e] of b){const old=a.get(id);
   if(!old)out.push({kind:'added',id,building:e.cityentity_id});
   else if(old.cityentity_id!==e.cityentity_id||old.level!==e.level)out.push({kind:'changed',id,building:e.cityentity_id});
   else if(old.state?.__class__==='ConstructionState'&&e.state?.__class__!=='ConstructionState')out.push({kind:'completed',id,building:e.cityentity_id});
   else if(old.connected!==e.connected)out.push({kind:'connection',id,building:e.cityentity_id});
  }
  for(const [id,e] of a)if(!b.has(id))out.push({kind:'removed',id,building:e.cityentity_id});
  const areas=s=>new Set((s?.map?.unlocked_areas||[]).map(a=>JSON.stringify([a.x,a.y,a.width,a.length])));
  const oldAreas=areas(before);for(const area of areas(after))if(!oldAreas.has(area))out.push({kind:'expansion',area:JSON.parse(area)});
  return out;
 }
 function database(){
  let opening;
  const open=()=>opening||=(new Promise((resolve,reject)=>{
   const request=indexedDB.open('foe-companion-quantum-history',1);
   request.onupgradeneeded=()=>request.result.createObjectStore('profiles');
   request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
  }));
  async function transact(key,value,write){const db=await open();return new Promise((resolve,reject)=>{
   const tx=db.transaction('profiles',write?'readwrite':'readonly'),store=tx.objectStore('profiles');
   const request=write?store.put(value,key):store.get(key);
   tx.oncomplete=()=>resolve(request.result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Przerwany zapis'));
  });}
  async function remove(key){const db=await open();return new Promise((resolve,reject)=>{
   const tx=db.transaction('profiles','readwrite');tx.objectStore('profiles').delete(key);
   tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Przerwane usuwanie'));
  });}
  async function latest(world){const db=await open();return new Promise((resolve,reject)=>{
   const tx=db.transaction('profiles','readonly'),request=tx.objectStore('profiles').openCursor();let selected=null,selectedAt=-1;
   request.onsuccess=()=>{const cursor=request.result;if(!cursor)return;if(String(cursor.key).startsWith(world+':')){const value=cursor.value,at=Number(value?.updatedAt)||value?.events?.reduce((max,event)=>Math.max(max,Number(event.at)||0),0)||0;if(value?.world===world&&at>selectedAt){selected=value;selectedAt=at;}}cursor.continue();};
   tx.oncomplete=()=>resolve(selected);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Przerwany odczyt'));
  });}
  return {load:key=>transact(key),save:(key,value)=>transact(key,value,true),remove,latest};
 }
 function create({storage=database(),world=location.host,now=()=>Date.now()}={}){
  let queue=Promise.resolve(),profile=null,doc=null,error='',onchange=()=>{};
  const enqueue=fn=>{queue=queue.then(fn).catch(e=>{error='Nie udało się zapisać lub odczytać historii: '+e.message;onchange();});return queue;};
  async function save(){doc.updatedAt=now();await storage.save(profile,copy(doc));error='';onchange();}
  function rememberEdit(before,label){
   const old=new Map(before.map(e=>[e.id,e])),current=new Map(doc.events.map(e=>[e.id,e])),patch=[];
   for(const [id,event] of old){
    const next=current.get(id);
    if(!next){patch.push({id,removed:event,index:before.findIndex(e=>e.id===id)});continue;}
    const fields=[];
    for(const key of new Set([...Object.keys(event),...Object.keys(next)]))if(JSON.stringify(event[key])!==JSON.stringify(next[key]))fields.push({key,had:Object.hasOwn(event,key),value:event[key],after:next[key]});
    if(fields.length)patch.push({id,fields});
   }
   if(patch.length)doc.undo=[...(doc.undo||[]),{label,patch}].slice(-3);
  }
  function observe(data,before,after){
   if(!after?.map)return queue;
   // Clone immediately: persistence is asynchronous but the game keeps updating.
   const b=copy(before),a=copy(after),responses=copy((Array.isArray(data)?data:[data]).filter(r=>r?.requestClass==='CityProductionService'&&['pickupProduction','pickupAll'].includes(r.requestMethod))),at=now();
   a.calculationVersion=root.FoeQuantum.calculationVersion;if(b)b.calculationVersion=root.FoeQuantum.calculationVersion;
   return enqueue(async()=>{
    const player=a.map.entities.find(e=>e.player_id!=null)?.player_id;
    if(player==null)return;
    const key=world+':'+player;
    if(profile!==key){const loaded=await storage.load(key);doc=loaded||{schemaVersion:1,world,playerId:player,events:[]};profile=key;try{root.localStorage?.setItem('foe-companion.quantum-history-profile:'+world,key);}catch{}}
    const run=String(a.summary?.raid?.endsAt||a.map.entities.find(e=>e.type==='main_building')?.id||'unknown');
    const diff=b?.map?changes(b,a).filter(c=>c.kind!=='completed'):[];
    const pickup=responses.filter(r=>r?.requestClass==='CityProductionService'&&['pickupProduction','pickupAll'].includes(r.requestMethod)&&r.responseData&&!r.responseData.error);
    const touched=new Set();
    function walk(v){if(!v||typeof v!=='object')return;if(v.__class__==='CityMapEntity'&&v.cityentity_id?.includes('GuildRaids'))touched.add(v.id);for(const child of Object.values(v))if(child&&typeof child==='object')walk(child);}
    pickup.forEach(r=>walk(r.responseData));
    const old=entities(b),current=entities(a);
    const stateKey=e=>JSON.stringify([e.state?.__class__,e.state?.next_state_transition_at,e.state?.productionOption]);
    const collected=[...touched].filter(id=>old.has(id)&&current.has(id)&&stateKey(old.get(id))!==stateKey(current.get(id)));
    const items=(b?.summary?.groups||[]).flatMap(g=>g.items).filter(i=>collected.includes(i.id));
    let cycle=null;
    if(items.length){
     const previous=[...doc.events].reverse().find(e=>e.run===run&&e.kind==='collection');
     const due=Math.min(...items.map(i=>Number(old.get(i.id)?.state?.next_state_transition_at)||at/1000));
     const alreadyCollected=previous&&doc.events.some(e=>e.run===run&&e.kind==='collection'&&e.cycle===previous.cycle&&items.some(i=>e.collected?.includes(i.id)));
     const same=previous&&Math.abs(due-(previous.cycleDue??previous.due))<=3600&&at-(previous.cycleAt??previous.at)<10*3600*1000&&!alreadyCollected;
     cycle=same?previous.cycle:(previous?.cycle||0)+1;
     const estimate=Object.fromEntries(root.FoeQuantum.KEYS.map(k=>[k,items.reduce((sum,i)=>sum+(i.production?.[k]||0),0)]));
     doc.events.push({id:crypto.randomUUID(),at,run,kind:'collection',cycle,due,cycleDue:same?(previous.cycleDue??previous.due):due,cycleAt:same?(previous.cycleAt??previous.at):at,collected:items.map(i=>i.id),estimate,changes:diff,before:b,after:a});
    }else if(diff.length){
     doc.events.push({id:crypto.randomUUID(),at,run,kind:'change',changes:diff,collected,before:b,after:a});
    }else return;
    await save();
   });
  }
  function loadLatest(playerId){return enqueue(async()=>{
   let key=Number.isSafeInteger(playerId)?world+':'+playerId:null,loaded=null;
   if(key)loaded=await storage.load(key);
   if(!key){try{key=root.localStorage?.getItem('foe-companion.quantum-history-profile:'+world)||null;}catch{}}
   if(!loaded&&key?.startsWith(world+':'))loaded=await storage.load(key);
   if(!loaded&&!Number.isSafeInteger(playerId)&&typeof storage.latest==='function'){
    loaded=await storage.latest(world);if(loaded)key=world+':'+loaded.playerId;
   }
   if(loaded){doc=loaded;profile=key;try{root.localStorage?.setItem('foe-companion.quantum-history-profile:'+world,key);}catch{}}
   else{doc={schemaVersion:1,world,...(Number.isSafeInteger(playerId)?{playerId}:{}),events:[]};profile=key;}
   error='';onchange();
  });}
  function clear(playerId){return enqueue(async()=>{
   let key=Number.isSafeInteger(playerId)?world+':'+playerId:profile;
   if(!key){try{key=root.localStorage?.getItem('foe-companion.quantum-history-profile:'+world)||null;}catch{}}
   if(!key&&typeof storage.latest==='function'){const latest=await storage.latest(world);if(latest)key=world+':'+latest.playerId;}
   if(key?.startsWith(world+':'))await storage.remove(key);
   const clearedPlayerId=Number.isSafeInteger(playerId)?playerId:key?.startsWith(world+':')?Number(key.slice(world.length+1)):undefined;
   profile=key?.startsWith(world+':')?key:null;
   doc={schemaVersion:1,world,...(Number.isSafeInteger(clearedPlayerId)?{playerId:clearedPlayerId}:{}),events:[]};error='';onchange();
  });}
  return {observe,ready:()=>queue,loadLatest,clear,get error(){return error;},get document(){return copy(doc);},set onChange(fn){onchange=fn;},
   export(){return JSON.stringify({exportedAt:new Date(now()).toISOString(),...copy(doc)},null,2);},
   get lastCycle(){return doc?.events.reduce((max,e)=>e.kind==='collection'&&e.cycle>max?e.cycle:max,0)||null;},
   get lastGroup(){const evs=doc?.events;if(!evs?.length)return null;const groups=groupEvents(evs).filter(g=>actionRows(g.actions).length);return groups.at(-1)||null;},
   get undoLabel(){return doc?.undo?.at(-1)?.label||'';},
   get undoCount(){return doc?.undo?.length||0;},
   undo(){return enqueue(async()=>{
    const operation=doc?.undo?.pop();if(!operation)return;
    for(const change of operation.patch){
     const event=doc.events.find(e=>e.id===change.id);
     if(change.removed){if(!event)doc.events.splice(Math.min(change.index,doc.events.length),0,change.removed);continue;}
     if(event)for(const field of change.fields){
      if(JSON.stringify(event[field.key])!==JSON.stringify(field.after))continue;
      if(field.had)event[field.key]=copy(field.value);else delete event[field.key];
     }
    }
    await save();
   });},
   split(refs){return enqueue(async()=>{
    if(!doc||!refs?.length)return;
    const group=groupEvents(doc.events).find(g=>g.actions.some(e=>e.id===refs[0].id));
    const index=group?.actions.findIndex(e=>e.id===refs[0].id);if(!(index>0))return;
    const before=copy(doc.events),left='split:'+crypto.randomUUID(),right='split:'+crypto.randomUUID();
    group.actions.forEach((e,i)=>{const target=doc.events.find(v=>v.id===e.id);target.groupId=i<index?left:right;target.manuallyGrouped=true;if(i===index)target.groupStart=true;});
    const leftCycle=group.actions.slice(0,index).find(e=>e.kind==='collection')?.cycle;
    const first=group.actions.slice(index).find(e=>e.kind==='collection');
    if(first&&leftCycle!=null){
     const delta=leftCycle+1-first.cycle;
     for(const e of doc.events)if(e.run===group.run&&e.kind==='collection'&&e.at>=first.at)e.cycle+=delta;
    }
    rememberEdit(before,'rozdzielenie zbioru');await save();
   });},
   remove(ids){return enqueue(async()=>{if(!doc)return;const before=copy(doc.events),selected=new Set(ids);doc.events=doc.events.filter(e=>!selected.has(e.id));rememberEdit(before,'usunięcie wpisu');await save();});},
   editRows(refs,note){return enqueue(async()=>{
    for(const ref of refs){const e=doc?.events.find(e=>e.id===ref.id);if(e)(e.notes||={})[ref.key]=String(note).slice(0,2000);}
    if(doc)await save();
   });},
   removeRows(refs){return enqueue(async()=>{
    const before=copy(doc?.events||[]);
    for(const ref of refs){const e=doc?.events.find(e=>e.id===ref.id);if(e){e.hiddenRows||=[];if(!e.hiddenRows.includes(ref.key))e.hiddenRows.push(ref.key);}}
    if(doc){doc.events=doc.events.filter(e=>actionRows([e]).length);rememberEdit(before,'usunięcie działania');await save();}
   });},
   merge(id){return enqueue(async()=>{
    if(!doc)return;const groups=groupEvents(doc.events),index=groups.findIndex(g=>g.id===id),selected=groups[index];
    if(!selected)return;
    const previous=groups.slice(0,index).reverse().find(g=>g.run===selected.run&&g.kind==='collection');
    if(!previous)return;
    const before=copy(doc.events);
    const groupId=previous.groupId||previous.id,start=groups.indexOf(previous);
    const ids=new Set(groups.slice(start,index+1).filter(g=>g.run===selected.run).flatMap(g=>g.actions.map(e=>e.id)));
    const delta=selected.kind==='collection'?selected.cycle-previous.cycle:0;
    for(const e of doc.events){
     if(ids.has(e.id)){e.groupId=groupId;delete e.groupStart;e.manuallyGrouped=true;if(e.kind==='collection')e.cycle=previous.cycle;}
     else if(delta>0&&e.run===selected.run&&e.kind==='collection'&&e.at>selected.endAt)e.cycle-=delta;
    }
    rememberEdit(before,'połączenie zbiorów');await save();
   });},
   relabel(id,split){return enqueue(async()=>{
    const event=doc?.events.find(e=>e.id===id);if(!event||event.kind!=='collection')return;
    const list=doc.events.filter(e=>e.run===event.run&&e.kind==='collection'),i=list.indexOf(event),prev=list[i-1];if(!prev)return;
    const delta=(split?prev.cycle+1:prev.cycle)-event.cycle;
    for(let n=i;n<list.length;n++)list[n].cycle+=delta;
    const anchors=new Map();for(const e of list){if(!anchors.has(e.cycle))anchors.set(e.cycle,e);const anchor=anchors.get(e.cycle);e.cycleDue=anchor.due;e.cycleAt=anchor.at;}
    event.manuallyGrouped=true;await save();
   });},
   saveScreenshot(id,label,dataUrl){return enqueue(async()=>{
    const event=doc?.events.find(e=>e.id===id);if(!event)return;
    event.screenshots||={};event.screenshots[label]=dataUrl;
    await save();
   });},
   setActionOrder(groupId,firstIds){return enqueue(async()=>{
    // Zapisuje kolejność wierszy działań dla danej grupy zbiorów.
    // groupId: id pierwszego zdarzenia grupy (event.id z groupEvents)
    // firstIds: tablica refs[0].id kolejnych actionRun w nowej kolejności; pusta = reset do chronologicznej
    if(!doc||!groupId||!Array.isArray(firstIds))return;
    doc.actionOrder||(doc.actionOrder={});
    if(firstIds.length===0){delete doc.actionOrder[groupId];}
    else{doc.actionOrder[groupId]=firstIds;}
    await save();
   });}
  };
 }
 // Group only the presentation; the export retains every observed action.
 function groupEvents(events){
  const groups=[];
  for(const e of events){
   const previous=groups.at(-1);
   const near=previous&&e.run===previous.run&&e.at-previous.endAt<=30*60*1000&&e.at-previous.at<2*3600*1000;
   const explicit=previous&&e.run===previous.run&&e.groupId&&e.groupId===previous.groupId;
   const same=!e.groupStart&&(explicit||(near&&(!e.groupId||!previous.groupId||e.groupId===previous.groupId)&&e.kind!=='baseline'&&previous.kind!=='baseline'&&(e.kind==='change'||(e.kind==='collection'&&previous.kind==='collection'&&e.cycle===previous.cycle))));
   if(!same){groups.push({...e,endAt:e.at,changes:[...(e.changes||[])],actions:[e]});continue;}
   previous.endAt=e.at;previous.after=e.after;previous.changes.push(...(e.changes||[]));previous.actions.push(e);
  }
  return groups;
 }
 const labels={added:'Dodano budynek',removed:'Usunięto budynek',changed:'Zmieniono budynek',completed:'Ukończono budowę',connection:'Zmieniono połączenie z drogą',expansion:'Kupuję rozszerzenie'};
 // Stable per-building row keys preserve notes when adjacent actions are grouped.
 function actionRows(actions){
  const rows=[];
  for(const action of actions){
   if(action.kind==='baseline')continue;
   const snaps=[action.before,action.after];
   const items=snaps.flatMap(s=>[...(s?.summary?.groups||[]).flatMap(g=>g.items),...(s?.summary?.builds||[]),...(s?.summary?.extras||[])]);
   const maps=snaps.flatMap(s=>s?.map?.entities||[]);
   const entries=(action.changes||[]).flatMap((c,i)=>c.kind==='completed'?[]:[{...c,key:'change:'+i}]);
   for(const id of action.collected||[]){const entity=maps.find(e=>e.id===id),item=items.find(e=>e.id===id);const building=entity?.cityentity_id||item?.cityentity_id;
    if(building)entries.push({kind:'collection',id,building,key:'collection:'+id});
   }
   for(const entry of entries){
    if(action.hiddenRows?.includes(entry.key))continue;
    const name=items.find(i=>i.cityentity_id===entry.building)?.name||entry.building||labels[entry.kind]||entry.kind;
    const note=action.notes?.[entry.key]||'';
    const previous=rows.at(-1),ref={id:action.id,key:entry.key};
    if(previous&&previous.run===action.run&&previous.kind===entry.kind&&previous.building===entry.building&&entry.building&&previous.note===note&&action.at-previous.endAt<=120000){previous.count++;previous.endAt=action.at;previous.refs.push(ref);}
    else rows.push({kind:entry.kind,building:entry.building,name,note,at:action.at,endAt:action.at,run:action.run,count:1,refs:[ref]});
   }
  }
  return rows;
 }
 // Collapse uninterrupted runs of the same operation, aggregating all building types.
 function actionRuns(actions){
  const runs=[];
  for(const row of actionRows(actions)){
   let run=runs.at(-1);
   if(!run||run.run!==row.run||run.kind!==row.kind||row.at-run.endAt>30*60*1000){
    run={kind:row.kind,run:row.run,at:row.at,endAt:row.endAt,buildings:[],refs:[],notes:[]};runs.push(run);
   }
   run.endAt=row.endAt;run.refs.push(...row.refs);
   if(row.note&&!run.notes.includes(row.note))run.notes.push(row.note);
   const building=run.buildings.find(b=>b.building===row.building&&b.name===row.name);
   if(building){building.count+=row.count;building.refs.push(...row.refs);}
   else run.buildings.push({building:row.building,name:row.name,count:row.count,refs:[...row.refs]});
  }
  return runs.map(run=>({...run,note:run.notes.join(' · ')}));
 }
 function mount({root:host,button,history,getWidth=()=>350,getSnapshot=()=>null,getSettings=()=>({}),getPlayerId=()=>null}){
  const el=(tag,parent,text)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;parent?.append(n);return n;};
  const dialog=el('dialog',host);dialog.setAttribute('aria-label','Historia zbiorów');dialog.className='qh-window';
  dialog.style.cssText='position:fixed;inset:auto;margin:0;z-index:2147483646;box-shadow:0 8px 30px #0008;color:#e7eeee;background:#102126;border:1px solid #56727b;padding:0;box-sizing:border-box;width:min(1100px,96vw);max-width:96vw;min-width:min(360px,96vw);resize:horizontal;max-height:85vh;overflow:hidden;pointer-events:auto;font:11px/1.35 system-ui';
  const smallButton=(parent,label,handler)=>{const b=el('button',parent,label);b.style.cssText='font:11px/1.2 system-ui;padding:2px 5px;margin:0 0 0 5px;min-width:0';b.onclick=event=>{event?.preventDefault();event?.stopPropagation();return handler();};return b;};
  const top=el('div',dialog);top.style.cssText='display:flex;gap:6px;align-items:center;flex-wrap:wrap;flex-shrink:0;padding:10px 14px;z-index:1;background:#102126;cursor:grab;touch-action:none;user-select:none';el('h2',top,'Historia zbiorów').style.cssText='font-size:14px;margin:4px 0';
  const undo=smallButton(top,'↶ Cofnij',()=>history.undo());
  const download=smallButton(top,'Eksport JSON',()=>{}),close=smallButton(top,'×',()=>dialog.close());
  download.style.marginLeft='auto';close.setAttribute('aria-label','Zamknij historię');close.title='Zamknij historię';close.style.cssText='border:0;background:transparent;color:inherit;font-size:24px;padding:0 5px;cursor:pointer';

  let position=null,drag=null;
  function place(x,y){
   const rect=dialog.getBoundingClientRect();
   position={x:Math.max(0,Math.min(x,Math.max(0,root.innerWidth-rect.width*0.2))),y:Math.max(0,Math.min(y,Math.max(0,root.innerHeight-70)))};
   dialog.style.left=position.x+'px';dialog.style.top=position.y+'px';
  }
  top.addEventListener('pointerdown',event=>{
   if(event.button!==0||event.target.closest('button'))return;
   const rect=dialog.getBoundingClientRect();drag={id:event.pointerId,x:event.clientX-rect.left,y:event.clientY-rect.top};
   top.setPointerCapture(event.pointerId);top.style.cursor='grabbing';event.preventDefault();event.stopPropagation();
  });
  top.addEventListener('pointermove',event=>{
   if(!drag||event.pointerId!==drag.id)return;
   place(event.clientX-drag.x,event.clientY-drag.y);event.preventDefault();event.stopPropagation();
  });
  function endDrag(event){
   if(!drag||event.pointerId!==drag.id)return;
   const id=drag.id;drag=null;top.style.cursor='grab';
   if(top.hasPointerCapture(id))top.releasePointerCapture(id);
  }
  for(const type of ['pointerup','pointercancel','lostpointercapture'])top.addEventListener(type,endDrag);
  root.addEventListener('resize',()=>{if(dialog.open&&position)place(position.x,position.y);});
  const sizeObserver=new ResizeObserver(()=>{if(dialog.open&&position)place(position.x,position.y);});sizeObserver.observe(dialog);
  dialog.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();dialog.close();}});
  const css=el('style',dialog);css.textContent='.qh-window[open]{display:flex;flex-direction:column}input[data-history-note],input[data-history-note]:hover,input[data-history-note]:focus{border:0!important;outline:none!important;box-shadow:none!important;background:transparent!important}.qh-compare{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.qh-compare>div{min-width:0;overflow-wrap:anywhere}@media(max-width:600px){.qh-compare{grid-template-columns:1fr}}';
  const content=el('div',dialog);content.style.cssText='overflow:auto;min-height:0;padding:0 14px 14px;scrollbar-gutter:stable';
  const status=el('p',content);
  // Pasek sortowania nad listą zbiorów
  let sortDesc=true; // domyślnie: najnowsze na górze
  const sortBar=el('div',content);sortBar.style.cssText='display:flex;align-items:center;justify-content:flex-end;gap:6px;padding:4px 0 2px;font-size:11px;color:#8a9fa5';
  const sortBtn=el('button',sortBar,'');sortBtn.style.cssText='background:transparent;border:1px solid #345058;color:#a0bfc5;font-size:11px;padding:2px 7px;cursor:pointer;border-radius:3px';
  function updateSortBtn(){sortBtn.textContent=sortDesc?'Najnowsze ↑':'Najstarsze ↑';}
  updateSortBtn();
  sortBtn.onclick=()=>{sortDesc=!sortDesc;updateSortBtn();paint();};
  const list=el('div',content);let limit=30;
  const num=v=>Number.isFinite(v)?v.toLocaleString('pl-PL'):'—';
  const resources={guild_raids_money:'🪙 Monety',guild_raids_supplies:'🔨 Zaopatrzenie',guild_raids_chrono_alloy:'🔩 Stop',guild_raids_rope:'➰ Liny',guild_raids_happiness:'😊 Zadowolenie',guild_raids_population:'👥 Populacja',guild_raids_action_points_collection:'⚡ Akcje/h',guild_raids_action_points_capacity:'Pojemność akcji',att_def_boost_attacker:'Atak',att_def_boost_defender:'Obrona'};
  function snapshot(parent,snap,{expanded=false,showActions=false,actions=[],actionOrder=null}={}){
   if(!snap?.summary)return;
   const summary=snap.summary,FoeQuantum=root.FoeQuantum;
   const imgMaxWidth=Math.round(getWidth()||350);
   const wrap=el('div',parent);wrap.style.cssText='width:'+(imgMaxWidth+50)+'px;max-width:100%;box-sizing:border-box;margin:0 auto;padding-right:8px;color:#e7eeee;line-height:1.4';
   const stockBox=el('div',wrap),groups=el('div',wrap);
   const $=id=>id==='quantum-summary'?stockBox:groups;
   const text=(parent,value,tag='p')=>el(tag,parent,value);
      const box=$('quantum-summary');box.style.cssText='font-size:13px;line-height:1.4;color:#f0e6d2;margin-bottom:12px';
      const stocks=text(box,'','div');stocks.style.cssText='display:flex;flex-wrap:wrap;gap:10px;font-weight:bold;border-bottom:1px solid #4a3525;padding-bottom:6px;margin-bottom:8px;justify-content:center';
      const num=n=>Number.isFinite(n)?n.toLocaleString('pl-PL'):'—';
      for(const [key,icon] of [['guild_raids_money','🪙'],['guild_raids_supplies','🔨'],['guild_raids_chrono_alloy','🔩'],['guild_raids_rope','➰']]){
        const node=text(stocks,icon+' '+num(summary.wallet[key]),'span');
        if(key==='guild_raids_rope')node.title=summary.ropeCapacity===null?'Brak danych do obliczenia produkcji lin.':'Z obecnych zapasów można wyprodukować maksymalnie '+num(summary.ropeCapacity)+' lin, łącząc dostępne paczki. Kalkulacja kosztów, bez kosztu budowy wytwórni.';
      }
      const mood=text(stocks,'✨ '+(summary.currentBonuses.euphoria?'150%':summary.currentBonuses.unhappy?'niska':'100%'),'span');mood.style.color=summary.currentBonuses.euphoria?'#4caf50':'#dfd1b8';
      const hourly=text(box,'🪙 +'+summary.bonuses.coins+'% / 🔨 +'+summary.bonuses.supplies+'% · ⚡ '+num(summary.actionsPerHour)+'/h · ⚔️ '+(summary.actionsPerHour/3500).toLocaleString('pl-PL',{maximumFractionDigits:2})+'/h','div');hourly.style.cssText='text-align:center;font-size:12px;color:#a99885;margin-bottom:8px';
      const table=document.createElement('table');table.style.cssText='background:#0b191e;width:100%;border-collapse:collapse;font-size:12px;margin-bottom:8px';box.append(table);
      const tr=document.createElement('tr');table.append(tr);text(tr,'Następny zbiór:','th');
      const next=summary.totals;
      for(const [key,icon] of [['guild_raids_money','🪙'],['guild_raids_supplies','🔨'],['guild_raids_chrono_alloy','🔩']]){const cell=text(tr,icon+' '+num(next?.[key]),'td');cell.style.cssText='padding:6px 4px;border-left:1px solid #4a3525;text-align:center;font-weight:bold';}

      const resourceValues=[summary.totals,...summary.groups.map(g=>g.production),...summary.groups.flatMap(g=>g.items.map(i=>i.production))];
      resourceValues.push(Object.fromEntries(FoeQuantum.KEYS.map(k=>[k,(summary.totals[k]||0)+summary.builds.reduce((sum,b)=>sum+(b.production?.[k]||0),0)])));
      const resourceColumns='minmax(0,1fr) '+FoeQuantum.KEYS.map(k=>Math.max(2,...resourceValues.map(v=>num(v[k]||0).length))+'ch').join(' ');
      const buildProduction=FoeQuantum.groupedBuildings(summary.builds.filter(b=>b.hasProduction)).map(item=>({...item,underConstruction:true}));
      const buildExtras=FoeQuantum.groupedExtras(summary.builds.filter(b=>!b.hasProduction&&FoeQuantum.EXTRA_KEYS.some(k=>b.effects[k]))).map(item=>({...item,underConstruction:true}));
      const constructionStyle=';opacity:0.5';
      const addConstructionTotal=(table,keys,totals,pending,field)=>{
        if(!pending.length)return;
        const label=text(table,'🚧 Suma z budową','span');label.style.cssText='font-weight:bold;padding:2px 0;text-align:left'+constructionStyle;
        label.title='Suma bieżących wierszy i budynków w budowie. Produkcja według bonusów zestawienia; bez przeliczania wpływu nowych budynków na pozostałe.';
        for(const key of keys){const value=(totals[key]||0)+pending.reduce((sum,item)=>sum+(item[field][key]||0)-(field==='effects'?(item.activeEffects?.[key]||0):0),0);const cell=text(table,value?num(value):'—','span');cell.style.cssText='text-align:right;font-weight:bold;padding:2px 0'+constructionStyle;}
      };
      // Zestawienie budynków i sumarycznej produkcji (domyślnie rozwinięte)
      if(summary.groups.length||buildProduction.length){
        const allItems=summary.groups.flatMap(g=>g.items);
        const grouped=[...FoeQuantum.groupedBuildings(allItems),...buildProduction];
        // Sortuj malejąco wg chronostopów + monet + młotków
        grouped.sort((a,b)=>{
          const score=item=>(item.production['guild_raids_chrono_alloy']||0)+(item.production['guild_raids_money']||0)+(item.production['guild_raids_supplies']||0);
          return score(b)-score(a);
        });
        const sec=document.createElement('details');sec.open=expanded;sec.style.cssText='';
        const hrZ=document.createElement('hr');hrZ.style.cssText='border:none;border-top:1px solid #2e4450;margin:10px 0 6px';$('quantum-groups').append(hrZ);
        $('quantum-groups').append(sec);
        const secLabel=document.createElement('summary');secLabel.style.cssText='font-weight:bold;font-size:12px;cursor:pointer;color:#8fcfcf;margin-bottom:4px;text-align:left';secLabel.textContent='Zestawienie';sec.append(secLabel);
        const tbl=document.createElement('div');tbl.style.cssText='display:grid;grid-template-columns:'+resourceColumns+';gap:0 8px;font-size:11px;font-variant-numeric:tabular-nums;';sec.append(tbl);
        // Nagłówki
        for(const h of ['','🪙','🔨','🔩']){const hd=document.createElement('span');hd.textContent=h;hd.style.cssText=(h?'text-align:right':'text-align:left')+';font-weight:bold;padding:1px 0;border-bottom:1px solid #4a3525';tbl.append(hd);}
        for(const item of grouped){
          const nameCell=document.createElement('span');const b=document.createElement('strong');b.textContent=item.count+'×';nameCell.append(b,' '+item.name+(item.underConstruction?' 🚧':''));nameCell.style.cssText='padding:1px 0;text-align:left'+(item.underConstruction?constructionStyle:'');if(item.underConstruction)nameCell.title='W budowie — bieżąca suma obejmuje tylko aktywne efekty.';tbl.append(nameCell);
          for(const k of FoeQuantum.KEYS){const c=document.createElement('span');c.textContent=item.production[k]?item.production[k].toLocaleString('pl-PL'):'—';c.style.cssText='text-align:right;padding:1px 0;color:'+(item.production[k]?'#f0e6d2':'#6a7a7e')+(item.underConstruction?constructionStyle:'');tbl.append(c);}
        }
        // Suma
        const totalsRow=document.createElement('span');totalsRow.textContent='Suma';totalsRow.style.cssText='font-weight:bold;padding:2px 0;text-align:left;border-top:1px solid #4a3525';tbl.append(totalsRow);
        for(const k of FoeQuantum.KEYS){const c=document.createElement('span');c.textContent=summary.totals[k]?summary.totals[k].toLocaleString('pl-PL'):'—';c.style.cssText='text-align:right;font-weight:bold;padding:2px 0;border-top:1px solid #4a3525';tbl.append(c);}
        addConstructionTotal(tbl,FoeQuantum.KEYS,summary.totals,buildProduction,'production');
      }
      // Sekcja: Pozostałe budynki (nieprodukcyjne — stałe efekty)
      if(summary.extras?.length||buildExtras.length){
        const grouped=[...FoeQuantum.groupedExtras(summary.extras||[]),...buildExtras];
        // Sortuj malejąco wg działań kwantowych na godzinę
        grouped.sort((a,b)=>(b.effects['guild_raids_action_points_collection']||0)-(a.effects['guild_raids_action_points_collection']||0));
        // Suma zadowolenia — kolumna widoczna tylko gdy <= 5000
        const totalHappiness=grouped.reduce((s,g)=>s+(g.effects['guild_raids_happiness']||0),0);
        // Ustal dynamicznie które kolumny mają jakiekolwiek wartości != 0
        const extraColDefs=[
          {key:'guild_raids_happiness',    label:'😊', title:'Zadowolenie'},
          {key:'guild_raids_population',   label:'👥', title:'Populacja'},
          {key:'guild_raids_action_points_collection', label:'⚡', title:'Produkcja działań/h'},
          {key:'guild_raids_action_points_capacity',   label:'🔋', title:'Pojemność działań'},
          {key:'att_def_boost_attacker',   label:'🗡️', title:'Bonus ataku atakującego %'},
          {key:'att_def_boost_defender',   label:'🛡️', title:'Bonus obrony obrońcy %'},
        ];
        const activeCols=extraColDefs.filter(col=>{
          // Pojemność działań — zawsze ukryta
          if(col.key==='guild_raids_action_points_capacity')return false;
          // Populacja — zawsze ukryta
          if(col.key==='guild_raids_population')return false;
          // Zadowolenie — ukryj gdy suma > 5000
          if(col.key==='guild_raids_happiness'&&totalHappiness>5000)return false;
          return grouped.some(g=>g.effects[col.key]!==0);
        });
        if(activeCols.length){
          const sec2=document.createElement('details');sec2.open=expanded;sec2.style.cssText='';
          const hrP=document.createElement('hr');hrP.style.cssText='border:none;border-top:1px solid #2e4450;margin:10px 0 6px';$('quantum-groups').append(hrP);
          $('quantum-groups').append(sec2);
          const sec2Label=document.createElement('summary');sec2Label.style.cssText='font-weight:bold;font-size:12px;cursor:pointer;color:#8fcfcf;margin-bottom:4px;text-align:left';sec2Label.textContent='Pozostałe budynki';sec2.append(sec2Label);
          const tbl2=document.createElement('div');
          tbl2.style.cssText=`display:grid;grid-template-columns:1fr ${activeCols.map(()=>'auto').join(' ')};gap:0 8px;font-size:11px;font-variant-numeric:tabular-nums;`;
          sec2.append(tbl2);
          // Nagłówki
          const hName=document.createElement('span');hName.style.cssText='font-weight:bold;padding:1px 0;text-align:left;border-bottom:1px solid #4a3525';tbl2.append(hName);
          for(const col of activeCols){const hd=document.createElement('span');hd.textContent=col.label;hd.title=col.title;hd.style.cssText='font-weight:bold;text-align:right;padding:1px 0;border-bottom:1px solid #4a3525';tbl2.append(hd);}
          // Wiersze
          const extTotals=Object.fromEntries(FoeQuantum.EXTRA_KEYS.map(k=>[k,0]));
          for(const item of grouped){
            const nameCell=document.createElement('span');const b=document.createElement('strong');b.textContent=item.count+'×';nameCell.append(b,' '+item.name+(item.underConstruction?' 🚧':''));nameCell.style.cssText='padding:1px 0;text-align:left'+(item.underConstruction?constructionStyle:'');if(item.underConstruction)nameCell.title='W budowie — bieżąca suma obejmuje tylko aktywne efekty.';tbl2.append(nameCell);
            for(const col of activeCols){
              const v=item.effects[col.key]||0;
              const c=document.createElement('span');
              c.textContent=v?(item.count>1&&col.key!=='guild_raids_happiness'&&col.key!=='guild_raids_population'?v.toLocaleString('pl-PL'):v.toLocaleString('pl-PL')):'—';
              c.style.cssText='text-align:right;padding:1px 0;color:'+(v!==0?(v<0?'#e57373':'#f0e6d2'):'#6a7a7e')+(item.underConstruction&&!item.activeEffects?.[col.key]?constructionStyle:'');
              if(item.underConstruction&&item.activeEffects?.[col.key])c.title='Działa już podczas budowy.';
              tbl2.append(c);
              extTotals[col.key]+=item.underConstruction?(item.activeEffects?.[col.key]||0):v;
            }
          }
          // Suma
          const sumName=document.createElement('span');sumName.textContent='Suma';sumName.style.cssText='font-weight:bold;padding:2px 0;text-align:left;border-top:1px solid #4a3525';tbl2.append(sumName);
          for(const col of activeCols){const c=document.createElement('span');const v=extTotals[col.key];c.textContent=v?v.toLocaleString('pl-PL'):'—';c.style.cssText='text-align:right;font-weight:bold;padding:2px 0;border-top:1px solid #4a3525;color:'+(v<0?'#e57373':'#f0e6d2');tbl2.append(c);}
          addConstructionTotal(tbl2,activeCols.map(col=>col.key),extTotals,buildExtras,'effects');
        }
      }
      // Sekcja działań — skondensowana, bez edycji
      if(showActions&&actions.length){
        const natural=actionRuns(actions);
        const runs=(()=>{
          if(!actionOrder?.length)return natural;
          const byFirst=new Map(natural.map(r=>[r.refs[0]?.id,r]));
          const sorted=actionOrder.map(id=>byFirst.get(id)).filter(Boolean);
          const rest=natural.filter(r=>!actionOrder.includes(r.refs[0]?.id));
          return [...sorted,...rest];
        })();
        if(runs.length){
          const hrA=document.createElement('hr');hrA.style.cssText='border:none;border-top:1px solid #2e4450;margin:10px 0 6px';wrap.append(hrA);
          const secA=document.createElement('details');secA.open=true;secA.style.cssText='text-align:left';wrap.append(secA);
          const secALabel=document.createElement('summary');secALabel.style.cssText='font-weight:bold;font-size:12px;cursor:pointer;color:#8fcfcf;margin-bottom:4px;text-align:left';secALabel.textContent='Działania ('+runs.length+')';secA.append(secALabel);
          const kindLabel={added:'Stawiam',removed:'Sprzedaję',collection:'Zbieram',changed:'Zmieniam',connection:'Połączenie'};
          for(const run of runs){
            const row=document.createElement('div');row.style.cssText='display:flex;align-items:baseline;gap:6px;padding:2px 0;font-size:11px;border-bottom:1px solid #1e3540;flex-wrap:wrap';secA.append(row);
            const time=document.createElement('span');
            const d=new Date(run.at);const h=d.getHours();const m=Math.floor(d.getMinutes()/10)*10;
            time.textContent=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
            time.style.cssText='color:#8a9fa5;flex-shrink:0';row.append(time);
            const desc=document.createElement('span');desc.style.cssText='flex:1;min-width:0';row.append(desc);
            const lbl=kindLabel[run.kind];if(lbl){const s=document.createElement('span');s.textContent=lbl+' ';s.style.cssText='color:#a99885';desc.append(s);}
            run.buildings.forEach((b,i)=>{if(i)desc.append(document.createTextNode(' · '));const strong=document.createElement('strong');strong.textContent=(b.building?b.count+'× ':'')+b.name;desc.append(strong);});
            if(run.note){const note=document.createElement('div');note.textContent=run.note;note.style.cssText='width:100%;color:#6a7a7e;font-style:italic;padding-left:2px;text-align:right';row.append(note);}
          }
        }
      }
  }
  let views=[];
  async function captureScreenshot(){
   return new Promise(resolve=>{
    if(!root.chrome?.runtime?.sendMessage){resolve({ok:false,error:'Brak dostępu do runtime'});return;}
    try{
     root.chrome.runtime.sendMessage({type:'captureTab'},(response)=>{
      if(root.chrome.runtime.lastError){resolve({ok:false,error:root.chrome.runtime.lastError.message});return;}
      resolve(response||{ok:false,error:'Brak odpowiedzi'});
     });
    }catch(e){resolve({ok:false,error:e.message});}
   });
  }
  function startFraming(onCapture){
   // Chowamy główny panel i okno historii
   const panelHost=host.host;
   const prevPanel=panelHost?.style.visibility||'';
   const prevDialog=dialog.style.visibility||'';
   if(panelHost)panelHost.style.visibility='hidden';
   dialog.style.visibility='hidden';
   // Panel kadrowania — identyczny styl co aside w panel.js
   const framing=document.createElement('div');framing.style.cssText='position:fixed;top:0;right:0;width:min(400px,96vw);height:100vh;background:#102126;color:#e7eeee;box-shadow:-8px 0 30px #0008;z-index:2147483646;pointer-events:all;display:flex;flex-direction:column;overflow:hidden;font:14px/1.5 system-ui';
   document.body.append(framing);
   // Tytuł — widoczny na zrzucie
   const titleBar=document.createElement('div');titleBar.style.cssText='flex-shrink:0;padding:8px 16px 6px;border-bottom:1px solid #345058';
   framing.append(titleBar);
   const lastGroup=history.lastGroup;
   const titleEl=document.createElement('span');titleEl.textContent=lastGroup?groupLabel(lastGroup):'Najazdy kwantowe';titleEl.style.cssText='font-weight:bold;font-size:11px;color:#f1d69a';titleBar.append(titleEl);
   // Treść — zestawienie kwantowe
   const body=document.createElement('div');body.style.cssText='flex:1;overflow:auto;padding:16px;scrollbar-width:thin;scrollbar-color:#45616a transparent;text-align:left';framing.append(body);
   const snap=getSnapshot();
   const settings=getSettings();
   const lastActions=lastGroup?.actions||[];
   const lastActionOrder=lastGroup?history.document?.actionOrder?.[lastGroup.id]:null;
   if(snap){snapshot(body,snap,{expanded:true,showActions:!!settings.showActions,actions:lastActions,actionOrder:lastActionOrder});}
   else{const p=document.createElement('p');p.textContent='Brak danych osady — otwórz osadę w grze.';p.style.color='#90a5ad';body.append(p);}
   // Pasek dolny z przyciskami i info — ukrywany podczas zrzutu
   const bottomBar=document.createElement('div');bottomBar.style.cssText='flex-shrink:0;border-top:1px solid #345058';framing.append(bottomBar);
   const btnRow=document.createElement('div');btnRow.style.cssText='display:flex;gap:8px;align-items:center;padding:8px 16px 6px';bottomBar.append(btnRow);
   const captureBtn=document.createElement('button');captureBtn.textContent='📷 Wykonaj zrzut';captureBtn.style.cssText='background:#2e7d32;border:0;color:#fff;font-size:13px;cursor:pointer;padding:5px 12px;pointer-events:all';btnRow.append(captureBtn);
   const cancelBtn=document.createElement('button');cancelBtn.textContent='✕ Anuluj';cancelBtn.style.cssText='background:transparent;border:1px solid #56727b;color:#e7eeee;font-size:13px;cursor:pointer;padding:5px 10px;pointer-events:all';btnRow.append(cancelBtn);
   const info=document.createElement('p');info.textContent='Ustaw widok osady, a następnie kliknij "Wykonaj zrzut".';info.style.cssText='margin:0;padding:0 16px 8px;font-size:11px;color:#8a9fa5';bottomBar.append(info);
   const close=()=>{framing.remove();if(panelHost)panelHost.style.visibility=prevPanel;dialog.style.visibility=prevDialog;};
   cancelBtn.onclick=close;
   captureBtn.onclick=async()=>{
    captureBtn.disabled=true;captureBtn.textContent='⏳';
    bottomBar.style.visibility='hidden';
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    const result=await captureScreenshot();
    bottomBar.style.visibility='';
    framing.remove();
    if(panelHost)panelHost.style.visibility=prevPanel;
    dialog.style.visibility=prevDialog;
    if(result.ok){onCapture(result.dataUrl);}
    else{captureBtn.disabled=false;captureBtn.textContent='📷 Wykonaj zrzut';const err=document.createElement('div');err.textContent='⚠ '+result.error;err.style.cssText='position:fixed;bottom:20px;right:20px;background:#b71c1c;color:#fff;padding:8px 14px;font-size:13px;z-index:2147483647';document.body.append(err);setTimeout(()=>err.remove(),4000);}
   };
  }
  function showLightbox(dataUrl){
   const backdrop=document.createElement('div');backdrop.style.cssText='position:fixed;inset:0;z-index:2147483646;background:transparent;pointer-events:all';document.body.append(backdrop);
   const lb=document.createElement('dialog');lb.style.cssText='padding:0;background:#000a;border:0;max-width:100vw;max-height:100vh;width:100vw;height:100vh;position:relative;display:flex;align-items:center;justify-content:center;pointer-events:all;z-index:2147483647';document.body.append(lb);
   lb.setAttribute('aria-label','Podgląd zrzutu ekranu');
   const img=document.createElement('img');img.src=dataUrl;lb.append(img);
   img.style.cssText='max-width:95vw;max-height:92vh;object-fit:contain;border:2px solid #56727b;border-radius:4px;box-shadow:0 8px 40px #000c;cursor:zoom-out;pointer-events:all';
   const toolbar=document.createElement('div');toolbar.style.cssText='position:absolute;top:12px;right:16px;display:flex;gap:8px;z-index:2147483647;pointer-events:all';lb.append(toolbar);
   const dlBtn=document.createElement('button');dlBtn.textContent='⬇ Pobierz';dlBtn.setAttribute('aria-label','Pobierz zrzut ekranu');dlBtn.style.cssText='background:#1a3a3a;border:1px solid #56727b;color:#fff;font-size:13px;border-radius:4px;cursor:pointer;padding:4px 10px;opacity:0.9;pointer-events:all';toolbar.append(dlBtn);
   dlBtn.onmouseenter=()=>dlBtn.style.opacity='1';dlBtn.onmouseleave=()=>dlBtn.style.opacity='0.9';
   const closeBtn=document.createElement('button');closeBtn.textContent='×';closeBtn.setAttribute('aria-label','Zamknij podgląd');closeBtn.style.cssText='background:transparent;border:0;color:#fff;font-size:32px;line-height:1;cursor:pointer;padding:0 4px;opacity:0.8;pointer-events:all';toolbar.append(closeBtn);
   closeBtn.onmouseenter=()=>closeBtn.style.opacity='1';closeBtn.onmouseleave=()=>closeBtn.style.opacity='0.8';
   const close=()=>{lb.close();lb.remove();backdrop.remove();document.removeEventListener('keydown',onKey,true);};
   const onKey=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close();}};
   document.addEventListener('keydown',onKey,true);
   lb.addEventListener('cancel',e=>e.preventDefault());
   dlBtn.onclick=e=>{e.stopPropagation();const a=document.createElement('a');a.href=dataUrl;a.download='zrzut-osady-'+new Date().toISOString().slice(0,19).replace(/:/g,'-')+'.jpg';document.body.append(a);a.click();a.remove();};
   closeBtn.onclick=e=>{e.stopPropagation();close();};
   img.onclick=close;
   lb.showModal();
  }
  const childDetails=node=>Array.from(node.children||[]).flatMap(child=>child.tagName==='DETAILS'?[child]:childDetails(child));
  const remember=node=>({open:node.open,children:childDetails(node).map(remember)});
  function restore(node,state){
   if(!state)return;node.open=state.open;
   if(node.open)node.historyBuild?.();
   childDetails(node).forEach((child,i)=>restore(child,state.children[i]));
  }
  const groupLabel=event=>(event.kind==='collection'?'Zbiór '+event.cycle:event.kind==='baseline'?'Początek obserwacji':'Żonglowanie')+' · '+new Date(event.at).toLocaleString('pl-PL',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
  function paint(){
   if(!dialog.open)return;
   undo.disabled=!history.undoCount;undo.title=history.undoLabel?'Cofnij: '+history.undoLabel+' ('+history.undoCount+'/3)':'Brak operacji do cofnięcia';
   if((host.activeElement||document.activeElement)?.dataset?.historyNote==='1')return;
   const scrollTop=content.scrollTop,states=new Map();
   for(const view of views){const state=remember(view.node);for(const id of view.ids)states.set(id,state);}
   views=[];const doc=history.document;list.replaceChildren();
   status.textContent=history.error;status.hidden=!history.error;
   download.disabled=!doc?.events.length;
   if(!doc?.events.length){el('p',list,'Brak zapisanej historii zbiorów dla tego świata.');return;}
   const grouped=groupEvents(doc.events).filter(e=>actionRows(e.actions).length);
   // Kumulatywne walki per event (od początku runu do tego eventu włącznie)
   const cumFights=new Map(); // eventId → walki
   const runState=new Map(); // run → {prevAt, prevAph}
   for(const e of [...doc.events].filter(ev=>ev.kind==='collection').sort((a,b)=>a.at-b.at)){
    const prev=runState.get(e.run);
    const aph=e.before?.summary?.actionsPerHour??e.after?.summary?.actionsPerHour;
    const prevFights=prev?.cumFights??0;
    let fights=prevFights;
    if(prev&&aph!=null){const dtH=(e.at-prev.prevAt)/3600000;fights+=prev.prevAph/3500*dtH;}
    // Dodaj ogon do końca najazdu jeśli to jest ostatni zbiór z tym endsAt
    const endsAt=e.after?.summary?.raid?.endsAt??e.before?.summary?.raid?.endsAt;
    const curAph=e.after?.summary?.actionsPerHour??aph;
    const tailFights=(endsAt&&curAph)?(()=>{const dtH=(endsAt*1000-e.at)/3600000;return dtH>0&&dtH<14*24?curAph/3500*dtH:0;})():0;
    cumFights.set(e.id,{base:fights,tail:tailFights,total:fights+tailFights});
    runState.set(e.run,{prevAt:e.at,prevAph:curAph??aph??0,cumFights:fights});
   }
   const displayGroups=sortDesc?grouped.slice(-limit).reverse():grouped.slice(0,limit);
   for(const event of displayGroups){
    const details=el('details',list);details.style.cssText='background:#162e35;border:1px solid #345058;padding:5px 7px;margin:4px 0;border-radius:4px';
    views.push({node:details,ids:event.actions.map(e=>e.id)});
    const heading=el('summary',details,groupLabel(event));
    const remove=smallButton(heading,'×',()=>history.remove(event.actions.map(e=>e.id)));remove.title='Usuń cały wpis';remove.setAttribute('aria-label','Usuń cały wpis');remove.style.float='right';
    if(event.kind==='collection'){
     const collEv=event.actions.find(e=>e.kind==='collection');
     const cf=collEv&&cumFights.get(collEv.id);
     if(cf!=null){
      const fightsBtn=document.createElement('button');
      fightsBtn.style.cssText='float:right;cursor:default;background:transparent;border:1px solid #345058;color:#f1d69a;font-size:11px;padding:1px 5px;margin:0 2px 0 0;display:inline-flex;align-items:center;gap:3px';
      fightsBtn.title='Walki wykonane od początku najazdu do tego zbioru';
      fightsBtn.onclick=e=>{e.preventDefault();e.stopPropagation();};
      const icon=document.createElement('span');icon.textContent='⚔️';fightsBtn.append(icon);
      const num=document.createElement('span');num.textContent=Math.round(cf.base).toLocaleString('pl-PL');num.style.cssText='display:inline-block;min-width:4ch;text-align:right;font-variant-numeric:tabular-nums';fightsBtn.append(num);
      heading.append(fightsBtn);
     }
    }
    const previous=grouped.slice(0,grouped.indexOf(event)).some(g=>g.run===event.run&&g.kind==='collection');
    if(event.kind!=='baseline'){const merge=smallButton(heading,'Połącz z poprzednim zbiorem',()=>history.merge(event.id));merge.disabled=!previous;}
    details.historyBuild=()=>{if(!details.open||details.dataset.built)return;details.dataset.built='1';
     const rows=(()=>{
      const natural=actionRuns(event.actions); // domyślnie: najstarsze na górze
      const order=history.document?.actionOrder?.[event.id];
      if(!order?.length)return natural;
      // Sortuj wg zapisanej kolejności; nieznane runy dołączamy na koniec
      const byFirst=new Map(natural.map(r=>[r.refs[0]?.id,r]));
      const sorted=order.map(id=>byFirst.get(id)).filter(Boolean);
      const rest=natural.filter(r=>!order.includes(r.refs[0]?.id));
      return [...sorted,...rest];
     })();
     const actions=el('details',details);actions.style.cssText='background:#18333b;padding:6px 9px;margin:6px 0';
     const actionsSummary=el('summary',actions,'Działania ('+rows.length+')');
     const hasCustomOrder=!!(history.document?.actionOrder?.[event.id]?.length);
     if(hasCustomOrder){
      const resetBtn=smallButton(actionsSummary,'↺ Resetuj kolejność',async()=>{
       const doc=history.document;if(!doc)return;
       doc.actionOrder||(doc.actionOrder={});
       delete doc.actionOrder[event.id];
       // Zapisz przez setActionOrder z pustą tablicą żeby wyczyścić
       await history.setActionOrder(event.id,[]);
       delete details.dataset.built;paint();
      });resetBtn.title='Przywróć kolejność chronologiczną';resetBtn.style.cssText='font:11px/1.2 system-ui;padding:2px 5px;margin:0 0 0 5px;min-width:0;float:right';
     }
     // Drag state
     let dragSrc=null,dragIdx=-1;
     for(const [rowIdx,action] of rows.entries()){
      const row=el('div',actions);row.style.cssText='display:flex;align-items:center;flex-wrap:wrap;gap:7px;padding:5px 0;border-bottom:1px solid #29434b';
      row.dataset.rowIdx=rowIdx;
      // Uchwyt do przeciągania
      const handle=el('span',row,'⠿');handle.style.cssText='cursor:grab;color:#56727b;font-size:14px;flex-shrink:0;user-select:none;touch-action:none';handle.title='Przeciągnij żeby zmienić kolejność';
      row.draggable=false;
      handle.addEventListener('mousedown',()=>{row.draggable=true;});
      handle.addEventListener('mouseleave',()=>{if(!dragSrc)row.draggable=false;});
      row.addEventListener('dragstart',e=>{dragSrc=row;dragIdx=rowIdx;e.dataTransfer.effectAllowed='move';row.style.opacity='0.4';});
      row.addEventListener('dragend',()=>{row.draggable=false;dragSrc=null;dragIdx=-1;row.style.opacity='';actions.querySelectorAll('[data-row-idx]').forEach(r=>{r.style.borderTop='';r.style.borderBottom='1px solid #29434b';});});
      row.addEventListener('dragover',e=>{if(!dragSrc||dragSrc===row)return;e.preventDefault();e.dataTransfer.dropEffect='move';actions.querySelectorAll('[data-row-idx]').forEach(r=>{r.style.borderTop='';r.style.borderBottom='1px solid #29434b';});const targetIdx=Number(row.dataset.rowIdx);if(targetIdx<dragIdx)row.style.borderTop='2px solid #5bb8d4';else row.style.borderBottom='2px solid #5bb8d4';});
      row.addEventListener('dragleave',()=>{row.style.borderTop='';row.style.borderBottom='1px solid #29434b';});
      row.addEventListener('drop',async e=>{
       e.preventDefault();if(!dragSrc||dragSrc===row)return;
       actions.querySelectorAll('[data-row-idx]').forEach(r=>{r.style.borderTop='';r.style.borderBottom='1px solid #29434b';});
       const fromIdx=dragIdx,toIdx=Number(row.dataset.rowIdx);
       if(fromIdx===toIdx)return;
       // Buduj nową kolejność firstIds przenosząc fromIdx na toIdx
       const currentOrder=rows.map(r=>r.refs[0]?.id);
       const moved=currentOrder.splice(fromIdx,1)[0];
       currentOrder.splice(toIdx,0,moved);
       await history.setActionOrder(event.id,currentOrder);
       delete details.dataset.built;paint();
      });
      el('span',row,new Date(action.at).toLocaleTimeString('pl-PL'));
      const label={added:'Stawiam:',removed:'Sprzedaję:',collection:'Zbieram:',changed:'Zmieniam:',connection:'Połączenie:'}[action.kind]||'';
      const description=el('span',row);description.style.cssText='min-width:0;overflow-wrap:anywhere';
      if(label)el('span',description,label+' ');
      action.buildings.forEach((building,index)=>{
       if(index)el('span',description,' · ');
       el('strong',description,(building.building?building.count+'× ':'')+building.name);
      });
      const input=el('input',row);input.type='text';input.dataset.historyNote='1';input.onblur=()=>Promise.resolve().then(paint);input.value=action.note;input.placeholder='Dodaj notatkę…';input.maxLength=2000;input.setAttribute('aria-label','Notatka: '+action.buildings.map(b=>b.name).join(', '));
      input.style.cssText='flex:1;min-width:100px;max-width:100%;background:transparent;color:inherit;border:0;outline:none;box-shadow:none;font:inherit;padding:4px;text-align:right';
      input.onchange=()=>history.editRows(action.refs,input.value);
      const split=smallButton(row,'✂️',()=>history.split(action.refs));split.title='Rozdziel od tego działania (to działanie i późniejsze utworzą osobną grupę)';split.setAttribute('aria-label','Rozdziel od tego działania');split.disabled=action.refs[0]?.id===event.actions[0]?.id;
      const remove=smallButton(row,'×',()=>history.removeRows(action.refs));remove.title='Usuń działanie';remove.setAttribute('aria-label','Usuń działanie');
     }
     const comparison=el('details',details);el('summary',comparison,'Przed i Po');
     comparison.historyBuild=()=>{if(!comparison.open||comparison.dataset.built)return;comparison.dataset.built='1';const columns=el('div',comparison);columns.className='qh-compare';
      // Auto-kopiuj "Po" z poprzedniego zbioru do "Przed" jeśli jeszcze nie ma
      const prevGroup=grouped.slice(0,grouped.indexOf(event)).reverse().find(g=>g.run===event.run&&g.kind==='collection');
      const prevPo=prevGroup?.actions.map(a=>a.screenshots?.['Po']).find(Boolean);
      const hasPrzed=event.actions.some(a=>a.screenshots?.['Przed']);
      if(prevPo&&!hasPrzed){
       const targetId=event.actions[0]?.id||event.id;
       history.saveScreenshot(targetId,'Przed',prevPo);
      }
      for(const [label,snap] of [['Przed',event.before],['Po',event.after]]){
       const column=el('div',columns);column.style.cssText='display:flex;flex-direction:column;align-items:flex-start';
       const header=el('div',column);header.style.cssText='display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:4px;width:100%';
       el('h3',header,label).style.cssText='margin:0;text-align:center';
       // Przycisk aparatu — tylko dla ostatniego zbioru danego run
       const isLatest=!grouped.slice(grouped.indexOf(event)+1).some(g=>g.run===event.run);
       const camBtn=el('button',header,'📷');camBtn.title='Zrób zrzut ekranu dla "'+label+'" (nadpisuje istniejący)';camBtn.setAttribute('aria-label','Zrzut ekranu: '+label);
       camBtn.style.cssText='background:transparent;border:0;cursor:pointer;font-size:16px;padding:2px 4px;opacity:0.7;line-height:1';
       if(!isLatest)camBtn.hidden=true;
       camBtn.onclick=async()=>{
        const targetId=event.actions[0]?.id||event.id;
        startFraming(async dataUrl=>{
         await history.saveScreenshot(targetId,label,dataUrl);
         renderThumbnail(column,label,dataUrl);
         camBtn.textContent='📷';camBtn.disabled=false;
        });
       };
       // Miniaturka jeśli już zapisana (lub skopiowana z poprzedniego Po)
       const existing=event.actions.map(a=>a.screenshots?.[label]).find(Boolean)||(label==='Przed'?prevPo:null);
       if(existing)renderThumbnail(column,label,existing);
       if(snap)snapshot(column,snap);else el('p',column,'Brak zapisanego stanu.');
      }
      function renderThumbnail(column,label,dataUrl){
       column.querySelector('.qh-thumb')?.remove();
       const wrap=el('div',column);wrap.className='qh-thumb';wrap.style.cssText='position:relative;margin:6px auto 15px;max-width:100%';
       const img=el('img',wrap);img.src=dataUrl;img.alt='Zrzut ekranu: '+label;
       img.style.cssText='max-width:100%;display:block;cursor:zoom-in;object-fit:cover;border:1px solid #345058';
       img.title='Kliknij, aby powiększyć';img.onclick=()=>showLightbox(dataUrl);
       const dlBtn=el('button',wrap,'⬇');dlBtn.setAttribute('aria-label','Pobierz zrzut: '+label);
       dlBtn.style.cssText='position:absolute;top:4px;right:4px;background:#0006;border:0;color:#fff;font-size:14px;cursor:pointer;padding:2px 5px;line-height:1;opacity:0.75';
       dlBtn.onmouseenter=()=>dlBtn.style.opacity='1';dlBtn.onmouseleave=()=>dlBtn.style.opacity='0.75';
       dlBtn.onclick=e=>{e.stopPropagation();const a=el('a',wrap);a.href=dataUrl;a.download='zrzut-osady-'+label.toLowerCase()+'-'+new Date().toISOString().slice(0,19).replace(/:/g,'-')+'.jpg';a.click();a.remove();};
      }
     };comparison.addEventListener('toggle',comparison.historyBuild);
    };
    details.addEventListener('toggle',details.historyBuild);
    restore(details,event.actions.map(e=>states.get(e.id)).find(Boolean));
   }
   if(grouped.length>limit){const more=el('button',list,'Pokaż starsze');more.onclick=()=>{limit+=30;paint();};}
   content.scrollTop=scrollTop;
  }
  button.onclick=async()=>{if(!position)dialog.style.width='min('+Math.max(900,2*(getWidth()||350)+120)+'px,96vw)';if(!dialog.open)dialog.show();const rect=dialog.getBoundingClientRect();place(position?.x??(root.innerWidth-rect.width)/2,position?.y??Math.max(12,root.innerHeight*0.06));status.textContent='Wczytywanie historii…';await history.loadLatest?.(getPlayerId());await history.ready();paint();};
  dialog.addEventListener('close',()=>button.focus());history.onChange=paint;
  download.onclick=async()=>{await history.ready();const blob=new Blob([history.export()],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),link=el('a',dialog);link.href=url;link.download='najazdy-kwantowe-historia-'+new Date().toISOString().slice(0,10)+'.json';link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 }
 root.FoeQuantumHistory={create,changes,groupEvents,actionRows,actionRuns,mount};if(typeof module!=='undefined')module.exports=root.FoeQuantumHistory;
})(globalThis);
