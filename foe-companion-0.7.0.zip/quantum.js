(function(root){
 const KEYS=['guild_raids_money','guild_raids_supplies','guild_raids_chrono_alloy'];
 const empty=()=>Object.fromEntries(KEYS.map(k=>[k,0]));
 function ropeCapacity(definitions,wallet){
   const options=[...definitions.values()].find(d=>d.id.endsWith('_Ropery'))?.components?.AllAge?.production?.options||[];
   const packs=options.flatMap(o=>(o.products||[]).filter(p=>p.playerResources?.resources?.guild_raids_rope>0).map(p=>({amount:p.playerResources.resources.guild_raids_rope,cost:p.requirements?.resources})));
   if(!packs.length||!Number.isFinite(wallet.guild_raids_money)||!Number.isFinite(wallet.guild_raids_supplies))return null;
   const gcd=(a,b)=>b?gcd(b,a%b):a;
   if(packs.some(p=>!p.cost?.guild_raids_money||!p.cost?.guild_raids_supplies))return null;
   const unit=packs.map(p=>p.cost.guild_raids_money).reduce(gcd),ratio=packs[0].cost.guild_raids_supplies/packs[0].cost.guild_raids_money;
   if(packs.some(p=>Math.abs(p.cost.guild_raids_supplies/p.cost.guild_raids_money-ratio)>1e-8))return null;
   const budget=Math.max(0,Math.floor(Math.min(wallet.guild_raids_money,wallet.guild_raids_supplies/ratio)/unit));
   if(budget>2000000)return null;
   const dp=new Float64Array(budget+1);
   for(let b=1;b<=budget;b++){dp[b]=dp[b-1];for(const p of packs){const cost=p.cost.guild_raids_money/unit;if(cost<=b)dp[b]=Math.max(dp[b],dp[b-cost]+p.amount);}}
   return dp[budget];
 }
 const categoryOrder=['main_building','residential','production','goods','culture','decoration'];
 function groupedBuildings(items){const groups=new Map();for(const item of items){const key=item.cityentity_id||item.name;let g=groups.get(key);if(!g){g={name:item.name,category:item.category,count:0,production:empty()};groups.set(key,g);}g.count++;for(const k of KEYS)g.production[k]+=item.production[k];}return [...groups.values()].sort((a,b)=>(categoryOrder.indexOf(a.category)<0?99:categoryOrder.indexOf(a.category))-(categoryOrder.indexOf(b.category)<0?99:categoryOrder.indexOf(b.category))||a.name.localeCompare(b.name,'pl'));}
 const EXTRA_KEYS=['guild_raids_happiness','guild_raids_population','guild_raids_action_points_collection','guild_raids_action_points_capacity','att_def_boost_attacker','att_def_boost_defender'];
 const emptyExtra=()=>Object.fromEntries(EXTRA_KEYS.map(k=>[k,0]));
 function groupedExtras(items){
  const groups=new Map();
  for(const item of items){
   const key=item.cityentity_id||item.name;let g=groups.get(key);
   if(!g){g={name:item.name,category:item.category,count:0,effects:emptyExtra(),activeEffects:emptyExtra()};groups.set(key,g);}
   g.count++;
   for(const k of EXTRA_KEYS){g.effects[k]+=item.effects[k]||0;g.activeEffects[k]+=item.activeEffects?.[k]||0;}
  }
  return [...groups.values()].sort((a,b)=>(categoryOrder.indexOf(a.category)<0?99:categoryOrder.indexOf(a.category))-(categoryOrder.indexOf(b.category)<0?99:categoryOrder.indexOf(b.category))||a.name.localeCompare(b.name,'pl'));
 }
 function isSettlementResponse(data){return (Array.isArray(data)?data:[data]).some(r=>r?.requestClass==='CityMapService'&&r.requestMethod==='getCityMap'&&r.responseData?.gridId==='guild_raids');}
 function walk(data,fn){const q=[data];for(let i=0;i<q.length&&i<250000;i++){const v=q[i];if(!v||typeof v!=='object')continue;fn(v);for(const c of Object.values(v))if(c&&typeof c==='object')q.push(c);}}
 function products(option){const sum=empty();for(const p of option?.products||[]){const r=p.playerResources?.resources;if(r)for(const k of KEYS)sum[k]+=Number(r[k])||0;}return sum;}
 const armyNames={guild_raids_catapult:'Katapulta',guild_raids_spearman:'Włócznik',guild_raids_armoredswordsman:'Ciężkozbrojny',guild_raids_bombarde:'Bombarda'};
 function summarizeArmy(info,updatedAt){
  const groups=new Map();
  for(const u of info.units){
   const count=u.__class__==='ArmyUnitStack'?u.count:1;
   if(!Number.isSafeInteger(count)||count<1)continue;
   let row=groups.get(u.unitTypeId);
   if(!row){row={id:u.unitTypeId,name:armyNames[u.unitTypeId]||u.unitTypeId,total:0,healthy:0,wounded:0,unknown:0,selected:0,hitpoints:[]};groups.set(u.unitTypeId,row);}
   row.total+=count;
   if(u.currentHitpoints===10)row.healthy+=count;
   else if(Number.isFinite(u.currentHitpoints)&&u.currentHitpoints>0&&u.currentHitpoints<10)row.wounded+=count;
   else row.unknown+=count;
   if(u.is_attacking){row.selected+=count;row.hitpoints.push({hp:u.currentHitpoints,count});}
  }
  return {updatedAt,stale:false,rows:[...groups.values()].sort((a,b)=>a.name.localeCompare(b.name,'pl'))};
 }
 function createTracker(){
  const definitions=new Map();let map=null,raid=null,wallet={},version=0,activeGrid=null,army=null;
  function consume(data,{fallback=false}={}){
   for(const r of Array.isArray(data)?data:[data]){
    const info=r?.responseData;
    // Only a full own-army response is authoritative; previews and battle units are not inventory.
    if(r?.requestClass==='ArmyUnitManagementService'&&r.requestMethod==='getArmyInfo'&&info?.__class__==='ArmyInfo'&&Array.isArray(info.units)&&info.units.length&&info.units.every(u=>u.unitTypeId?.startsWith('guild_raids_'))){
     army=summarizeArmy(info,Date.now()/1000);version++;
    }else if(army&&((r?.requestClass==='BattlefieldService'&&info?.battleType?.type==='guild_raids')||(r?.requestClass==='ArmyUnitManagementService'&&(r.requestMethod!=='getArmyInfo'||info?.units?.length===0)))){
     army={...army,stale:true};version++;
    }
   }
   walk(data,v=>{
    if(v.__class__==='GenericCityEntity'&&typeof v.id==='string'&&v.components){if(!fallback||!definitions.has(v.id))definitions.set(v.id,v);version++;}
    if(typeof v.gridId==='string'&&Array.isArray(v.entities))activeGrid=v.gridId;
    if(v.gridId==='guild_raids'&&Array.isArray(v.entities)){map=v;version++;}
    if(v.__class__==='GuildRaidsRunningState'){if(raid&&raid.endsAt!==v.endsAt)army=null;raid={name:v.raidInstance?.raidName,difficulty:v.raidInstance?.difficultyLevel,endsAt:v.endsAt};version++;}
    if(v.__class__==='ResourceBag'){
     const r=v.resources?.resources||v.resources;
     if(r&&Object.keys(r).some(k=>k.startsWith('guild_raids_'))){for(const [k,n] of Object.entries(r))if(k.startsWith('guild_raids_')&&typeof n==='number')wallet[k]=n;version++;}
    }
   });
   // Typed additions and updates are scoped to this outpost, never the main city.
   if(map)walk(data,v=>{if(v.__class__==='CityMapEntity'&&typeof v.cityentity_id==='string'&&v.cityentity_id.includes('GuildRaids')){
    const owner=map.entities.find(e=>e.player_id!=null)?.player_id;
    if(owner!=null&&v.player_id!=null&&owner!==v.player_id)return;
    const i=map.entities.findIndex(e=>e.id===v.id);
    if(i<0){map={...map,entities:[...map.entities,v]};version++;}
    else if(map.entities[i]!==v){map={...map,entities:map.entities.map((e,n)=>n===i?{...e,...v}:e)};version++;}
   }});
   if(map&&activeGrid==='guild_raids')for(const r of Array.isArray(data)?data:[data]){
    if(r?.requestClass==='CityMapService'&&r.requestMethod==='deleteEntity'&&Number.isSafeInteger(r.responseData)&&map.entities.some(e=>e.id===r.responseData)){
     map={...map,entities:map.entities.filter(e=>e.id!==r.responseData)};version++;
    }
   }
   return version;
  }
  function component(e){return definitions.get(e.cityentity_id)?.components?.AllAge;}
  function summary(now=Date.now()/1000){
   if(!map)return null;
   const missing=new Set(),items=[],builds=[],extras=[];
   for(const e of map.entities){
    if(e.cityentity_id.includes('Impediment'))continue;
    const def=definitions.get(e.cityentity_id),c=component(e),s=e.state||{},name=e.cityentity_id==='H_GuildRaidsEarlyMiddleAge_Townhall'||e.type==='main_building'?'Ratusz':def?.name||e.cityentity_id;
    if(!def&&e.type!=='main_building')missing.add(e.cityentity_id);
    // Budynki nieprodukcyjne (stałe efekty) — zbierane jako extras
    const extraEffects=emptyExtra();
    const sr=c?.staticResources?.resources?.resources||{};
    for(const k of ['guild_raids_happiness','guild_raids_population'])if(sr[k])extraEffects[k]=Number(sr[k])||0;
    for(const b of c?.boosts?.boosts||[]){
     if(b.type==='guild_raids_action_points_collection')extraEffects.guild_raids_action_points_collection=Number(b.value)||0;
     if(b.type==='guild_raids_action_points_capacity')extraEffects.guild_raids_action_points_capacity=Number(b.value)||0;
     if(b.type==='att_def_boost_attacker')extraEffects.att_def_boost_attacker=Number(b.value)||0;
     if(b.type==='att_def_boost_defender')extraEffects.att_def_boost_defender=Number(b.value)||0;
    }
    const hasExtras=EXTRA_KEYS.some(k=>extraEffects[k]!==0);
    if(s.__class__==='ConstructionState'){
     const emoji={guild_raids_happiness:'😊',guild_raids_population:'👥'},benefits=[];
     for(const [key,value] of Object.entries(c?.staticResources?.resources?.resources||{}))if(emoji[key])benefits.push(emoji[key]+' '+value);
     for(const boost of c?.boosts?.boosts||[]){
      if(boost.type==='guild_raids_action_points_collection')benefits.push('⚡ '+boost.value);
      if(boost.type==='guild_raids_coins_production')benefits.push('🪙 +'+boost.value+'%');
      if(boost.type==='guild_raids_supplies_production')benefits.push('🔨 +'+boost.value+'%');
     }
     // Bazowa produkcja z opcji produkcyjnych definicji
     const prodEmoji={guild_raids_money:'🪙',guild_raids_supplies:'🔨',guild_raids_chrono_alloy:'🔩'};
     for(const opt of c?.production?.options||[]){
      const sum=products(opt);
      const time=opt.time?(opt.time>=3600?(opt.time/3600)+'h':(opt.time/60)+'min'):'';
      for(const k of KEYS)if(sum[k])benefits.push(prodEmoji[k]+' '+sum[k].toLocaleString('pl')+(time?' / '+time:''));
     }
     const options=(c?.production?.options||[]).filter(opt=>KEYS.some(k=>products(opt)[k]));
     builds.push({name,cityentity_id:e.cityentity_id,category:c?.constructionMenu?.category,underConstruction:true,effects:extraEffects,activeEffects:{guild_raids_action_points_collection:e.connected!==0?extraEffects.guild_raids_action_points_collection:0},raw:options.length===1?products(options[0]):null,hasProduction:options.length>0,at:s.next_state_transition_at||null,benefits:benefits.join('\n')});continue;
    }
    const ready=s.__class__==='ProductionFinishedState'||s.__class__==='ProductionReadyState';
    if(s.__class__!=='ProducingState'&&!ready){
     if(hasExtras&&e.connected!==0)extras.push({id:e.id,name,cityentity_id:e.cityentity_id,category:e.type==='main_building'?'main_building':c?.constructionMenu?.category,effects:extraEffects});
     continue;
    }
    let raw=products(s.productionOption);
    if(!KEYS.some(k=>raw[k])){
     const r=s.current_product?.product?.resources;
     if(r)raw=Object.fromEntries(KEYS.map(k=>[k,Number(r[k])||0]));
     else {const options=c?.production?.options||[];if(options.length===1)raw=products(options[0]);}
    }
    if(!KEYS.some(k=>raw[k]))continue;
    if(e.connected===0)continue;
    const at=ready?now:Number(s.next_state_transition_at);
    if(!Number.isFinite(at))continue;
    items.push({id:e.id,name,cityentity_id:e.cityentity_id,category:e.type==='main_building'?'main_building':c?.constructionMenu?.category,at:Math.max(now,at),raw,hall:e.type==='main_building',x:e.x,y:e.y});
   }
   items.sort((a,b)=>a.at-b.at);
   const groups=[];
   for(const item of items){let group=groups.at(-1);if(!group||item.at-group.at>3600){group={at:item.at,items:[],production:empty()};groups.push(group);}group.at=item.at;group.items.push(item);}
   function bonuses(at){let population=0,happiness=0,coins=0,supplies=0;
    for(const e of map.entities){if(e.connected===0)continue;const c=component(e);if(!c)continue;
     if(e.state?.__class__==='ConstructionState'&&(!e.state.next_state_transition_at||e.state.next_state_transition_at>at))continue;
     const r=c.staticResources?.resources?.resources||{};population+=Math.max(0,Number(r.guild_raids_population)||0);happiness+=Number(r.guild_raids_happiness)||0;
     for(const b of c.boosts?.boosts||[]){if(b.type==='guild_raids_coins_production')coins+=b.value;if(b.type==='guild_raids_supplies_production')supplies+=b.value;}
    }
    // 100% is the conservative base below euphoria; severe unhappiness is flagged.
    return {population,happiness,coins,supplies,euphoria:happiness>=population*2,multiplier:happiness>=population*2?1.5:1,unhappy:happiness<population};
   }
   const totals=empty();
   for(const g of groups){g.bonuses=bonuses(g.at);for(const item of g.items){item.production=empty();for(const k of KEYS){
    const boost=k===KEYS[0]?g.bonuses.coins:k===KEYS[1]?g.bonuses.supplies:0;
    // Production boosts and the +50% euphoria bonus add to the base.
    const value=item.hall?item.raw[k]:Math.round(item.raw[k]*(g.bonuses.multiplier+boost/100));
    item.production[k]=value;g.production[k]+=value;totals[k]+=value;
   }}}
   // Construction previews use the same bonuses as the production overview.
   const previewBonuses=bonuses(groups.at(-1)?.at||now);
   for(const build of builds){build.production=empty();if(build.raw)for(const k of KEYS){
    const boost=k===KEYS[0]?previewBonuses.coins:k===KEYS[1]?previewBonuses.supplies:0;
    build.production[k]=Math.round(build.raw[k]*(previewBonuses.multiplier+boost/100));
   }}
   let actionsPerHour=5000;
   for(const e of map.entities){if(e.connected===0)continue;for(const b of component(e)?.boosts?.boosts||[])if(b.type==='guild_raids_action_points_collection')actionsPerHour+=Number(b.value)||0;}
   return {groups,totals,builds,extras,missing:[...missing],actionsPerHour,ropeCapacity:ropeCapacity(definitions,wallet),currentBonuses:bonuses(now),raid,wallet:{...wallet},bonuses:bonuses(groups.at(-1)?.at||now),entityCount:map.entities.filter(e=>!e.cityentity_id.includes('Impediment')).length};
  }
  return {consume,summary,definitions,get map(){return map;},get army(){return army;}};
 }
 const api={createTracker,KEYS,EXTRA_KEYS,groupedBuildings,groupedExtras,isSettlementResponse,calculationVersion:3};root.FoeQuantum=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
