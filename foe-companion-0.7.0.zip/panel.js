(() => {
  'use strict';

  let battle = null,
    count = 0,
    output = '',
    paint = () => {},
    notice = '',
    mapReady = false;

  const methods = [];
  let playerAttrition=null,paintAttrition=()=>{};
  function readPlayerAttrition(responses){
    let value;
    for(const response of responses){
      if(response?.requestClass!=='GuildBattlegroundService')continue;
      const data=response.responseData;
      const participant=response.requestMethod==='getBattleground'?data?.currentPlayerParticipant:response.requestMethod==='getPlayerParticipant'?data:null;
      const attrition=participant?.attrition;
      if(attrition?.__class__!=='GuildBattlegroundAttrition')continue;
      const level=attrition.level??0;
      if(Number.isSafeInteger(level)&&level>=0)value=level;
    }
    return value;
  }

  let construction = null,
    paintPearl = () => {},
    paintCity = () => {};

  let ownPlayerId = null;
  fetch(chrome.runtime.getURL('building-fp-types.json')).then(r=>r.json()).then(types=>{for(const [id,fp] of Object.entries(types))FoeModel.seedProductionType(id,fp);paintCity();}).catch(()=>{});
  const metadataNamesKey='foe-companion.metadataBuildingNames';
  let metadataNames={};
  try{const stored=JSON.parse(localStorage.getItem(metadataNamesKey)||'{}');if(stored&&typeof stored==='object'&&!Array.isArray(stored))metadataNames=stored;}catch{}
  for(const [id,name] of Object.entries(metadataNames))if(/^[A-Z]+_[A-Za-z0-9_]+$/.test(id)&&typeof name==='string')FoeModel.seedName(id,name);

  const pearlTracker = FoePearls.createTracker();
  const quantumTracker = FoeQuantum.createTracker();
  const quantumHistory = FoeQuantumHistory.create();
  let paintQuantum=()=>{},syncNotes=()=>{};
  fetch(chrome.runtime.getURL('quantum-definitions.json')).then(r=>r.json()).then(defs=>{
    quantumTracker.consume(defs,{fallback:true});
    for(const def of defs) FoeModel.seedName(def.id,def.name);
    paintQuantum();paintPearl();
  }).catch(()=>{});

  // Ostatnia cyfra 1-5 wciśnięta przed otwarciem perły
  let lastDigit = null;

  // Funkcje ustawiane w mount(), pozwalają otworzyć panel
  // z poziomu listenera odbierającego dane gry.
  let openPearlPanel = () => {};
  let openGbgPanel   = () => {};
  let openQuantumPanel = () => {};

window.addEventListener('message', event => {
  if (
    event.source !== window ||
    event.origin !== location.origin
  ) {
    return;
  }

  const channel = event.data?.channel;
  if(channel==='foe-building-names'){
    let changed=false;
    for(const item of Array.isArray(event.data.names)?event.data.names:[]){
      if(!item||typeof item.id!=='string'||!/^[A-Z]+_[A-Za-z0-9_]+$/.test(item.id)||typeof item.name!=='string'||!item.name.trim())continue;
      if(item.producesFP===true){FoeModel.seedProductionType(item.id,true);changed=true;}
      const name=item.name.trim();if(metadataNames[item.id]===name)continue;
      metadataNames[item.id]=name;FoeModel.seedName(item.id,name);changed=true;
    }
    if(changed){try{localStorage.setItem(metadataNamesKey,JSON.stringify(metadataNames));}catch{}paintCity();paintPearl();}
    return;
  }

  // --- foe-companion-v1: dane gry ---
  if (channel !== 'foe-companion-v1') return;

  count++;

  const data = event.data.data;
  const responses = Array.isArray(data) ? data : [data];
  if(FoeModel.updateCollectionBonuses(data))paintCity();
  const attrition=readPlayerAttrition(responses);
  if(attrition!==undefined){playerAttrition=attrition;paintAttrition();}

  // Uzupełniaj słownik nazw ze wszystkich odpowiedzi
  FoeModel.learnNames(data);
  const quantumBefore=quantumTracker.map?{map:quantumTracker.map,summary:quantumTracker.summary()}:null;
  quantumTracker.consume(data);
  if(quantumTracker.map&&quantumBefore?.map!==quantumTracker.map)quantumHistory.observe(data,quantumBefore,{map:quantumTracker.map,summary:quantumTracker.summary()});
  paintQuantum();
  if(FoeQuantum.isSettlementResponse(data))openQuantumPanel();

  construction = pearlTracker.consume(
    data,
    event.data.methods || []
  );

  /*
   * AUTOMATYCZNE OTWIERANIE PANELU
   *
   * Panel wysuwa się przy każdym otwarciu perły —
   * czyli gdy w odpowiedzi gry pojawia się getConstruction.
   */
  const hasConstruction = responses.some(
    r => r?.requestClass === 'GreatBuildingsService' &&
         r?.requestMethod === 'getConstruction'
  );

  if (hasConstruction) {
    openPearlPanel();
  }

  paintPearl();

  for (const response of responses) {
    if (typeof response?.requestClass === 'string') {
      methods.push(
        `${response.requestClass}.${response.requestMethod || ''}`
      );
    }

    // StartupService.getData — parsuj całe miasto
    if (response?.requestClass === 'StartupService' &&
        response?.requestMethod === 'getData' &&
        response?.responseData?.city_map?.entities) {
      // Wyciągnij własne player_id z user_data
      if (!ownPlayerId) {
        ownPlayerId = response.responseData.user_data?.player_id ?? null;
      }
      FoeModel.parseCity(response.responseData.city_map.entities, ownPlayerId);
      paintCity();
      paintPearl();
    }

    if (
      response?.requestClass === 'GuildBattlegroundStateService' &&
      response?.requestMethod === 'getState' &&
      !battle
    ) {
      notice =
        'Wykryto Pola Chwały. Oczekuję na odpowiedź z mapą sektorów.';
    }
  }

  methods.splice(
    0,
    Math.max(0, methods.length - 20)
  );

  const update = FoeModel.updateBattle(
    battle,
    data
  );

  if (update.changed) {
    battle = update.battle;
    notice = '';
    if(!event.data.internal)openGbgPanel();
  }

  // Aktualizuj stan budynków miasta z CityMapEntity w bieżącej odpowiedzi
  const cityUpdate = FoeModel.updateCity(data);
  if (cityUpdate.changed) {
    paintCity();
  }

  paint();
});

  Promise.all(['sectors.json','sectors-volcano.json'].map(file=>fetch(chrome.runtime.getURL(file)).then(r=>r.json())))
    .then(maps => {
      maps.forEach(m=>FoeModel.setTopology(m));
      mapReady = true;
      paint();
    })
    .catch(() => {
      notice = 'Nie udało się załadować mapy sektorów.';
      paint();
    });

  fetch(chrome.runtime.getURL('building-names.json'))
    .then(r => r.json())
    .then(names => {
      // Zasilamy słownik gotowymi nazwami — learnNames przyjmuje obiekt {ceid: name}
      for (const [ceid, name] of Object.entries(names)) {
        FoeModel.seedName(ceid, name);
      }
      paintCity();
      paintPearl();
    })
    .catch(() => {});

  function mount() {
    const advancedSettings=globalThis.FoeMode?.advanced===true;
    const host = document.createElement('div');

    host.style.cssText =
      'position:fixed;inset:0;pointer-events:none;z-index:2147483647';

    document.documentElement.append(host);

    const root = host.attachShadow({
      mode: 'closed'
    });

    // The MAIN-world keyboard guard sees this flag even with our closed shadow root.
    root.addEventListener('focusin',event=>{host.dataset.foeEditing=event.composedPath()[0]?.matches('input[data-history-note],textarea#notes-text,#list')?'1':'0';});
    root.addEventListener('focusout',()=>{delete host.dataset.foeEditing;});
    root.innerHTML = `
      <style>
        :host {
          all: initial
        }

        * {
          box-sizing: border-box
        }

        button,
        input {
          font: inherit
        }

        button {
          cursor: pointer;
          background: #243d45;
          border: 1px solid #405961;
          color: #e9f1f2;
          border-radius: 0px;
          padding: 4px 4px
        }
        button#handle {
          cursor: pointer;
          background: #243d45;
          border: 1px solid #405961;
          color: #e9f1f2;
          border-radius: 8px;
          border-top-right-radius: 0px;
          border-bottom-right-radius: 0px;
          padding: 8px 12px
        }
        button#close {
          cursor: pointer;
          background: transparent;
          border: none;
          color: #e9f1f2;
          padding: 8px 12px;
          font-size:20px;
        }

        button:hover {
          background: #355660
        }

        #handle {
          position: absolute;
          right: 0;
          top: 90%;
          pointer-events: auto;
          color: #f1d69a;
          font: 700 14px system-ui
        }

        aside {
          position: absolute;
          right: 0;
          top: 0;
          width: min(400px, 96vw);
          height: 100vh;
          overflow: auto;
          padding: 20px;
          background: #102126;
          color: #e7eeee;
          box-shadow: -8px 0 30px #0008;
          pointer-events: auto;
          font: 14px/1.5 system-ui;
          transform: translateX(105%);
          transition: transform .2s
        }

        aside.open {
          transform: none
        }

        header {
          display: flex;
          justify-content: space-between;
          align-items: center
        }

        h1 {
          font-size: 19px;
          color: #f1d69a;
          margin: 0
        }

        h2 {
          font-size: 17px
        }

        nav {
          display: flex;
          gap: 7px;
          margin: 18px 0;
          border-bottom: 1px solid #345058;
          padding-bottom: 12px
        }

        nav button {
          width: 43px;
          height: 39px;
          padding: 4px;
          font-size: 19px
        }

        nav button[aria-selected=true] {
          border-color: #e1be77;
          background: #39525a
        }

        section[hidden] {
          display: none
        }

        pre {
          white-space: pre-wrap;
          background: #0b191e;
          border-radius: 8px;
          padding: 12px;
          font: 13px/1.9 monospace;
          max-height: 300px;
          overflow-y: auto
        }

        p {
          color: #aebfc4
        }

        #notice {
          color: #e1be77;
          font-size: 12px
        }

        label {
          display: block;
          margin: 12px 0
        }

        #feedback {
          font-size: 12px
        }

        small {
          color: #90a5ad
        }
      </style>

      <button
        id="handle"
        aria-label="Otwórz panel"
      >
        FoE ›
      </button>

      <aside>
        <header>
          <h1>
            FOE Companion
            <small style="font-size:11px;font-weight:400">
              v.${(chrome.runtime.getManifest().version_name || chrome.runtime.getManifest().version)}
            </small>
          </h1>

          <button
            id="close"
            aria-label="Zamknij"
          >
            ×
          </button>
        </header>

        <nav
          role="tablist"
          aria-label="Sekcje"
        >
          <button role="tab" data-page="nego" id="nego-tab" aria-selected="false" title="Negocjacje poza Polami Chwały" hidden>🤝 Nego</button>
          <button
            role="tab"
            data-page="gb"
            aria-label="Kalkulator pereł"
            title="Kalkulator pereł"
            aria-selected="true"
          >
            🏛️
          </button>

          <button
            role="tab"
            data-page="gbg"
            aria-label="Pola Chwały"
            title="Pola Chwały"
            aria-selected="false"
          >
            ⚔️
          </button>

          <button
            role="tab"
            data-page="city"
            aria-label="Zbiory"
            title="Zbiory"
            aria-selected="false"
          >
            🏘️
          </button>

          <button
            role="tab"
            data-page="settings"
            aria-label="Ustawienia"
            title="Ustawienia"
            aria-selected="false"
          >
            ⚙️
          </button>
        </nav>

        <section
          id="gb"
          role="tabpanel"
        >
          <h2>Kalkulator pereł</h2>

          <p id="pearl-status" style="font-size:11px">
            Otwórz perłę w grze.
          </p>

          <div id="pearl-rows"></div>

          <small>

          </small>

          <p id="pearl-feedback" style="font-size:11px"></p>
          <p id="pearl-refresh-note" hidden style="font-size:10px;color:#7a9099;margin-top:6px">Po wpłacie z panelu stan PR na perle w grze może nie być widoczny do czasu kolejnej akcji. Aby odświeżyć: wpłać dodatkowe 1 PR, poczekaj na wpłatę innej osoby lub odśwież stronę.</p>
        </section>

        <section
          id="gbg"
          role="tabpanel"
          hidden
        >
          <div id="gbg-title"><h2>Pola Chwały</h2></div>

          <div id="open-sectors-heading" style="display:flex;align-items:center;gap:6px"><h3 style="margin-right:auto">Otwarte sektory</h3><button id="copy-open" title="Kopiuj otwarte sektory" aria-label="Kopiuj otwarte sektory" style="background:transparent;border:0;box-shadow:none;margin:0;padding:0;min-width:0;line-height:1;cursor:pointer">📋</button><button id="sector-guard-open" title="Opcje pilnowania sektorów" aria-label="Opcje pilnowania sektorów" style="background:transparent;border:0;box-shadow:none;margin:0;padding:0 2px;min-width:0;line-height:1;cursor:pointer;color:#8a9fa5;font-size:16px">⋮</button><button id="own-sectors-open" title="Nasze sektory" aria-label="Nasze sektory" style="background:transparent;border:0;box-shadow:none;margin:0;padding:0 2px;min-width:0;line-height:1;cursor:pointer">🏠</button></div>
          <div id="open-sectors"></div>
          <p id="battle-feedback" role="status"></p>

          <div id="schedule-heading"><h3>Rozpiska</h3><label><input id="frontier" type="checkbox" checked> tylko sąsiedzi</label></div>

          <p id="notice"></p>

          <pre id="list">
Otwórz mapę Pól Chwały w grze.
          </pre>

          <button id="copy">
            Kopiuj rozpiskę
          </button>
          <button id="export-battle" disabled style="display:none">Pobierz stan mapy JSON</button>

          <p id="feedback"></p>

        </section>

        <section
          id="city"
          role="tabpanel"
          hidden
        >
          <h2>Zbiory</h2>
          <p id="city-status" style="color:#aebfc4;font-size:13px">
            Odśwież grę, aby załadować dane miasta.
          </p>
          <div id="city-list"></div>
        </section>

        <section
          id="settings"
          role="tabpanel"
          hidden
        >
          <details id="settings-pearls"><summary>Perły architektury</summary>

          <label>
            Przelicznik
            <input
              id="multiplier"
              type="text"
              inputmode="decimal"
              value="1.9"
              style="width:75px;padding:6px;margin-left:8px"
              aria-label="Przelicznik nagrody"
            >
          </label>

          <label>Bonus Arki (%) <input id="arc-bonus" type="text" inputmode="decimal" value="92.7" style="width:75px;padding:6px;margin-left:8px" aria-label="Bonus nagrody Arki w procentach"></label>
          <label><input id="auto-copy" type="checkbox" checked> Kopiuj kwotę (klawisze 1–5)</label>
          </details><details id="settings-open"><summary>Wysuwaj panel</summary>
          <div class="settings-open">
            <label><input id="auto-open" type="checkbox" checked> Otwarcie perły</label>
            <label><input id="auto-open-gbg" type="checkbox" checked> Pola Chwały</label>
            <label><input id="auto-open-quantum" type="checkbox" checked> Osada kwantowa</label>
            <label hidden><input id="auto-open-nego" type="checkbox" checked> Negocjacje</label>
          </div>
          </details>
          <details id="settings-gbg"><summary>Pola chwały</summary>
          <label><input id="show-attack-buttons" type="checkbox"> Wyświetlaj przyciski ataku</label>
          <label><input id="show-negotiation-buttons" type="checkbox"> Wyświetlaj przyciski negocjacji</label>
          <div class="settings-alert">
            <label><input id="gbg-sound-enabled" type="checkbox"> Alert</label>
            <select id="gbg-sound-kind" aria-label="Sygnał alertu"><option value="classic">Trzy piknięcia</option><option value="ding">Ding-dong</option><option value="single">Pojedynczy</option><option value="melody">Melodyjka</option><option value="alarm">Alarm</option></select>
            <input id="gbg-sound-minutes" type="number" min="1" max="60" step="1" value="2" aria-label="Wyprzedzenie w minutach" title="Wyprzedzenie alertu (minuty)"><span>min</span>
            <button id="gbg-sound-test" title="Odsłuch sygnału" aria-label="Odsłuch sygnału">▶</button>
          </div>
          <div id="gbg-automation-settings"></div>
          </details>
          <details id="settings-buildings"><summary>Budynki</summary><label><input id="show-collection-buttons" type="checkbox"> Wyświetlaj przyciski zbiorów</label></details>

          <details id="settings-quantum"><summary>Najazdy kwantowe</summary>
          <label><input id="quantum-show-history" type="checkbox"> Dziennik zbiorów</label>
          <label><input id="quantum-show-snapshot" type="checkbox"> Panel na zrzucie</label>
          <label><input id="quantum-show-actions" type="checkbox"> Działania na zrzucie</label>
          <button id="quantum-clear-history" type="button">Wyczyść dziennik zbiorów</button><small id="quantum-clear-history-status" role="status" style="display:block;margin:4px 0"></small>
          </details>



          <details id="changelog"><summary>Changelog · ${(chrome.runtime.getManifest().version_name || chrome.runtime.getManifest().version)}</summary><div style="max-height:240px;overflow-y:auto;font-size:11px;line-height:1.45"><p><strong>0.7.0</strong></p><ul><li>Podsumowanie linii 0.6: automatyzacja Pól Chwały, historia najazdów, rozpiska Discord i porządkowanie ustawień.</li><li>Wspólny styl checkboxów, zwijane sekcje ustawień i konfigurowalna rozpiska.</li><li>Modal sektorów: zmiana szerokości, kopiowanie zamkniętych sektorów, zaznaczanie tekstu i wyróżnianie wykonywanej akcji.</li><li>Edytowalne checkboxy zamkniętych sektorów i reset wyborów po przejęciu. Opcjonalny opór zamkniętych sektorów w rozpisce i kopii.</li><li>Potwierdzone odrzucenie walki przez serwer pozwala ponowić próbę bez odświeżania strony.</li></ul><p><strong>0.6.14</strong></p><ul><li>Pełna instrukcja użytkownika: osobny opis każdej zakładki, przycisków, emoji, pól i komunikatów.</li><li>Globalny autoatak może pominąć gildyjne oznaczenie ignorowania; lokalne „Ignoruj” nadal blokuje automat.</li><li>Poprawione kopiowanie rozpiski Discorda i nieaktywne kontrolki nadchodzących sektorów.</li></ul><p><strong>0.6.13</strong></p><ul><li>Rozpiska Discorda: kompaktowy blok tekstu z wyrównanymi godzinami i sektorami.</li><li>Poprawiona autoryzacja żądań Discord API; sprawdzanie kanału i aktualizacja rozpiski nie wymagają odczytu historii wiadomości.</li></ul><p><strong>0.6.12</strong></p><ul><li>Nasze sektory: własne pola, ataki przeciwnika, sloty budynków, opór sąsiadów i oznaczenia gildii; emoji nagłówków z tooltipami, trzy równe kwadraty slotów.</li><li>Dziennik zbiorów dostępny z zakładki Najazdy kwantowe bez otwierania osady.</li><li>Kopiowanie wszystkich sektorów podaje godzinę otwarcia HH:mm zamiast odliczania.</li></ul><p><strong>0.6.11</strong></p><ul><li>Modal Nasze sektory: własne sektory, postęp ataku przeciwnika, zajęte sloty budynków, opór sąsiadów oraz gildyjne oznaczenia ✋ i 🎯.</li></ul><p><strong>0.6.10</strong></p><ul><li>Lokalne Ignoruj wyklucza sektor z obu automatów otwartych sektorów, niezależnie od gildyjnego oznaczenia.</li><li>Opcja zamykania negocjacjami dla 🕐 i ⚡, z rezerwą, limitem oporu i STOP; bez limitu porażek.</li><li>Ustawiany próg autozamykania ⚡, domyślnie 50% postępu wroga.</li><li>Ukrywanie całych kolumn akcji; przy obu opcjach wyłączonych także checkboxów. Puste nagłówki kolumn automatów.</li><li>Autoatak pomija niekwalifikujący się sektor przed wysłaniem walki i kontynuuje kolejkę bez naliczania porażki.</li></ul><p><strong>0.6.09</strong></p><ul><li>Modal: do 5 nadchodzących sektorów pod otwartymi, posortowanych według czasu otwarcia. Przygaszone wiersze mają wyłączone przyciski i checkboxy.</li><li>Kolumna Otwarcie: odliczanie HH:MM:SS lub Otwarte. Przejście do otwartych i uzupełnianie listy bez ponownego otwierania okna.</li></ul><p><strong>0.6.08</strong></p><ul><li>Usunięcie ostatniej gildyjnej łapki ✋ aktualizuje panel i oba automaty, także gdy gra pomija puste pole signals. Po zdjęciu oznaczenia sektor jest ponownie kwalifikowany bez przełączania automatu.</li></ul><p><strong>0.6.07</strong></p><ul><li>Własne sektory ⚪ wykluczone z list i alarmów otwartych sektorów.</li><li>Tabela otwartego modala odświeża progres, dostępność i stan akcji bez zmiany położenia okna.</li><li>Aktualizacje sektorów wszystkich gildii zerują nieaktualne blokady i progres, umożliwiając ponowną kwalifikację do automatyzacji.</li></ul><p><strong>0.6.06</strong></p><ul><li>Autoatak otwartych sektorów: ustawiany limit szansy wzrostu oporu, domyślnie 20%, sprawdzany ponownie przed walką.</li><li>Kontynuacja autonegocjacji po potwierdzonym przejęciu sektora i zakończeniu negocjacji.</li><li>Pływające okno, przeciąganie za nagłówek; status na dole bez tooltipa.</li><li>Powiadomienia do 99%, krótszy progres, wyścig 🔥, wróg 👾 i opór 🔻.</li><li>Kopiowanie pojedynczego sektora, przyciski automatów jako emoji i opisy kolumn pilnowania.</li></ul><p><strong>0.6.05</strong></p><ul><li>Powiadomienia sektorów: nasz postęp i postęp wroga 👾, alarm 🔔 we wspólnej liście, usuwanie zamkniętych sektorów.</li><li>Nagłówki 🔔, 🕐 i ⚡ przełączają całą widoczną kolumnę pilnowania.</li><li>Wskaźniki ⚔️ i 🤝 przy tytule otwartych sektorów oraz nad uchwytem panelu; kliknięcie zatrzymuje wybrany automat.</li><li>Modal pokazuje wspólne liczniki walk, negocjacji i oporu.</li></ul><p><strong>0.6.04</strong></p><ul><li>Otwarte sektory: widoczny przycisk autonegocjacji z powodem blokady, STOP tylko podczas automatyzacji. Limit sektora także z postępu innych gildii; pierwszy autoatak przy nieznanym limicie i zerowym postępie.</li><li>Otwarte sektory: wspólna kolejka autoataku i autonegocjacji, STOP, limity progresu i wybór typu sektora.</li><li>Negocjacje: limit oporu i trwały limit sukcesów na otwarcie, bez limitu porażek. Autoatak zatrzymuje się po 3 porażkach z rzędu.</li></ul><p><strong>0.6.03</strong></p><ul><li>Historia: licznik walk przy każdym zbiorze — skumulowane walki od początku najazdu do danego zbioru (⚔️ N).</li><li>Walki liczone jako suma interwałów między zbiorami × actionsPerHour z danego okresu.</li></ul><p><strong>0.6.02</strong></p><ul><li>Najazdy: ustawienia w panelu — dziennik zbiorów, panel na zrzucie, działania na zrzucie.</li><li>Zrzut: tytuł z nazwą i datą zbioru widoczny na zrzucie; przyciski przeniesione na dół panelu.</li><li>Historia: porównanie Przed/Po wycentrowane z 15 px odstępem pod zrzutem; zawartość wyrównana do lewej.</li><li>Sekcja działań na zrzucie: skondensowana lista z godziną, etykietą, budynkami i notatką.</li><li>Etykiety zbiorów bez sekund; „Zestawienie" i „Pozostałe budynki" wyrównane do lewej.</li></ul><p><strong>0.6.01</strong></p><ul><li>Historia zbiorów: pływające okno bez blokowania strony, przeciągane za pasek tytułu; do 80% szerokości poza prawą krawędzią. Zmiana szerokości za prawy dolny róg.</li><li>Najazdy: sekcja Wojsko ze stanem jednostek, zdrowiem, składem atakującym i czasem ostatniego odczytu.</li></ul><p><strong>0.6.00</strong></p><ul><li>Najazdy: uporządkowana historia bez technicznych duplikatów, nazwy zbieranych budynków i najnowsze działania na górze.</li><li>Kolejne zbiory, sprzedaże i budowy w tekstowych grupach z licznikami; trwałe uwagi wyrównane do prawej.</li><li>Wycentrowane porównanie Przed/Po, eksport po prawej, zamknięcie × i poprawione odstępy od suwaków.</li><li>Osobne, domyślnie wyłączone ustawienia przycisków ataku, negocjacji i zbiorów oraz informacja o ryzyku bana.</li><li>Pola Chwały: nowa ikona wyścigu, uproszczone zaznaczenie sektora i tytuł powiadomień.</li><li>Wydanie porządkuje funkcje panelu z linii 0.5: zbiory, najazdy i rozpiski Pól Chwały.</li></ul><p><strong>0.5.02</strong></p><ul><li>🏁 Wyścig: sąsiedztwo konkurencyjnej gildii w powiadomieniu i rozpisce do 30 minut przed otwarciem.</li><li>Wyłączone wpłaty PR z panelu oraz negocjacje poza Polami Chwały.</li><li>Kategoria PR korzysta także z definicji produkcji: widoczne niezmotywowane Emporium Solary i oba egzemplarze Elizejskiego Młyna; obsługa losowej produkcji PR.</li><li>Pełniejsza lista budynków: widoczne nieaktywne produkcje, nowe budynki i osobne egzemplarze; kategorie PR i wojska niezależne od motywacji.</li><li>Zbiory: domyślna karta Ulubione, zapis wybranych budynków i przyciski dodawania/usuwania.</li><li>Zbierz wszystkie w każdej podzakładce: jedno zbiorcze żądanie dla gotowych budynków wybranej kategorii i osobna kontrola wyniku każdego zbioru.</li><li>Potwierdzenie zbioru wymaga zmiany stanu budynku; brak fałszywego sukcesu przy odrzuconym zbiorze.</li></ul><p><strong>0.5.01</strong></p><ul><li>Przeładowanie karty gry przez nowy proces rozszerzenia po aktualizacji.</li><li>Serwer deweloperski: status połączenia klienta, przekazania wersji i braku zapytań zamiast deklaracji wykonanego odświeżenia.</li></ul><p><strong>0.5.0</strong></p><ul><li>Zbiory: aktywne bonusy podwojenia i zaopatrzenia wraz z pozostałymi użyciami z odpowiedzi gry.</li><li>Zwijane ustawienia z pamięcią, wyrównane pola i wyraźne nagłówki.</li><li>Powiadomienia sektorów przy przycisku panelu: odliczanie, zamykanie i automatyczne ukrywanie.</li><li>Perły: zaniżone wpłaty zastępowane pełną kwotą inwestora, uwzględnienie przesunięć rankingu i kontrola przed wpłatą.</li><li>Zbiory: karty PR, pereł, wojska i pozostałych; oznaczenia gotowych zbiorów.</li><li>Nazwy budynków przechwytywane z metadanych gry; poprawiony przycisk resetowania nazw i tooltip.</li><li>Ustawiany zakres przerwy między turami negocjacji.</li><li>Opcje Pól Chwały przeniesione z diagnostyki; godziny w logach serwera deweloperskiego.</li><li>Pełna historia wersji w przewijalnym changelogu. Poprawione ładowanie modułu pereł w panelu i skrypcie gry.</li></ul><p><strong>0.4.22</strong> · status autonegocjacji w osobnej linii pod przyciskami</p>
<p><strong>0.4.21</strong> · automatyczna aktualizacja soli podpisu z pliku JS gry</p>
<p><strong>0.4.20</strong> · aktualizacja soli podpisu do wersji gry 1.345</p>
<p><strong>0.4.19</strong> · separatory między sekcjami kwantowymi</p>
<p><strong>0.4.18</strong> · zbiory kwantowe — domyślnie zwinięte, stan zachowany przy odświeżaniu danych</p>
<p><strong>0.4.17</strong> · zbiory kwantowe — wsp&#243;lny grid 4-kolumnowy wyr&#243;wnany z zestawieniem</p>
<p><strong>0.4.16</strong> · zestawienie pozostałych budynk&#243;w kwantowych z dynamicznymi kolumnami efekt&#243;w</p>
<p><strong>0.4.15</strong> · ukrycie zakładki Inne (automisje) — ostrożność po ostrzeżeniu</p>
<p><strong>0.4.14</strong> · potwierdzenie wpłaty perły — emoji check, mniejszy font, bez drugiego zdania</p>
<p><strong>0.4.13</strong> · podsumowanie nagr&#243;d po automisji — grupowanie i sumowanie</p>
<p><strong>0.4.12</strong> · nagroda w logu misji + emoji zamiast Abort</p>
<p><strong>0.4.11</strong> · fix misji powtarzalnych — osobne żądanie getPlayerResourceBag</p>
<p><strong>0.4.10</strong> · odbi&#243;r nagrody misji-negocjacji + przycisk Następna misja</p>
<p><strong>0.4.9</strong> · zakładka Inne + automisje powtarzalne</p>
<p><strong>0.4.8</strong> · przycisk &#39;Resetuj nazwy&#39; w Zbiorach + info o odświeżeniu perły</p>
<p><strong>0.4.7</strong> · potwierdzenie wpłaty perły znika po chwili + info o widoku gry</p>
<p><strong>0.4.6</strong> · rozpoznawanie nazw budynk&#243;w z zestaw&#243;w wyboru (cityEntityId)</p>
<p><strong>0.4.5</strong> · zbiory miejskie — tooltip emoji bez tekstu, ciaśniejsza lista</p>
<p><strong>0.4.4</strong> · zestawienie budynk&#243;w kwantowych po zbiorach</p>
<p><strong>0.4.3</strong> · zbiory kwantowe — produkcja do prawej, pogrubione godziny i liczebności</p>
<p><strong>0.4.2</strong> · tooltipy budynk&#243;w kwantowych — produkcja z emoji, 1 linia na pozycję</p>
<p><strong>0.4.1</strong> · perły, negocjacje misji, uzycie w polu chwały, testy</p><p><strong>0.3.0</strong> · Pierwsza wersja w historii Git: panel, perły, Pola Chwały i osada kwantowa. Kolejne poprawki tej wersji: solver i zamykanie negocjacji, obsługa brakujących towarów, rezerwa walk tylko w automacie, odblokowanie po invalid wave, sortowanie sektorów, stabilny układ, rozpiska do 100 px, zwijane notatki i komunikaty.</p></div></details>
          <small style="display:block;margin:8px 0;color:#c5ab87">Korzystanie z przycisków ataku, negocjacji i zbiorów może wiązać się z ryzykiem bana konta w grze.</small>
        </section>
      </aside>
    `;

    const $ = id => root.getElementById(id);
    const sectorStatus=document.createElement('p');sectorStatus.id='gbg-sound-status';sectorStatus.setAttribute('role','status');
    $('open-sectors-heading').before(sectorStatus);
    const sectorPopup=document.createElement('div');sectorPopup.id='sector-popup';sectorPopup.hidden=true;
    sectorPopup.innerHTML='<div id="sector-popup-header"><strong id="sector-popup-title">Pola chwały</strong><button id="sector-popup-copy" aria-label="Kopiuj widoczne sektory" data-tooltip="Kopiuj widoczne sektory">📋</button><button id="sector-popup-close" aria-label="Zamknij powiadomienia sektorów">×</button></div><div id="sector-popup-list"></div>';
    root.append(sectorPopup);
    $('sector-popup-copy').onclick=async()=>{
      const button=$('sector-popup-copy'),text=$('sector-popup-list').textContent;
      if(!text)return;
      try{await navigator.clipboard.writeText(text);button.textContent='✓';button.dataset.tooltip='Skopiowano sektory';}
      catch{button.textContent='!';button.dataset.tooltip='Nie udało się skopiować sektorów';}
      setTimeout(()=>{button.textContent='📋';button.dataset.tooltip='Kopiuj widoczne sektory';},1500);
    };
    const negoSection=document.createElement('section');negoSection.id='nego';negoSection.hidden=true;negoSection.setAttribute('role','tabpanel');
    negoSection.innerHTML='<h2>Negocjacje</h2><p id="standalone-kind"></p><button id="standalone-start" disabled>🤝 Negocjuj</button><p id="standalone-status" role="status" style="height:32px;font-size:12px">Otwórz negocjację w grze.</p><div id="standalone-history" style="max-height:300px;overflow:auto;font-size:12px"></div>';
    root.querySelector('aside').append(negoSection);

    // Zakładka Inne — tymczasowo ukryta
    const inneTab=document.createElement('button');inneTab.dataset.page='inne';inneTab.setAttribute('role','tab');inneTab.setAttribute('aria-selected','false');inneTab.title='Inne';inneTab.setAttribute('aria-label','Inne');inneTab.textContent='🧩';
    inneTab.hidden=true;
    root.querySelector('nav').insertBefore(inneTab,root.querySelector('[data-page="settings"]'));
    const inneSection=document.createElement('section');inneSection.id='inne';inneSection.hidden=true;inneSection.setAttribute('role','tabpanel');
    inneSection.innerHTML=`
      <h2>Inne</h2>
      <h3>Misje powtarzalne</h3>
      <div style="font-size:12px;color:#a5b8bc;margin-bottom:8px">
        Wykonuje misje powtarzalne wymagające wpłaty monet lub zaopatrzenia.<br>
        Pomija misje z innymi warunkami. Zatrzymuje się gdy brakuje zasobów.
      </div>
      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:8px">
        <label style="font-size:12px">🪙 min zapas <input id="quest-min-money" type="number" min="0" step="1000" value="50000" style="width:90px;padding:3px 5px;margin-left:4px" aria-label="Minimalny zapas monet"></label>
        <label style="font-size:12px">🔨 min zapas <input id="quest-min-supplies" type="number" min="0" step="1000" value="50000" style="width:90px;padding:3px 5px;margin-left:4px" aria-label="Minimalny zapas zaopatrzenia"></label>
      </div>
      <button id="quest-auto-start">▶ Wykonuj misje</button>
      <button id="quest-auto-stop" disabled>⏹ Zatrzymaj</button>
      <p id="quest-auto-status" role="status" style="font-size:12px;min-height:18px;margin-top:6px"></p>
      <div id="quest-auto-log" style="max-height:200px;overflow:auto;font-size:11px;color:#a5b8bc;margin-top:4px"></div>
      <div id="quest-auto-rewards" style="display:none;margin-top:6px;padding:4px 6px;background:#1a2a2a;border-radius:4px;font-size:11px;color:#c8e0e0"></div>
    `;
    root.querySelector('aside').append(inneSection);

    // Ustawienia automisji z localStorage
    const LS_QUEST_MONEY='foe-companion.questMinMoney',LS_QUEST_SUPPLIES='foe-companion.questMinSupplies';
    const loadQuestSettings=()=>{
      const m=Number(localStorage.getItem(LS_QUEST_MONEY));const s=Number(localStorage.getItem(LS_QUEST_SUPPLIES));
      if(m>=0)$('quest-min-money').value=m;if(s>=0)$('quest-min-supplies').value=s;
    };
    loadQuestSettings();
    $('quest-min-money').onchange=()=>localStorage.setItem(LS_QUEST_MONEY,$('quest-min-money').value);
    $('quest-min-supplies').onchange=()=>localStorage.setItem(LS_QUEST_SUPPLIES,$('quest-min-supplies').value);

    let questAutoRunning=false,questAutoToken=null;
    const questLog=msg=>{const line=document.createElement('div');line.textContent=msg;$('quest-auto-log').append(line);line.scrollIntoView?.({block:'nearest'});};
    const questStatus=msg=>$('quest-auto-status').textContent=msg;
    // Grupowanie nagród wg typu — emoji na podstawie subType/iconAssetName
    const rewardEmoji=key=>{
      if(/money|coin/i.test(key))return'🪙';
      if(/supplies|supply/i.test(key))return'🔨';
      if(/strategy|forgepoint|fp/i.test(key))return'🔵';
      if(/good|wire|lumber|marble|ebony|granite|cloth|dye|iron/i.test(key))return'📦';
      if(/gem|klejnot|diamond/i.test(key))return'💎';
      if(/medal/i.test(key))return'🏅';
      if(/fragment/i.test(key))return'🧩';
      if(/ally|sojuszni/i.test(key))return'⚔️';
      return'🎁';
    };
    const renderQuestRewards=rewards=>{
      const el=$('quest-auto-rewards');
      el.replaceChildren();
      const header=document.createElement('div');
      header.textContent='Zdobyte nagrody:';
      header.style.cssText='font-weight:bold;margin-bottom:4px;color:#8fcfcf';
      el.append(header);
      for(const [key,{name,amount}] of Object.entries(rewards)){
        const row=document.createElement('div');
        const emoji=rewardEmoji(key);
        // Wyodrębnij samą nazwę bez liczby (serwer podaje np. "66 500 Monet")
        const label=name.replace(/^\d[\d\s]*/,'').trim()||key;
        row.textContent=`${emoji} ${amount.toLocaleString('pl-PL')} ${label}`;
        el.append(row);
      }
      el.style.display='block';
    };

    $('quest-auto-start').onclick=()=>{
      if(questAutoRunning)return;
      questAutoRunning=true;questAutoToken='quest-auto-'+Date.now();
      $('quest-auto-start').disabled=true;$('quest-auto-stop').disabled=false;
      $('quest-auto-log').replaceChildren();$('quest-auto-rewards').style.display='none';$('quest-auto-rewards').replaceChildren();questStatus('Uruchamiam…');
      const minMoney=Math.max(0,Number($('quest-min-money').value)||0);
      const minSupplies=Math.max(0,Number($('quest-min-supplies').value)||0);
      window.postMessage({channel:'foe-quest-auto',token:questAutoToken,minMoney,minSupplies},location.origin);
    };
    $('quest-auto-stop').onclick=()=>{
      questAutoRunning=false;questAutoToken=null;
      $('quest-auto-start').disabled=false;$('quest-auto-stop').disabled=true;questStatus('Zatrzymano.');
      window.postMessage({channel:'foe-quest-auto-stop'},location.origin);
    };
    window.addEventListener('message',event=>{
      if(event.source!==window||event.origin!==location.origin)return;
      const d=event.data;
      if(d?.channel==='foe-quest-auto-update'&&d.token===questAutoToken){
        questStatus(d.status||'');
        if(d.log)questLog(d.log);
        if(d.done){
          questAutoRunning=false;questAutoToken=null;$('quest-auto-start').disabled=false;$('quest-auto-stop').disabled=true;
          if(d.rewards&&Object.keys(d.rewards).length)renderQuestRewards(d.rewards);
        }
      }
    });
    const negoOpenKey='foe-companion.autoOpenNego';
    $('auto-open-nego').checked=false;
    $('auto-open-nego').onchange=()=>localStorage.setItem(negoOpenKey,$('auto-open-nego').checked?'1':'0');
    let standaloneToken=null,standaloneGame=null;
    const appendNego=text=>{const line=document.createElement('p');line.textContent=text;$('standalone-history').append(line);line.scrollIntoView?.({block:'nearest'});};
    const feedbackText=slots=>slots.map(s=>`[${(s.slotId??0)+1}] ${s.resourceId} ${s.state==='correct'?'✅':s.state==='wrong_person'?'🟡':'❌'}`).join(' · ');
    $('standalone-start').onclick=()=>{
      if(standaloneToken||!standaloneGame)return;
      standaloneToken='open-nego-'+Date.now();$('standalone-start').disabled=true;$('standalone-history').replaceChildren();$('standalone-status').textContent='Status: odczyt negocjacji…';
      window.postMessage({channel:'foe-open-negotiate',token:standaloneToken,turnDelay:negTurnSettings},location.origin);
    };
    window.addEventListener('message',event=>{
      if(event.source!==window||event.origin!==location.origin)return;
      const d=event.data;
      if(d?.channel==='foe-open-negotiation'){
        return; // Negotiations outside battlegrounds are disabled.
        standaloneGame=d.game;
        if(d.game){
          $('nego-tab').hidden=true;$('standalone-kind').textContent=d.game.context==='quest'?'Misja':`Negocjacja: ${d.game.context}`;
          if(!standaloneToken)$('standalone-status').textContent='Status: ready';
          if(d.detected&&$('auto-open-nego').checked){
            root.querySelector('aside').classList.add('open');
            root.querySelectorAll('[data-page]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.page==='nego')));
            root.querySelectorAll('aside>section').forEach(s=>s.hidden=s.id!=='nego');syncNotes();
          }
        }else if(!standaloneToken)$('standalone-status').textContent=d.reason||'Brak aktywnej negocjacji.';
        $('standalone-start').disabled=!!standaloneToken||!standaloneGame;
      }
      if(!standaloneToken||d?.token!==standaloneToken)return;
      if(d.channel==='foe-open-nego-started'){
        appendNego('Towary: '+d.goods.join(', '));
        d.history.forEach((t,i)=>appendNego(`Tura ${i+1}: ${feedbackText(t.slots||[])}`));
      }
      if(d.channel==='foe-open-nego-turn'){$('standalone-status').textContent=`Status: ${d.turn} tura`;appendNego(`Tura ${d.turn}: ${d.guess.join(' · ')}`);}
      if(d.channel==='foe-open-nego-feedback')appendNego(feedbackText(d.feedback));
      if(d.channel==='foe-open-nego-result'){
        standaloneToken=null;$('standalone-status').textContent=d.message;
        // Jeśli misja-negocjacja zakończona z kolejną misją — pokaż przycisk NEXT
        const existingNext=$('standalone-next');if(existingNext)existingNext.remove();
        if(d.won&&d.nextQuest){
          const nextBtn=document.createElement('button');nextBtn.id='standalone-next';nextBtn.textContent='▶ Następna misja: '+d.nextQuest.title;
          nextBtn.style.cssText='margin-top:6px;font-size:12px';
          nextBtn.onclick=()=>{
            nextBtn.disabled=true;nextBtn.textContent='Uruchamiam…';
            const t='quest-next-'+Date.now();
            window.postMessage({channel:'foe-quest-next',token:t,quest:d.nextQuest},location.origin);
            const handler=ev=>{
              if(ev.source!==window||ev.origin!==location.origin||ev.data?.channel!=='foe-quest-next-result'||ev.data.token!==t)return;
              window.removeEventListener('message',handler);
              nextBtn.remove();
              $('standalone-status').textContent=ev.data.message;
              if(ev.data.ok){standaloneGame=ev.data.game;$('standalone-start').disabled=false;}
            };
            window.addEventListener('message',handler);
          };
          $('standalone-history').after(nextBtn);
        }
        $('standalone-start').disabled=!!standaloneToken||!standaloneGame;
      }
    });
    window.postMessage({channel:'foe-open-negotiation-query'},location.origin);
    const soundKey='foe-companion.gbgSound';
    let soundSettings={enabled:false,minutes:2,kind:'classic'},audioContext=null,alertBusy=false;
    try{const saved=JSON.parse(localStorage.getItem(soundKey)||'null');if(saved)soundSettings={enabled:saved.enabled===true,minutes:Number.isInteger(saved.minutes)&&saved.minutes>=1&&saved.minutes<=60?saved.minutes:2};}catch{}
    $('gbg-sound-enabled').checked=soundSettings.enabled;
    $('gbg-sound-minutes').value=soundSettings.minutes;
    const signals={classic:[[784,0,.2],[1047,.23,.2],[784,.46,.2]],ding:[[880,0,.35],[660,.37,.4]],single:[[880,0,.3]],melody:[[523,0,.18],[659,.2,.18],[784,.4,.18],[1047,.6,.3]],alarm:[[1000,0,.12],[700,.15,.12],[1000,.3,.12],[700,.45,.12]]};
    try{const saved=JSON.parse(localStorage.getItem(soundKey)||'{}');soundSettings.kind=Object.hasOwn(signals,saved.kind)?saved.kind:'classic';}catch{soundSettings.kind='classic';}
    $('gbg-sound-kind').value=soundSettings.kind;
    $('gbg-sound-kind').onchange=()=>{soundSettings.kind=$('gbg-sound-kind').value;localStorage.setItem(soundKey,JSON.stringify(soundSettings));};
    let sounded={};
    try{sounded=JSON.parse(sessionStorage.getItem(soundKey+'.sent')||'{}')||{};}catch{}
    const popupKey='foe-companion.sectorPopup';
    const popupEntries=new Map(),popupCycles=new Map();let popupDismissed={};
    try{popupDismissed=JSON.parse(sessionStorage.getItem(popupKey+'.dismissed.v2')||'{}')||{};}catch{}
    try{for(const [key,value] of JSON.parse(sessionStorage.getItem(popupKey+'.cycles')||'[]'))popupCycles.set(key,value);}catch{}
    function savePopupDismissed(){try{sessionStorage.setItem(popupKey+'.dismissed.v2',JSON.stringify(popupDismissed));sessionStorage.setItem(popupKey+'.cycles',JSON.stringify([...popupCycles]));}catch{}}
    $('sector-popup-close').onclick=()=>{
      const until=Date.now()/1000+3600;
      for(const key of popupEntries.keys())popupDismissed[key]=until;
      popupEntries.clear();savePopupDismissed();paintSectorPopup();
    };
    function sectorPopupText(entry,now,countdown){
      const seconds=Math.max(0,Math.ceil(entry.until-now));
      const time=[Math.floor(seconds/3600),Math.floor(seconds/60)%60,seconds%60].map(n=>String(n).padStart(2,'0')).join(':');
      const type=entry.isAttackBattleType===true?'🟥 ':entry.isAttackBattleType===false?'🟦 ':'';
      const progress=FoeModel.displaySettings.ownProgress&&seconds===0&&entry.progress>0?' '+entry.progress+'/'+(entry.maxProgress??'—'):'';
      const marker=FoeModel.displaySettings.enemyProgress&&seconds===0&&entry.enemyProgress>0?' 👾'+entry.enemyProgress:entry.race?' 🔥':'';
      return (entry.guardAlarm?'🔔 ':'')+(seconds===0?'Otwarte ':countdown?time+' ':'')+type+FoeModel.guildColor(entry)+entry.sector+progress+marker;
    }
    function paintSectorPopup(){
      const now=Date.now()/1000;
      for(const [key,entry] of popupEntries){
        if((!soundSettings.enabled&&!entry.guardAlarm)||entry.mapId!==battle?.map?.id)popupEntries.delete(key);
      }
      for(const [key,expiry] of Object.entries(popupDismissed))if(expiry<=now)delete popupDismissed[key];
      savePopupDismissed();
      const lines=[...popupEntries.values()].sort((a,b)=>Number(!!b.guardAlarm)-Number(!!a.guardAlarm)||a.until-b.until).slice(0,10).map(entry=>sectorPopupText(entry,now,true));
      const text=lines.join('\n');if($('sector-popup-list').textContent!==text)$('sector-popup-list').textContent=text;
      sectorPopup.hidden=!lines.length;
      // Anchor to the actual handle width, also when the panel is expanded.
      sectorPopup.style.right=($('handle').getBoundingClientRect().width+8)+'px';
      if(lines.length)sectorStatus.textContent='🔔 '+text.replaceAll('\n',' · ');
      else if(sectorStatus.textContent.startsWith('🔔'))sectorStatus.textContent='';
    }
    function eligibleOpenSector(r,now){
      return r.until<=now&&Number.isFinite(r.maxProgress)&&r.maxProgress>0&&Number.isFinite(r.progress)&&r.progress<r.maxProgress/2&&Number.isFinite(r.gainAttritionChance)&&r.gainAttritionChance<30;
    }
    function updateSectorPopup(rows,now){
      for(const [key,expiry] of Object.entries(popupDismissed))if(expiry<=now)delete popupDismissed[key];
      const present=new Set(rows.map(r=>battle.map.id+':'+r.id));
      for(const key of popupEntries.keys())if(!present.has(key))popupEntries.delete(key);
      for(const r of rows){
        const key=battle.map.id+':'+r.id,cycle=popupCycles.get(key),lock=r.until||0;
        if(cycle&&(cycle.season!==battle.endsAt||cycle.owner!==r.ownerId||(lock>0&&lock!==cycle.lock))){popupEntries.delete(key);delete popupDismissed[key];}
        popupCycles.set(key,{season:battle.endsAt,owner:r.ownerId,lock:lock||cycle?.lock||0});
        const guardAlarm=r.color!=='⚪'&&r.until<=now&&r.enemyProgress>0&&getGuard(battle.map.id,r.id).guard;
        const closed=r.until>now,own=r.color==='⚪';
        const near=closed&&r.until-now<=soundSettings.minutes*60;
        const high=Number.isFinite(r.maxProgress)&&r.maxProgress>0&&r.progress/r.maxProgress>0.99;
        const retained=popupEntries.get(key)?.regular&&!closed&&!own&&!high;
        const eligible=soundSettings.enabled&&!own&&(near||(!closed&&!high&&(eligibleOpenSector(r,now)||retained)));
        if(!popupDismissed[key]&&(eligible||guardAlarm))popupEntries.set(key,{...r,mapId:battle.map.id,guardAlarm,regular:eligible});
        else popupEntries.delete(key);
      }
      paintSectorPopup();
    }
    async function unlockAudio(){
      audioContext ||= new AudioContext();
      if(audioContext.state==='suspended')await audioContext.resume();
      return audioContext.state==='running';
    }
    function playAlert(){
      if(audioContext?.state!=='running')return false;
      for(const [frequency,offset,duration] of signals[soundSettings.kind]||signals.classic){
        const osc=audioContext.createOscillator(),gain=audioContext.createGain(),at=audioContext.currentTime+offset;
        osc.frequency.value=frequency;gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(.14,at+.015);gain.gain.exponentialRampToValueAtTime(.001,at+duration-.02);
        osc.connect(gain);gain.connect(audioContext.destination);osc.start(at);osc.stop(at+duration);
      }
      return true;
    }
    function checkSectorAlerts(){
      paintSectorPopup();
      if(!battle)return;
      const now=Date.now()/1000;
      const rows=FoeModel.rows(battle,$('frontier').checked).rows;
      const guarded=FoeModel.rows(battle,false).rows.filter(r=>getGuard(battle.map.id,r.id).guard);
      updateSectorPopup([...new Map([...rows,...guarded].map(r=>[r.id,r])).values()],now);
      // --- Logika pilnowania sektorow ---
      const guards=loadGuards();
      for(const row of rows){
        if(row.until>now||row.color==='⚪'){cancelCloseAtHour(row.id);continue;}
        const key=battle.map.id+':'+row.id;
        const guard=guards[key];if(!guard)continue;
        if(guard.closeAtHour){if(!closeAtHourTimers.has(row.id))scheduleCloseAtHour(row.id);}
        else{cancelCloseAtHour(row.id);}
        if(guard.guard||guard.closeWhenThreatened){
          const province=battle.map.provinces.find(p=>(p.id??0)===row.id);
          const own=battle.currentParticipantId;
          const enemyEntries=(province?.conquestProgress||[]).filter(c=>c.participantId!==own);
          const maxEnemy=enemyEntries.reduce((m,c)=>Math.max(m,c.progress??0),0);
          const prevEnemy=enemyProgressPrev.get(key)??0;
          enemyProgressPrev.set(key,maxEnemy);
          if(guard.guard&&maxEnemy>0&&(prevEnemy===0||!guardAlerted.get(key))){
            guardAlerted.set(key,true);
            setBattleFeedback('Sektor '+row.sector+' atakowany! 👾 '+maxEnemy+'/'+(row.enemyMaxProgress??row.maxProgress??'—'));
            if(soundSettings.enabled)playAlert();
          }
          if(maxEnemy===0)guardAlerted.delete(key);
          if(guard.closeWhenThreatened&&row.maxProgress&&maxEnemy/row.maxProgress*100>bulkSettings.closeEnemyProgress){
            if(autoSector===null&&autoNegSector===null&&!battlePending&&!negPending&&!bulkAutomation?.engaged&&!bulkAutomation?.guardsPaused){
              setBattleFeedback('Zamykam sektor '+row.sector+' — wrog osiagnal '+Math.round(maxEnemy/row.maxProgress*100)+'%!');
              startGuardClosing(row.id);
            }
          }
        }
      }
      for(const [sid] of closeAtHourTimers){if(!rows.find(r=>r.id===sid&&r.until<=now))cancelCloseAtHour(sid);}
      if(!soundSettings.enabled)return;
      const upcoming=rows.filter(r=>r.until>now&&r.until-now<=soundSettings.minutes*60);
      if(alertBusy)return;
      const due=upcoming.filter(r=>r.color!=='⚪'&&!popupDismissed[battle.map.id+':'+r.id]&&!sounded[`${battle.map.id}:${r.id}:${r.until}`]);
      if(!due.length)return;
      if(!playAlert()){$('gbg-sound-status').textContent='Kliknij Test dzwieku, aby aktywowac dzwiek w tej karcie.';return;}
      alertBusy=true;
      for(const [key,until] of Object.entries(sounded))if(until<=now)delete sounded[key];
      for(const r of due)sounded[`${battle.map.id}:${r.id}:${r.until}`]=r.until;
      try{sessionStorage.setItem(soundKey+'.sent',JSON.stringify(sounded));}catch{}
      if(popupEntries.size)paintSectorPopup();
      setTimeout(()=>alertBusy=false,800);
    }
    $('gbg-sound-enabled').onchange=async()=>{
      soundSettings.enabled=$('gbg-sound-enabled').checked;localStorage.setItem(soundKey,JSON.stringify(soundSettings));
      if(soundSettings.enabled){try{await unlockAudio();checkSectorAlerts();}catch{$('gbg-sound-status').textContent='Nie udało się uruchomić dźwięku.';}}
      else {paintSectorPopup();$('gbg-sound-status').textContent='Alerty wyłączone.';}
    };
    $('gbg-sound-minutes').onchange=()=>{
      const value=Number($('gbg-sound-minutes').value);
      if(!Number.isInteger(value)||value<1||value>60){$('gbg-sound-minutes').value=soundSettings.minutes;return;}
      soundSettings.minutes=value;localStorage.setItem(soundKey,JSON.stringify(soundSettings));checkSectorAlerts();
    };
    $('gbg-sound-test').onclick=async()=>{try{await unlockAudio();$('gbg-sound-status').textContent=playAlert()?'Odtworzono dźwięk testowy.':'Dźwięk zablokowany przez przeglądarkę.';}catch{$('gbg-sound-status').textContent='Nie udało się uruchomić dźwięku.';}};
    document.addEventListener('pointerdown',()=>{if(soundSettings.enabled)unlockAudio().catch(()=>{});},{capture:true});
    setInterval(checkSectorAlerts,1000);
    document.addEventListener('visibilitychange',checkSectorAlerts);
    // Extend the existing UI without replacing user styling and settings.
    const style=document.createElement('style');
    style.textContent=`aside{display:flex;flex-direction:column;overflow:hidden}header,nav{flex-shrink:0}aside>section{flex:1;min-height:0;overflow:auto}#notes-dock{flex-shrink:0;max-height:300px;overflow:hidden;border-top:1px solid #345058;padding-top:8px;margin-top:10px;display:flex;flex-direction:column}#notes-dock label{margin:0 0 4px}#notes-text{font:13px/1.5 system-ui;box-sizing:border-box;width:100%;height:140px;min-height:60px;max-height:250px;resize:vertical;background:#0b191e;color:#e7eeee;border:1px solid #45616a;border-radius:7px;padding:8px}#notes-status{font-size:11px;min-height:16px;color:#90a5ad}.quantum-group{border-top:1px solid #345058;padding:10px 0}.quantum-resources{font-size:16px;color:#f1d69a}`;
    style.textContent+=`
      *{scrollbar-width:thin;scrollbar-color:#45616a transparent}
      *::-webkit-scrollbar{width:4px;height:4px}
      *::-webkit-scrollbar-thumb{background:#45616a;border-radius:4px}
      *::-webkit-scrollbar-track{background:transparent}
      aside>section,#list,#open-sectors,#neg-panel,#battle-feedback{scrollbar-gutter:stable;overflow-anchor:none}
      #gbg-controls{position:sticky;top:0;z-index:2;background:#102127;padding:4px 0}
      #gbg-stop-controls{display:grid;grid-template-columns:1fr 1fr;gap:6px;height:38px;align-items:stretch}
      #gbg-stop-controls button{margin:0;padding:4px;font-size:11px;min-width:0}
      #gbg-stop-controls button[hidden]{display:block!important;visibility:hidden;pointer-events:none}
      #neg-status{height:18px;line-height:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #neg-status::before{content:'Status: ';font-weight:bold}
      #list{user-select:text!important;-webkit-user-select:text!important;cursor:text;max-height:100px;box-sizing:border-box;overflow-y:auto}
      #open-sectors{overflow-y:auto;overflow-x:hidden}
      #neg-panel{height:160px;box-sizing:border-box;overflow-y:scroll;overflow-x:hidden;overflow-wrap:anywhere}
      #neg-panel:empty{overflow:hidden}
      #battle-feedback{height:18px;min-height:18px;line-height:18px;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;scrollbar-gutter:auto;margin:2px 0;overflow-wrap:normal}
    `;
    style.textContent+=`
      #gbg-title{display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:6px}
      #gbg-title h2{margin:0;font-size:16px;white-space:nowrap}
      #gbg-title td{padding:0 5px}
      #gb button,#gb button:hover{background:transparent;border:0;box-shadow:none}
      #gbg h3{font-size:13px;margin:6px 0}
      #gbg-controls{display:grid;grid-template-columns:1fr;align-items:center;gap:2px;padding:2px 0}
      #neg-status{grid-column:1/-1;text-align:left}
      #gbg-stop-controls{height:28px;gap:4px}
      #gbg-stop-controls button{font-size:10px;padding:2px}
      #open-sectors{font-size:11px}
      #open-sectors>div{padding:2px 0!important;gap:3px!important;min-height:22px;white-space:nowrap}
      #open-sectors button{position:relative;flex-shrink:0;font-size:11px!important;line-height:18px!important;width:19px;height:20px;padding:0!important;margin:0;background:transparent!important;border:0!important;box-shadow:none}
      #open-sectors button.action-start{margin-left:7px}
      #open-sectors button.action-start::before{content:'|';position:absolute;left:-6px;color:#56737b;font-weight:normal;pointer-events:none}
      #schedule-heading{display:flex;align-items:center;justify-content:space-between;gap:6px;margin-top:6px}
      #schedule-heading label{font-size:11px;white-space:nowrap;margin:0;display:flex;align-items:center;gap:4px}
      #schedule-heading input{margin:0}
      #list{margin:4px 0;padding:6px;font-size:11px;max-height:100px}
      #copy{font-size:11px;padding:4px 8px}
      #gbg:not([hidden]){display:flex;flex-direction:column;overflow-y:auto;overflow-x:hidden}
      #gbg> *{flex-shrink:0;box-sizing:border-box}
      #gbg-title{height:26px}
      #open-sectors-heading{height:28px}
      #gbg-controls{position:static;height:auto;min-height:32px}
      #gbg #open-sectors{flex:1 0 80px;min-height:80px;height:auto}
      #schedule-heading{height:28px}
      #gbg #list{height:100px;min-height:100px;max-height:100px;flex:none}
      #gbg #notice,#gbg #feedback{display:block;height:16px;line-height:16px;margin:0;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #gbg #copy{height:28px;align-self:flex-start}
      #notes-dock{display:block;margin-top:4px;padding-top:4px;max-height:300px}
      #notes-dock summary{cursor:pointer;line-height:24px;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #notes-dock:not([open]) #notes-text,#notes-dock:not([open]) #notes-status{display:none}
    `;
    style.textContent+=`
      aside input:not([type=checkbox]),aside select{background:#0b191e;color:#e9f1f2;border:1px solid #345058;border-radius:3px}
      #settings{font-size:12px}#settings h2{font-size:15px;margin:8px 0}#settings h3{font-size:13px;margin:12px 0 6px}
      #settings label{margin:4px 0}.settings-open{display:grid;grid-template-columns:1fr 1fr;gap:2px 8px}
      .settings-alert{display:flex;align-items:center;gap:5px;white-space:nowrap}.settings-alert label{display:flex;align-items:center}
      .settings-alert select{min-width:0;flex:1;width:100px}.settings-alert input[type=number]{width:42px}.settings-alert button{padding:2px 5px}
      #settings details{border-top:1px solid #345058;margin-top:10px;padding-top:8px}#settings summary{cursor:pointer;font-weight:bold}
      #settings #gbg-sound-status{font-size:10px}#nego-tab{display:none!important}
      #settings details{border:0;padding:0;margin:8px 0}
      #settings summary{background:#243d45;color:#f1d69a;padding:6px 8px;line-height:1.4}
      #settings details details{margin:6px 0 6px 8px}
      #settings details details>summary{background:#182e35;color:#dce8ec;font-size:12px}
      #settings label{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:7px 0}
      #settings label>input{margin-left:auto!important;order:1}
      #settings input:not([type=checkbox]){width:65px!important;max-width:100%;padding:4px!important;text-align:right}
      #settings .settings-range{display:flex;align-items:center;gap:4px;margin-left:auto}
      #settings .settings-open{display:block}
      #settings .settings-alert{margin:8px 0;justify-content:flex-end;gap:4px}
      #settings .settings-alert label{margin-right:auto;gap:4px}
      #settings .settings-alert input[type=number]{width:38px!important}
      #settings .settings-alert select{flex:0 1 135px;width:135px;margin-left:auto}
      #settings input:not([type=checkbox]),#settings select,#settings #gbg-sound-test{height:28px;min-height:28px;box-sizing:border-box;font:inherit;line-height:18px;padding:4px!important;vertical-align:middle}
      [hidden]{display:none!important}
      input[type=checkbox]{appearance:none;width:13px;height:13px;min-width:13px;box-sizing:border-box;margin:0;border:1px solid #3a5057;border-radius:1px;background:#0b191e;color:#b4c5c7;display:inline-grid;place-content:center;vertical-align:middle;cursor:pointer}
      input[type=checkbox]::before{content:"✓";font:600 10px/1 system-ui;transform:scale(0);transition:transform 80ms ease-in-out}
      input[type=checkbox]:checked{background:#294349;border-color:#59747a}
      input[type=checkbox]:checked::before{transform:scale(1)}
      input[type=checkbox]:indeterminate{background:#294349;border-color:#59747a}
      input[type=checkbox]:indeterminate::before{content:"−";transform:scale(1)}
      input:focus,select:focus,textarea:focus,button:focus,[contenteditable]:focus{outline:none;box-shadow:none}
      input:focus-visible,select:focus-visible,textarea:focus-visible,button:focus-visible,[contenteditable]:focus-visible{border-color:#74878a}
      input[type=checkbox]:disabled{opacity:.5;cursor:default}
      button[role=checkbox]{border:1px solid #45616a;border-radius:3px;background:#0b191e;color:#e7eeee;padding:2px 5px}
      button[role=checkbox][aria-checked=true],button[role=checkbox][aria-checked=mixed]{background:#294349;border-color:#59747a}
      #gbg-sound-status{font-size:10px;line-height:16px;height:16px;min-height:16px;margin:2px 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      #sector-popup{position:absolute;bottom:10%;max-width:calc(100vw - 100px);max-height:50vh;overflow:auto;background:#102126;color:#e7eeee;padding:7px 26px 7px 9px;border-radius:0;box-shadow:0 2px 10px #0008;pointer-events:auto;font:12px/1.5 system-ui;z-index:2}
      #sector-popup[hidden]{display:none!important}
      #sector-popup-list{white-space:pre-line;font-variant-numeric:tabular-nums}
      #sector-popup{padding:7px 9px}
      #sector-popup-header{display:flex;align-items:center;gap:7px;margin-bottom:4px}
      #sector-popup-title{display:block;color:#f1d69a;font-size:12px;margin-right:auto}
      #sector-popup-copy,#sector-popup-close{border:0;background:transparent;padding:0 2px;line-height:18px}
      #sector-popup-copy{font-size:12px}#sector-popup-close{font-size:16px}
      #quantum{padding-right:14px;box-sizing:border-box;scrollbar-gutter:stable}.quantum-group{padding:5px 0;font-size:11px}.quantum-group summary{cursor:pointer;white-space:nowrap}
      #rich-tooltip{position:fixed;z-index:2147483647;max-width:min(320px,calc(100vw - 20px));white-space:pre-wrap;overflow-wrap:anywhere;background:#07171c;color:#e9f1f2;border:1px solid #45616a;border-radius:5px;padding:8px;font-size:12px;line-height:1.45;pointer-events:none;box-shadow:0 3px 14px #0008}
      #rich-tooltip strong{color:#ffd66b}
      #rich-tooltip[hidden]{display:none!important}
      #rich-tooltip{pointer-events:none!important}
      #city{padding-bottom:100px;box-sizing:border-box}
    `;
    root.append(style);
    const tip=document.createElement('div');tip.id='rich-tooltip';tip.setAttribute('role','tooltip');tip.hidden=true;root.append(tip);
    const convertTitles=node=>{
      const elements=[...(node.nodeType===1?[node]:[]),...(node.querySelectorAll?.('[title]')||[])];
      for(const el of elements)if(el.hasAttribute('title')){el.dataset.tooltip=el.getAttribute('title');el.removeAttribute('title');}
    };
    convertTitles(root);
    new MutationObserver(records=>{for(const r of records){if(r.type==='attributes')convertTitles(r.target);else for(const node of r.addedNodes)convertTitles(node);}}).observe(root,{subtree:true,childList:true,attributes:true,attributeFilter:['title']});
    const hideTip=()=>{tip.hidden=true;tip.replaceChildren();};
    function showTip(event){
      if(event.target.closest?.('#reset-building-names')){hideTip();return;}
      const el=event.target.closest?.('[data-tooltip]');if(!el||!el.dataset.tooltip){hideTip();return;}
      tip.replaceChildren();
      for(const part of el.dataset.tooltip.split(/(\d[\d\s.,]* lin)/u)){
        if(/^\d[\d\s.,]* lin$/u.test(part)){const strong=document.createElement('strong');strong.textContent=part;tip.append(strong);}else tip.append(document.createTextNode(part));
      }
      tip.hidden=false;const rect=el.getBoundingClientRect();
      tip.style.left=Math.max(8,Math.min(rect.left,innerWidth-tip.offsetWidth-8))+'px';
      tip.style.top=Math.max(8,Math.min(rect.bottom+5,innerHeight-tip.offsetHeight-8))+'px';
    }
    root.addEventListener('pointerover',showTip);root.addEventListener('focusin',showTip);
    root.addEventListener('pointerout',hideTip);root.addEventListener('focusout',hideTip);root.addEventListener('scroll',hideTip,true);
    root.addEventListener('pointerdown',hideTip,true);
    root.addEventListener('pointermove',event=>{if(event.target.closest?.('#reset-building-names'))hideTip();});
    root.addEventListener('keydown',event=>{if(event.key==='Escape')hideTip();});
    const qtab=document.createElement('button');qtab.dataset.page='quantum';qtab.setAttribute('role','tab');qtab.setAttribute('aria-selected','false');qtab.title='Najazdy kwantowe';qtab.setAttribute('aria-label','Najazdy kwantowe');qtab.textContent='⚛️';
    root.querySelector('nav').insertBefore(qtab,root.querySelector('[data-page="settings"]'));
    const quantumSection=document.createElement('section');quantumSection.id='quantum';quantumSection.hidden=true;quantumSection.setAttribute('role','tabpanel');
    quantumSection.innerHTML='<h2>Najazdy kwantowe</h2><div id="quantum-summary"></div><div id="quantum-groups"></div><div id="quantum-army"></div><button id="quantum-history" style="margin-top:12px">Historia zbiorów</button>';
    $('settings').before(quantumSection);
    const LS_QUANTUM='foe-companion.quantum.';
    const qGet=key=>{try{return localStorage.getItem(LS_QUANTUM+key)==='1';}catch{return false;}};
    const qSet=(key,val)=>{try{localStorage.setItem(LS_QUANTUM+key,val?'1':'0');}catch{}};
    const applyQuantumSettings=()=>{
      $('quantum-history').hidden=!qGet('showHistory');
    };
    FoeQuantumHistory.mount({root,button:$('quantum-history'),history:quantumHistory,getWidth:()=>$('quantum-summary').getBoundingClientRect().width,getSnapshot:()=>quantumTracker.map?{map:quantumTracker.map,summary:quantumTracker.summary()}:null,getSettings:()=>({showSnapshot:qGet('showSnapshot'),showActions:qGet('showActions')}),getPlayerId:()=>ownPlayerId});
    for(const [key,id] of [['showHistory','quantum-show-history'],['showSnapshot','quantum-show-snapshot'],['showActions','quantum-show-actions']]){
      const cb=$(id);if(!cb)continue;
      cb.checked=qGet(key);
      cb.onchange=()=>{qSet(key,cb.checked);applyQuantumSettings();};
    }
    $('quantum-clear-history').onclick=async()=>{
      if(!confirm('Czy na pewno wyczyścić cały dziennik zbiorów Najazdów kwantowych? Tej operacji nie można cofnąć.'))return;
      await quantumHistory.clear(ownPlayerId);
      $('quantum-clear-history-status').textContent=quantumHistory.error||'Dziennik zbiorów został wyczyszczony.';
    };
    applyQuantumSettings();
    const title=document.createElement('h3');title.id='pearl-name';$('pearl-status').before(title);
    const totalLabel=document.createElement('label');totalLabel.innerHTML='Total PR <input id="pearl-total" type="number" min="0" step="1" placeholder="Koszt poziomu" style="width:130px;padding:6px">';
    $('pearl-status').before(totalLabel);
    const pearlTotals=new Map();let totalTarget=null;
    $('pearl-total').addEventListener('input',()=>{pearlTotals.set(totalTarget,$('pearl-total').value);paintPearl();});
    const dock=document.createElement('details');dock.id='notes-dock';dock.innerHTML='<summary>Notatki <small id="notes-context"></small></summary><textarea id="notes-text" placeholder="Twoje notatki…"></textarea><div id="notes-status" role="status"></div>';
    root.querySelector('aside').append(dock);
    const notes=FoeNotes.createStore(localStorage);let noteKey=null,noteSection=null,notePearl=null;
    function pearlType(){
      if(construction?.cityentity_id)return construction.cityentity_id;
      const ids=new Set((construction?.rankings||[]).flatMap(r=>(r.reward?.blueprintRewards||[]).map(b=>b.building_id)).filter(Boolean));
      return ids.size===1?[...ids][0]:null;
    }
    syncNotes=()=>{
      const active=[...root.querySelectorAll('aside>section')].find(s=>!s.hidden)?.id||'gb';
      const section=active==='gb'?'pearl':active==='quantum'?'najazdy':active;
      const pearl=section==='pearl'?pearlType():null,key=section+':'+(pearl||'');
      $('notes-context').textContent=section==='pearl'?(pearl?FoeModel.buildingLabel(pearl):'— otwórz perłę'):'';
      if(key===noteKey)return;
      noteKey=key;noteSection=section;notePearl=pearl;
      $('notes-text').disabled=section==='pearl'&&!pearl;
      $('notes-text').value=$('notes-text').disabled?'':notes.get(section,pearl);$('notes-status').textContent='';
    };
    $('notes-text').addEventListener('input',()=>{
      try{notes.set(noteSection,notePearl,$('notes-text').value);$('notes-status').textContent='Zapisano';}
      catch{$('notes-status').textContent='Nie udało się zapisać — skopiuj notatkę przed zamknięciem.';}
    });
    new MutationObserver(syncNotes).observe(root.querySelector('aside'),{subtree:true,attributes:true,attributeFilter:['hidden']});
    window.addEventListener('storage',e=>{if(e.key===FoeNotes.KEY && root.activeElement!==$('notes-text')){noteKey=null;syncNotes();}});
    const formatResources=r=>`🪙 ${r.guild_raids_money.toLocaleString('pl-PL')}   🔨 ${r.guild_raids_supplies.toLocaleString('pl-PL')}   🔩 ${r.guild_raids_chrono_alloy.toLocaleString('pl-PL')}`;
    const formatTime=t=>new Date(t*1000).toLocaleString('pl-PL',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
    paintQuantum=()=>{
      // Nie rerenderuj jeśli dane się nie zmieniły
      const curVer=quantumTracker.consume({});
      if(paintQuantum._lastVer===curVer){
        // Tylko aktualizuj etykiety "Gotowe" bez niszczenia DOM
        const now=Date.now()/1000;
        $('quantum-groups').querySelectorAll('[data-groupat]').forEach(el=>{
          const at=Number(el.dataset.groupat);
          if(at&&at<=now&&!el.dataset.ready){el.dataset.ready='1';const s=el.querySelector('strong');if(s)s.textContent=(el.dataset.collapsed==='1'?'▸ ':'▾ ')+'Gotowe';}
        });
        return;
      }
      paintQuantum._lastVer=curVer;
      // Zachowaj stan zwinięcia przed rerenderem
      if(!paintQuantum._collapsed)paintQuantum._collapsed=new Map();
      $('quantum-groups').querySelectorAll('[data-groupat]').forEach(el=>{
        paintQuantum._collapsed.set(el.dataset.groupat, el.dataset.collapsed!=='0');
      });
      const summary=quantumTracker.summary();$('quantum-summary').replaceChildren();$('quantum-groups').replaceChildren();
      const text=(parent,value,tag='p',className='')=>{const node=document.createElement(tag);node.textContent=value;node.className=className;parent.append(node);return node;};
      // Quantum army is available even before opening the settlement.
      const armyBox=$('quantum-army');armyBox.replaceChildren();
      armyBox.style.cssText='border-top:1px solid #345058;margin-top:12px;padding-top:8px;font-size:12px';
      text(armyBox,'⚔️ Wojsko','h3');
      const army=quantumTracker.army;
      if(!army)text(armyBox,'Otwórz armię w grze');
      else for(const row of army.rows)text(armyBox,row.total+'× '+row.name,'div');
      if(!summary){text($('quantum-summary'),'Otwórz osadę kwantową w grze.');return;}

      const heading=$('quantum').querySelector('h2');heading.replaceChildren(document.createTextNode('Najazdy kwantowe'));
      heading.style.cssText='display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:4px;margin-bottom:8px';
      const meta=text(heading,'👑 '+(summary.raid?.difficulty??'—')+' · ⌛ '+(summary.raid?.endsAt?formatTime(summary.raid.endsAt):'—'),'small');meta.style.cssText='font-size:12px;color:#ffd700';
      const box=$('quantum-summary');box.style.cssText='font-size:13px;line-height:1.4;color:#f0e6d2;margin-bottom:12px';
      const stocks=text(box,'','div');stocks.style.cssText='display:flex;flex-wrap:wrap;gap:10px;font-weight:bold;border-bottom:1px solid #4a3525;padding-bottom:6px;margin-bottom:8px';
      const num=n=>Number.isFinite(n)?n.toLocaleString('pl-PL'):'—';
      for(const [key,icon] of [['guild_raids_money','🪙'],['guild_raids_supplies','🔨'],['guild_raids_chrono_alloy','🔩'],['guild_raids_rope','➰']]){
        const node=text(stocks,icon+' '+num(summary.wallet[key]),'span');
        if(key==='guild_raids_rope')node.title=summary.ropeCapacity===null?'Brak danych do obliczenia produkcji lin.':'Z obecnych zapasów można wyprodukować maksymalnie '+num(summary.ropeCapacity)+' lin, łącząc dostępne paczki. Kalkulacja kosztów, bez kosztu budowy wytwórni.';
      }
      const mood=text(stocks,'✨ '+(summary.currentBonuses.euphoria?'150%':summary.currentBonuses.unhappy?'niska':'100%'),'span');mood.style.color=summary.currentBonuses.euphoria?'#4caf50':'#dfd1b8';
      const hourly=text(box,'🪙 +'+summary.bonuses.coins+'% / 🔨 +'+summary.bonuses.supplies+'% · ⚡ '+num(summary.actionsPerHour)+'/h · ⚔️ '+(summary.actionsPerHour/3500).toLocaleString('pl-PL',{maximumFractionDigits:2})+'/h','div');hourly.style.cssText='text-align:center;font-size:12px;color:#a99885;margin-bottom:8px';
      const table=document.createElement('table');table.style.cssText='background:#0b191e;border-radius:5px;width:100%;border-collapse:collapse;font-size:12px;margin-bottom:8px';box.append(table);
      const tr=document.createElement('tr');table.append(tr);text(tr,'Następny zbiór:','th');
      const next=summary.totals;
      for(const [key,icon] of [['guild_raids_money','🪙'],['guild_raids_supplies','🔨'],['guild_raids_chrono_alloy','🔩']]){const cell=text(tr,icon+' '+num(next?.[key]),'td');cell.style.cssText='padding:6px 4px;border-left:1px solid #4a3525;text-align:center;font-weight:bold';}

      if(summary.missing.length)text(box,'Niepełne dane: brakuje definicji '+summary.missing.length+' budynków.');
      if(summary.bonuses.unhappy)text(box,'Prognoza nie uwzględnia kary za niezadowolenie.');
      const clockTime=(at,seconds=true)=>new Intl.DateTimeFormat('pl-PL',{timeZone:'Europe/Warsaw',hour:'2-digit',minute:'2-digit',...(seconds?{second:'2-digit'}:{})}).format(at*1000);
      const addSection=(label,first=false)=>{
        if(!first){const hr=document.createElement('hr');hr.style.cssText='border:none;border-top:1px solid #2e4450;margin:10px 0 6px';$('quantum-groups').append(hr);}
        const h=document.createElement('strong');h.textContent=label;h.style.cssText='display:block;font-size:12px;color:#8fcfcf;margin-bottom:4px';$('quantum-groups').append(h);
      };
      // Shared resource widths keep every collection group and overview aligned.
      const resourceValues=[summary.totals,...summary.groups.map(g=>g.production),...summary.groups.flatMap(g=>g.items.map(i=>i.production))];
      resourceValues.push(Object.fromEntries(FoeQuantum.KEYS.map(k=>[k,(summary.totals[k]||0)+summary.builds.reduce((sum,b)=>sum+(b.production?.[k]||0),0)])));
      const resourceColumns='minmax(0,1fr) '+FoeQuantum.KEYS.map(k=>Math.max(2,...resourceValues.map(v=>num(v[k]||0).length))+'ch').join(' ');
      addSection('Zbiory',true);
      // Jeden grid dla wszystkich grup — kolumny wyrównane jak w Zestawieniu
      const zbGrid=document.createElement('div');
      zbGrid.style.cssText='display:grid;grid-template-columns:'+resourceColumns+';gap:0 8px;font-size:11px;font-variant-numeric:tabular-nums;margin-bottom:4px';
      $('quantum-groups').append(zbGrid);
      // Nagłówki kolumn
      const zbHdr=document.createElement('span');zbHdr.style.cssText='padding:1px 0;border-bottom:1px solid #4a3525';zbGrid.append(zbHdr);
      for(const icon of ['🪙','🔨','🔩']){const hd=document.createElement('span');hd.textContent=icon;hd.style.cssText='font-weight:bold;text-align:right;padding:1px 0;border-bottom:1px solid #4a3525';zbGrid.append(hd);}
      for(const group of summary.groups){
        const atKey=String(group.at);
        // Stan zwinięcia: domyślnie true (zwinięte), przywróć jeśli był wcześniej rozwinięty
        const collapsed=paintQuantum._collapsed?.has(atKey)?paintQuantum._collapsed.get(atKey):true;
        // Wiersz nagłówka grupy
        const hRow=document.createElement('span');
        hRow.dataset.groupat=atKey;hRow.dataset.collapsed=collapsed?'1':'0';
        hRow.style.cssText='grid-column:1/-1;display:grid;grid-template-columns:'+resourceColumns+';gap:0 8px;cursor:pointer;margin-top:4px';
        const isReady=group.at<=Date.now()/1000;
        if(isReady)hRow.dataset.ready='1';
        const timeCell=document.createElement('strong');
        timeCell.textContent=(collapsed?'▸ ':'▾ ')+(isReady?'Gotowe':clockTime(group.at));
        timeCell.style.cssText='padding:1px 0';hRow.append(timeCell);
        for(const k of FoeQuantum.KEYS){const c=document.createElement('span');c.textContent=num(group.production[k])||'—';c.style.cssText='text-align:right;padding:1px 0;font-weight:bold;color:'+(group.production[k]?'#f0e6d2':'#6a7a7e');hRow.append(c);}
        zbGrid.append(hRow);
        // Wiersze budynków
        const rows=[];
        for(const item of FoeQuantum.groupedBuildings(group.items)){
          const nameCell=document.createElement('span');const bold=document.createElement('strong');bold.textContent=item.count+'×';nameCell.append(bold,' '+item.name);
          nameCell.style.cssText='padding:1px 4px;color:#c8d8dc'+(collapsed?';display:none':'');
          zbGrid.append(nameCell);rows.push(nameCell);
          for(const k of FoeQuantum.KEYS){const c=document.createElement('span');c.textContent=item.production[k]?item.production[k].toLocaleString('pl-PL'):'—';c.style.cssText='text-align:right;padding:1px 0;color:'+(item.production[k]?'#f0e6d2':'#6a7a7e')+(collapsed?';display:none':'');zbGrid.append(c);rows.push(c);}
        }
        // Toggle
        hRow.onclick=()=>{
          const nowCollapsed=hRow.dataset.collapsed!=='0';
          hRow.dataset.collapsed=nowCollapsed?'0':'1';
          rows.forEach(r=>r.style.display=nowCollapsed?'':'none');
          timeCell.textContent=(nowCollapsed?'▾ ':'▸ ')+(group.at<=Date.now()/1000?'Gotowe':clockTime(group.at));
          if(!paintQuantum._collapsed)paintQuantum._collapsed=new Map();
          paintQuantum._collapsed.set(atKey,!nowCollapsed);
        };
      }
      if(summary.builds.length){
        addSection('W budowie');
        const groups=[];
        for(const build of [...summary.builds].sort((a,b)=>(a.at??Infinity)-(b.at??Infinity))){
          let group=groups.at(-1);
          if(!group||!build.at||!group.at||build.at-group.start>600){group={start:build.at,at:build.at,items:new Map()};groups.push(group);}
          group.at=build.at;
          const key=build.cityentity_id||build.name;
          if(!group.items.has(key))group.items.set(key,{...build,count:0});group.items.get(key).count++;
        }
        for(const group of groups){
          const line=text($('quantum-groups'),(group.at?clockTime(group.at,false):'—')+' | ','div');line.style.cssText='font-size:11px;margin:5px 0';
          for(const [i,item] of [...group.items.values()].entries()){
            if(i)line.append(' · ');const node=text(line,item.count+'× '+item.name,'span');node.title=item.benefits||'Brak danych o efektach budynku.';
          }
        }
      }
      const buildProduction=FoeQuantum.groupedBuildings(summary.builds.filter(b=>b.hasProduction)).map(item=>({...item,underConstruction:true}));
      const buildExtras=FoeQuantum.groupedExtras(summary.builds.filter(b=>!b.hasProduction&&FoeQuantum.EXTRA_KEYS.some(k=>b.effects[k]))).map(item=>({...item,underConstruction:true}));
      const constructionStyle=';opacity:0.5';
      const addConstructionTotal=(table,keys,totals,pending,field)=>{
        if(!pending.length)return;
        const label=text(table,'🚧 Suma z budową','span');label.style.cssText='font-weight:bold;padding:2px 0'+constructionStyle;
        label.title='Suma bieżących wierszy i budynków w budowie. Produkcja według bonusów zestawienia; bez przeliczania wpływu nowych budynków na pozostałe.';
        for(const key of keys){const value=(totals[key]||0)+pending.reduce((sum,item)=>sum+(item[field][key]||0)-(field==='effects'?(item.activeEffects?.[key]||0):0),0);const cell=text(table,value?num(value):'—','span');cell.style.cssText='text-align:right;font-weight:bold;padding:2px 0'+constructionStyle;}
      };
      // Zestawienie budynków i sumarycznej produkcji (domyślnie rozwinięte)
      if(summary.groups.length||buildProduction.length){
        const allItems=summary.groups.flatMap(g=>g.items);
        const grouped=[...FoeQuantum.groupedBuildings(allItems),...buildProduction];
        const sec=document.createElement('details');sec.open=true;sec.style.cssText='';
        const hrZ=document.createElement('hr');hrZ.style.cssText='border:none;border-top:1px solid #2e4450;margin:10px 0 6px';$('quantum-groups').append(hrZ);
        $('quantum-groups').append(sec);
        const secLabel=document.createElement('summary');secLabel.style.cssText='font-weight:bold;font-size:12px;cursor:pointer;color:#8fcfcf;margin-bottom:4px';secLabel.textContent='Zestawienie';sec.append(secLabel);
        const tbl=document.createElement('div');tbl.style.cssText='display:grid;grid-template-columns:'+resourceColumns+';gap:0 8px;font-size:11px;font-variant-numeric:tabular-nums;';sec.append(tbl);
        // Nagłówki
        for(const h of ['','🪙','🔨','🔩']){const hd=document.createElement('span');hd.textContent=h;hd.style.cssText='font-weight:bold;text-align:right;padding:1px 0;border-bottom:1px solid #4a3525';tbl.append(hd);}
        for(const item of grouped){
          const nameCell=document.createElement('span');const b=document.createElement('strong');b.textContent=item.count+'×';nameCell.append(b,' '+item.name+(item.underConstruction?' 🚧':''));nameCell.style.cssText='padding:1px 0'+(item.underConstruction?constructionStyle:'');if(item.underConstruction)nameCell.title='W budowie — bieżąca suma obejmuje tylko aktywne efekty.';tbl.append(nameCell);
          for(const k of FoeQuantum.KEYS){const c=document.createElement('span');c.textContent=item.production[k]?item.production[k].toLocaleString('pl-PL'):'—';c.style.cssText='text-align:right;padding:1px 0;color:'+(item.production[k]?'#f0e6d2':'#6a7a7e')+(item.underConstruction?constructionStyle:'');tbl.append(c);}
        }
        // Suma
        const totalsRow=document.createElement('span');totalsRow.textContent='Suma';totalsRow.style.cssText='font-weight:bold;padding:2px 0;border-top:1px solid #4a3525';tbl.append(totalsRow);
        for(const k of FoeQuantum.KEYS){const c=document.createElement('span');c.textContent=summary.totals[k]?summary.totals[k].toLocaleString('pl-PL'):'—';c.style.cssText='text-align:right;font-weight:bold;padding:2px 0;border-top:1px solid #4a3525';tbl.append(c);}
        addConstructionTotal(tbl,FoeQuantum.KEYS,summary.totals,buildProduction,'production');
      }
      // Sekcja: Pozostałe budynki (nieprodukcyjne — stałe efekty)
      if(summary.extras?.length||buildExtras.length){
        const grouped=[...FoeQuantum.groupedExtras(summary.extras||[]),...buildExtras];
        // Ustal dynamicznie które kolumny mają jakiekolwiek wartości != 0
        const extraColDefs=[
          {key:'guild_raids_happiness',    label:'😊', title:'Zadowolenie'},
          {key:'guild_raids_population',   label:'👥', title:'Populacja'},
          {key:'guild_raids_action_points_collection', label:'⚡', title:'Produkcja działań/h'},
          {key:'guild_raids_action_points_capacity',   label:'🔋', title:'Pojemność działań'},
          {key:'att_def_boost_attacker',   label:'🗡️', title:'Bonus ataku atakującego %'},
          {key:'att_def_boost_defender',   label:'🛡️', title:'Bonus obrony obrońcy %'},
        ];
        const activeCols=extraColDefs.filter(col=>grouped.some(g=>g.effects[col.key]!==0));
        if(activeCols.length){
          const sec2=document.createElement('details');sec2.open=true;sec2.style.cssText='';
          const hrP=document.createElement('hr');hrP.style.cssText='border:none;border-top:1px solid #2e4450;margin:10px 0 6px';$('quantum-groups').append(hrP);
          $('quantum-groups').append(sec2);
          const sec2Label=document.createElement('summary');sec2Label.style.cssText='font-weight:bold;font-size:12px;cursor:pointer;color:#8fcfcf;margin-bottom:4px';sec2Label.textContent='Pozostałe budynki';sec2.append(sec2Label);
          const tbl2=document.createElement('div');
          tbl2.style.cssText=`display:grid;grid-template-columns:1fr ${activeCols.map(()=>'auto').join(' ')};gap:0 8px;font-size:11px;font-variant-numeric:tabular-nums;`;
          sec2.append(tbl2);
          // Nagłówki
          const hName=document.createElement('span');hName.style.cssText='font-weight:bold;padding:1px 0;border-bottom:1px solid #4a3525';tbl2.append(hName);
          for(const col of activeCols){const hd=document.createElement('span');hd.textContent=col.label;hd.title=col.title;hd.style.cssText='font-weight:bold;text-align:right;padding:1px 0;border-bottom:1px solid #4a3525';tbl2.append(hd);}
          // Wiersze
          const extTotals=Object.fromEntries(FoeQuantum.EXTRA_KEYS.map(k=>[k,0]));
          for(const item of grouped){
            const nameCell=document.createElement('span');const b=document.createElement('strong');b.textContent=item.count+'×';nameCell.append(b,' '+item.name+(item.underConstruction?' 🚧':''));nameCell.style.cssText='padding:1px 0'+(item.underConstruction?constructionStyle:'');if(item.underConstruction)nameCell.title='W budowie — bieżąca suma obejmuje tylko aktywne efekty.';tbl2.append(nameCell);
            for(const col of activeCols){
              const v=item.effects[col.key]||0;
              const c=document.createElement('span');
              c.textContent=v?(item.count>1&&col.key!=='guild_raids_happiness'&&col.key!=='guild_raids_population'?v.toLocaleString('pl-PL'):v.toLocaleString('pl-PL')):'—';
              c.style.cssText='text-align:right;padding:1px 0;color:'+(v!==0?(v<0?'#e57373':'#f0e6d2'):'#6a7a7e')+(item.underConstruction&&!item.activeEffects?.[col.key]?constructionStyle:'');
              if(item.underConstruction&&item.activeEffects?.[col.key])c.title='Działa już podczas budowy.';
              tbl2.append(c);
              extTotals[col.key]+=item.underConstruction?(item.activeEffects?.[col.key]||0):v;
            }
          }
          // Suma
          const sumName=document.createElement('span');sumName.textContent='Suma';sumName.style.cssText='font-weight:bold;padding:2px 0;border-top:1px solid #4a3525';tbl2.append(sumName);
          for(const col of activeCols){const c=document.createElement('span');const v=extTotals[col.key];c.textContent=v?v.toLocaleString('pl-PL'):'—';c.style.cssText='text-align:right;font-weight:bold;padding:2px 0;border-top:1px solid #4a3525;color:'+(v<0?'#e57373':'#f0e6d2');tbl2.append(c);}
          addConstructionTotal(tbl2,activeCols.map(col=>col.key),extTotals,buildExtras,'effects');
        }
      }
      const emojiTitles={'🪙':'Monety kwantowe','🔨':'Zaopatrzenie kwantowe (młotki)','🔩':'Chronostopy','👑':'Poziom trudności najazdu','⌛':'Termin zakończenia najazdu','✨':'Mnożnik produkcji wynikający z zadowolenia','⚡':'Produkcja działań kwantowych na godzinę','⚔️':'Walki na godzinę przy koszcie 3500 działań za walkę'};
      const walker=document.createTreeWalker($('quantum'),NodeFilter.SHOW_TEXT),nodes=[];
      while(walker.nextNode())nodes.push(walker.currentNode);
      for(const node of nodes){
        const parts=node.textContent.split(/(🪙|🔨|🔩|👑|⌛|✨|⚡|⚔️)/u);
        if(parts.length===1)continue;
        const fragment=document.createDocumentFragment();
        for(const part of parts){
          if(emojiTitles[part]){const icon=document.createElement('span');icon.textContent=part;icon.title=emojiTitles[part];fragment.append(icon);}
          else fragment.append(document.createTextNode(part));
        }
        node.replaceWith(fragment);
      }
    };
    syncNotes();paintQuantum();
    setInterval(paintQuantum,30000);

    // Wczytaj ustawienia z localStorage
    const LS_MULTIPLIER    = 'foe-companion.multiplier';
    const LS_ARC_BONUS     = 'foe-companion.arcBonus';
    const LS_AUTO_OPEN     = 'foe-companion.autoOpen';
    const LS_AUTO_OPEN_GBG = 'foe-companion.autoOpenGbg';
    const LS_AUTO_OPEN_QUANTUM = 'foe-companion.autoOpenQuantum';
    $('auto-open-quantum').checked=localStorage.getItem(LS_AUTO_OPEN_QUANTUM)!=='0';
    $('auto-open-quantum').onchange=()=>localStorage.setItem(LS_AUTO_OPEN_QUANTUM,$('auto-open-quantum').checked?'1':'0');
    openQuantumPanel=()=>{
      if(!$('auto-open-quantum').checked)return;
      root.querySelector('aside').classList.add('open');
      root.querySelectorAll('[data-page]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.page==='quantum')));
      root.querySelectorAll('aside>section').forEach(s=>s.hidden=s.id!=='quantum');
      syncNotes();
    };
    const LS_AUTO_COPY     = 'foe-companion.autoCopy';

    const savedMultiplier   = localStorage.getItem(LS_MULTIPLIER);
    $('arc-bonus').value=localStorage.getItem(LS_ARC_BONUS)??'92.7';
    const savedAutoOpen     = localStorage.getItem(LS_AUTO_OPEN);
    const savedAutoOpenGbg  = localStorage.getItem(LS_AUTO_OPEN_GBG);
    const savedAutoCopy     = localStorage.getItem(LS_AUTO_COPY);

    if (savedMultiplier !== null) {
      $('multiplier').value = savedMultiplier;
    }
    const autoOpenEnabled    = () => $('auto-open').checked;
    const autoOpenGbgEnabled = () => $('auto-open-gbg').checked;
    const autoCopyEnabled    = () => $('auto-copy').checked;

    if (savedAutoOpen === '0')    { $('auto-open').checked = false; }
    if (savedAutoOpenGbg === '0') { $('auto-open-gbg').checked = false; }
    if (savedAutoCopy === '0')    { $('auto-copy').checked = false; }

    /*
     * Funkcja używana przez listener wiadomości gry.
     * Dzięki temu można otworzyć panel zanim zostanie
     * wywołane paintPearl().
     */
    openPearlPanel = () => {
      if (!autoOpenEnabled()) return;

      const aside = root.querySelector('aside');
      if (aside) aside.classList.add('open');

      // Przełącz na zakładkę perły
      root.querySelectorAll('[data-page]').forEach(b =>
        b.setAttribute('aria-selected', String(b.dataset.page === 'gb'))
      );
      root.querySelectorAll('section').forEach(s => {
        s.hidden = s.id !== 'gb';
      });

      // Auto-kopiowanie kwoty dla wybranej cyfry
      if (autoCopyEnabled() && lastDigit) {
        const digit = lastDigit;
        // Poczekaj aż paintPearl wyrenderuje wiersze
        setTimeout(() => {
          const result = FoeModel.pearlAmounts(
            construction,
            $('multiplier').value,
            false
          );
          if (!result) return;
          const row = result.rows.find(r => r.rank === digit);
          if (!row || row.amount === null) return;
          navigator.clipboard.writeText(String(row.amount)).then(() => {
            $('pearl-feedback').textContent =
              'Skopiowano P' + digit + ': ' + row.amount;
          }).catch(() => {});
        }, 50);
      }
    };

    openGbgPanel = () => {
      if (!autoOpenGbgEnabled()) return;

      const aside = root.querySelector('aside');
      if (aside) aside.classList.add('open');

      // Przełącz na zakładkę Pól Chwały
      root.querySelectorAll('[data-page]').forEach(b =>
        b.setAttribute('aria-selected', String(b.dataset.page === 'gbg'))
      );
      root.querySelectorAll('section').forEach(s => {
        s.hidden = s.id !== 'gbg';
      });
    };

    $('handle').onclick = () => {
      root
        .querySelector('aside')
        .classList.add('open');

      $('close').focus();
    };

    $('close').onclick = () => {
      root
        .querySelector('aside')
        .classList.remove('open');
    };


    // 2. CZYSTY LISTENER KLAWIATURY (Bez logiki Double Ctrl)
    document.addEventListener('keydown', e => {
      // Oryginalna obsługa klawisza Escape
      if (e.key === 'Escape') {
        root
          .querySelector('aside')
          .classList.remove('open');
      }

      // Oryginalna obsługa cyfr 1–5 poza polami tekstowymi
      if (/^[1-5]$/.test(e.key) && !e.ctrlKey && !e.altKey && !e.metaKey) {
        const tag = (root.activeElement || document.activeElement)?.tagName;
        if (!['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) {
          const digit = Number(e.key);
          lastDigit = digit;
          // Jeśli panel jest otwarty i są dane perły — kopiuj od razu
          const aside = root.querySelector('aside');
          if (aside?.classList.contains('open') && construction) {
            const result = FoeModel.pearlAmounts(construction, $('multiplier').value, false);
            const row = result?.rows?.find(r => r.rank === digit);
            if (row?.amount !== null && row?.amount !== undefined) {
              navigator.clipboard.writeText(String(row.amount)).then(() => {
                $('pearl-feedback').textContent = 'Skopiowano P' + digit + ': ' + row.amount;
              }).catch(() => {});
            }
          }
        }
      }
    });


    root
      .querySelectorAll('[data-page]')
      .forEach(button => {
        button.onclick = () => {
          root
            .querySelectorAll('[data-page]')
            .forEach(b =>
              b.setAttribute(
                'aria-selected',
                String(b === button)
              )
            );

          root
            .querySelectorAll('section')
            .forEach(s => {
              s.hidden =
                s.id !== button.dataset.page;
            });
        };
      });

    $('settings').prepend($('settings-open'));
    $('list').tabIndex=0;
    for(const event of ['pointerdown','mousedown','mouseup','click','copy','selectstart'])$('list').addEventListener(event,e=>e.stopPropagation());
    const scheduleKey='foe-companion.scheduleDisplay.v1';
    try{FoeModel.setDisplaySettings(JSON.parse(localStorage.getItem(scheduleKey)||'{}'));}catch{}
    const scheduleConfig=document.createElement('details');scheduleConfig.id='settings-schedule';
    scheduleConfig.innerHTML='<summary>Rozpiska</summary>';
    for(const [key,label] of [['guildColor','Kolor gildii w sektorze'],['ownProgress','Pokazuj progres w sektorze'],['enemyProgress','Pokazuj progres wroga w sektorze'],['closedAttrition','Opór zamkniętych sektorów'],['closedCount','Liczba zamkniętych sektorów w modalu']]){
      const line=document.createElement('label'),input=document.createElement('input');line.textContent=label+' ';
      input.type=key==='closedCount'?'number':'checkbox';
      if(input.type==='number'){input.min='0';input.max='500';input.step='1';input.value=FoeModel.displaySettings[key];}else input.checked=FoeModel.displaySettings[key];
      input.onchange=()=>{
        const value=input.type==='number'?Number(input.value):input.checked;
        if(input.type==='number'&&(!input.value||!Number.isInteger(value)||value<0||value>500)){input.value=FoeModel.displaySettings[key];return;}
        const previous=FoeModel.displaySettings;
        try{localStorage.setItem(scheduleKey,JSON.stringify({...previous,[key]:value}));FoeModel.setDisplaySettings({[key]:value});}
        catch{if(input.type==='number')input.value=previous[key];else input.checked=previous[key];return;}
        paint();paintOpenSectors();paintSectorPopup();
      };line.append(input);scheduleConfig.append(line);
    }
    $('settings-gbg').querySelector('summary').after(scheduleConfig);
    const autoKey='foe-companion-gbg-auto';
    let bulkAutomation=null;
    let modalActionStatus='';
    function actionVisible(kind){try{return localStorage.getItem('foe-companion.showActions.'+kind)==='1';}catch{return false;}}
    for(const [kind,id] of [['attack','show-attack-buttons'],['negotiation','show-negotiation-buttons'],['collection','show-collection-buttons']]){
      const checkbox=$(id);checkbox.checked=actionVisible(kind);
      checkbox.onchange=()=>{
        try{localStorage.setItem('foe-companion.showActions.'+kind,checkbox.checked?'1':'0');}catch{checkbox.checked=actionVisible(kind);return;}
        if(!checkbox.checked&&kind==='attack')requestStopAuto();
        if(!checkbox.checked&&kind==='negotiation')stopAutoNeg('Przyciski negocjacji wyłączone.');
        refreshActionSettings();paintOpenSectors();paintCity();
      };
    }

    let selectedSector=null;
    let autoSettings={reserve:3,min:0.7,max:1.5};
    try{const v=JSON.parse(localStorage.getItem(autoKey));if(v&&Number.isInteger(v.reserve)&&v.reserve>=0&&Number.isFinite(v.min)&&v.min>=0&&Number.isFinite(v.max)&&v.max>=v.min){autoSettings=v;}}catch{}
    const autoConfig=document.createElement('details');autoConfig.id='settings-autoattack';
    autoConfig.innerHTML='<summary>Autoatak</summary><label>Pozostaw walk <input id="auto-reserve" type="number" min="0" step="1"></label><label>Przerwa (s) <span class="settings-range"><input id="auto-min" aria-label="Minimalna przerwa po walce" type="number" min="0" step="0.1"> – <input id="auto-max" aria-label="Maksymalna przerwa po walce" type="number" min="0" step="0.1"></span></label><small>Stop po 3 porażkach z rzędu.</small><p id="auto-settings-error"></p>';
    $('gbg-automation-settings').append(autoConfig);
    const negTurnKey='foe-companion.negotiationTurnDelay';
    let negTurnSettings={min:3.7,max:6};
    try{const saved=JSON.parse(localStorage.getItem(negTurnKey));if(saved&&Number.isFinite(saved.min)&&Number.isFinite(saved.max)&&saved.min>=0&&saved.max>=saved.min&&saved.max<=60){negTurnSettings={min:saved.min,max:saved.max};}}catch{}
    const negTurnConfig=document.createElement('details');negTurnConfig.id='settings-negotiations';
    negTurnConfig.innerHTML='<summary>Negocjacje</summary><label>Między turami (s) <span class="settings-range"><input id="nego-turn-min" type="number" min="0" max="60" step="0.1" aria-label="Minimalna przerwa między turami"> – <input id="nego-turn-max" type="number" min="0" max="60" step="0.1" aria-label="Maksymalna przerwa między turami"></span></label><small id="nego-turn-error" role="status"></small>';
    autoConfig.after(negTurnConfig);
    const registerSettingsFolds=()=>{
      for(const section of $('settings').querySelectorAll('details[id]')){
        if(section.dataset.foldRegistered)continue;
        section.open=false;
        section.dataset.foldRegistered='1';
      }
    };
    registerSettingsFolds();
    for(const key of ['min','max']){
      $('nego-turn-'+key).value=negTurnSettings[key];
      $('nego-turn-'+key).onchange=()=>{
        const minText=$('nego-turn-min').value,maxText=$('nego-turn-max').value,min=Number(minText),max=Number(maxText);
        if(!minText||!maxText||!Number.isFinite(min)||!Number.isFinite(max)||min<0||max<min||max>60){$('nego-turn-error').textContent='Zakres: 0–60 s; maksimum ≥ minimum.';return;}
        negTurnSettings={min,max};localStorage.setItem(negTurnKey,JSON.stringify(negTurnSettings));$('nego-turn-error').textContent='';
      };
    }
    for(const key of ['reserve','min','max']){
      $('auto-'+key).value=autoSettings[key];
      $('auto-'+key).onchange=()=>{
        const next=Object.fromEntries(['reserve','min','max'].map(k=>[k,Number($('auto-'+k).value)]));
        if(!Number.isInteger(next.reserve)||next.reserve<0||!Number.isFinite(next.min)||next.min<0||!Number.isFinite(next.max)||next.max<next.min){$('auto-settings-error').textContent='Podaj nieujemne wartości; maksymalna przerwa musi być ≥ minimalnej.';return;}
        autoSettings=next;localStorage.setItem(autoKey,JSON.stringify(next));$('auto-settings-error').textContent='';stopAuto('Ustawienia zmienione.');bulkAutomation?.stop(null,'Ustawienia zmienione — uruchom ponownie.');
      };
    }
    let autoSector=null,autoTimer=null,autoStopRequested=false,lossStreak=0,fights=0,wins=0;
    const stats=document.createElement('td');stats.title='Wygrane / zakończone walki przyciskami rozszerzenia w tej sesji';stats.textContent='🏆 0/0';$('open-sectors').before(stats);
    const stopButton=document.createElement('button');stopButton.textContent='⏹ Stop walk';stopButton.hidden=true;stats.after(stopButton);stopButton.onclick=()=>requestStopAuto();
    function setBattleFeedback(message){
      const full=String(message||'');
      let short=full;
      if(full.includes('3 kolejnych porażkach'))short='Autoatak: STOP — 3 porażki z rzędu.';
      else if(full.includes('Osiągnięto ustawiony zapas')||full.includes('Osiągnięto zapas:'))short='STOP — osiągnięto ustawiony zapas walk.';
      else if(full.includes('Wyczerpano limit tur. Negocjacja poddana.'))short='Przegrana — koniec tur, negocjacja poddana.';
      else if(full.startsWith('Negocjacja zakończona sukcesem'))short=full.replace('Negocjacja zakończona sukcesem','Wygrana');
      else if(full.startsWith('Auto-negocjacja zatrzymana.'))short='Auto-negocjacje: STOP.';
      else if(full.startsWith('Autoatak zatrzymany.'))short='Autoatak: STOP.';
      else if(full.includes('Auto-negocjacje zatrzymane.'))short='Auto-negocjacje: STOP — błąd; sprawdź towary.';
      else if(full.startsWith('Pobieranie i wymiana armii:'))short=full.replace('Pobieranie i wymiana armii:','Wymiana armii:');
      modalActionStatus=short;
      const status=root.querySelector('[data-bulk-status]');if(status)status.textContent=short;
      const feedback=$('battle-feedback');feedback.textContent=short;feedback.setAttribute('aria-label',short);
    }
    function stopAuto(message){clearTimeout(autoTimer);autoTimer=null;autoSector=null;autoStopRequested=false;stopButton.disabled=false;stopButton.textContent='⏹ Stop walk';stopButton.hidden=true;if(message)setBattleFeedback(message);paintOpenSectors();}

    // --- Pilnowanie sektorów (sectorGuard) ---
    const GUARD_KEY='foe-companion.sectorGuard';
    function loadGuards(){try{const v=JSON.parse(localStorage.getItem(GUARD_KEY)||'{}');return(v&&typeof v==='object'&&!Array.isArray(v))?v:{};}catch{return{};}}
    function saveGuards(guards){try{localStorage.setItem(GUARD_KEY,JSON.stringify(guards));}catch{}}
    function getGuard(mapId,sectorId){const g=loadGuards();return g[mapId+':'+sectorId]||{guard:false,closeAtHour:false,closeWhenThreatened:false};}
    function setGuard(mapId,sectorId,patch){const g=loadGuards();const key=mapId+':'+sectorId;g[key]={...getGuard(mapId,sectorId),...patch};if(!g[key].guard&&!g[key].closeAtHour&&!g[key].closeWhenThreatened)delete g[key];saveGuards(g);}
    const closeAtHourTimers=new Map();
    function startGuardClosing(sectorId){
      if(!battle||bulkAutomation?.engaged||bulkAutomation?.guardsPaused||battlePending||negPending||autoSector!==null||autoNegSector!==null||battleWaveSector!==null)return false;
      if(!bulkSettings.closeWithNegotiations){if(!actionVisible('attack'))return false;return startFight(sectorId,true);}
      if(!actionVisible('negotiation')||!battleReady)return false;
      guardNegClosing=true;autoNegSector=sectorId;stopNegButton.hidden=false;startNeg(sectorId);return !!negPending;
    }
    function scheduleCloseAtHour(sectorId){
      if(closeAtHourTimers.has(sectorId))return;
      const now=Date.now();const ms=now%3600000;let delay=3600000-ms-30000;if(delay<=0)delay+=3600000;
      const timer=setTimeout(()=>{
        closeAtHourTimers.delete(sectorId);if(!battle||bulkAutomation?.engaged||bulkAutomation?.guardsPaused)return;
        const guard=getGuard(battle.map.id,sectorId);if(!guard.closeAtHour)return;
        setBattleFeedback('Zamykam sektor o pełnej godzinie: '+sectorId);
        startGuardClosing(sectorId);setGuard(battle.map.id,sectorId,{closeAtHour:false});paintOpenSectors();
      },delay);
      closeAtHourTimers.set(sectorId,timer);
    }
    function cancelCloseAtHour(sectorId){const t=closeAtHourTimers.get(sectorId);if(t!=null){clearTimeout(t);closeAtHourTimers.delete(sectorId);}}
    const enemyProgressPrev=new Map();
    const guardAlerted=new Map();


    // --- Negocjacje UI --- (negStats/stopNegButton/negPanel zdefiniowane poniżej, montowane tu)
    // Montaż następuje po deklaracji zmiennych negocjacyjnych w kolejnym bloku.
    let negClearTimer=null;
    let negPending=null,negPendingSector=null,negLastSector=null,negLastUntil=0,negLastOK=false;
    function requestStopAuto(){
      if(autoSector===null)return;
      if(!battlePending&&battleWaveSector===null){stopAuto('Autoatak zatrzymany.');return;}
      autoStopRequested=true;stopButton.disabled=true;stopButton.textContent='Kończę walkę…';
      setBattleFeedback('Zatrzymywanie — kończę rozpoczętą walkę wraz z pozostałymi falami.');
      if(!battlePending&&battleWaveSector!==null&&!autoTimer)startFight(autoSector,true);
    }
    let autoNegSector=null,autoNegTimer=null,negWins=0,negDone=0,guardNegClosing=false;
    const negStats=document.createElement('td');negStats.title='Wygrane / zakończone negocjacje przyciskami rozszerzenia w tej sesji';negStats.textContent='🤝 0/0';
    const stopNegButton=document.createElement('button');stopNegButton.textContent='⏹ Stop nego';stopNegButton.hidden=true;
    // Panel tury negocjacji — wyświetlany pod listą sektorów podczas aktywnej negocjacji.
    const negPanel=document.createElement('div');negPanel.id='neg-panel';negPanel.style.cssText='background:transparent;padding:10px;margin:8px 0;font-size:13px';
    // Montuj w DOM: negStats i stopNegButton za stopButton, negPanel przed listą sektorów.
    const counters=document.createElement('table');counters.style.cssText='width:auto;margin:0;border-collapse:collapse;text-align:center;font-size:12px;white-space:nowrap';
    const counterBody=document.createElement('tbody'),counterRow=document.createElement('tr');
    const attritionStats=document.createElement('td');attritionStats.title='Aktualny opór na Polach Chwały';attritionStats.setAttribute('aria-live','polite');
    paintAttrition=()=>{attritionStats.textContent='🔻 '+(playerAttrition??'—');};paintAttrition();
    $('gbg-title').append(counters);counterRow.append(stats,negStats,attritionStats);counterBody.append(counterRow);counters.append(counterBody);
    const controls=document.createElement('div');controls.id='gbg-controls';
    const stops=document.createElement('div');stops.id='gbg-stop-controls';
    stopButton.before(controls);stops.append(stopButton,stopNegButton);controls.append(stops);
    stopNegButton.onclick=()=>stopAutoNeg('Auto-negocjacja zatrzymana. Trwająca negocjacja zostanie dokończona.');
    $('feedback').after(negPanel);$('open-sectors').before($('battle-feedback'));
    const negStatus=document.createElement('div');negStatus.id='neg-status';negStatus.textContent='ready';negStatus.style.cssText='font-size:12px';controls.append(negStatus);
    function stopAutoNeg(message){
      if(guardNegClosing){guardNegClosing=false;bulkAutomation?.pauseGuards();}
      clearTimeout(autoNegTimer);autoNegTimer=null;autoNegSector=null;stopNegButton.hidden=true;
      if(message)setBattleFeedback(message);paintOpenSectors();
    }
    function startNeg(id,bulkPolicy=null){
      if(guardNegClosing){
        const target=battle&&FoeModel.rows(battle,true).rows.find(r=>r.id===id&&r.until<=Date.now()/1000);
        if(bulkAutomation?.guardsPaused||!bulkSettings.closeWithNegotiations||!target||target.ignored||target.gainAttritionChance!==20||!Number.isSafeInteger(playerAttrition)||playerAttrition>bulkSettings.maxAttrition){stopAutoNeg('Zamykanie negocjacjami zatrzymane — sektor lub opór nie spełnia warunków.');return false;}
        bulkPolicy={kind:'negotiation',mapId:battle.map.id,endsAt:battle.endsAt,progress:100,reserve:autoSettings.reserve,maxAttrition:bulkSettings.maxAttrition};
      }
      if(bulkAutomation?.engaged&&!bulkPolicy){if(autoNegSector!==null)stopAutoNeg();setBattleFeedback('Najpierw zatrzymaj automatyzację otwartych sektorów.');return false;}
      if(battlePending||autoSector!==null||battleWaveSector!==null)return false;
      if(!actionVisible('negotiation')){stopAutoNeg();return;}
      if(negPending){if(autoNegSector!==null)stopAutoNeg('Negocjacja w toku.');return;}
      if(!battleReady){if(autoNegSector!==null)stopAutoNeg('Brak gotowego połączenia.');return;}
      const row=FoeModel.rows(battle,true).rows.find(r=>r.id===id&&r.until<=Date.now()/1000);
      if(!row){stopAutoNeg('Sektor nie jest już dostępny.');return;}
      negPending=crypto.randomUUID();negPendingSector=id;selectedSector=id;negStatus.textContent='start nego';
      clearTimeout(negClearTimer);
      negPanel.style.display='block';negPanel.innerHTML='<em>Uruchamiam negocjację: '+row.sector+'…</em>';
      setBattleFeedback('Negocjacja: '+row.sector+'…');
      window.postMessage({channel:'foe-negotiate',token:negPending,provinceId:id,turnDelay:negTurnSettings,...(bulkPolicy?{bulkPolicy,reserve:autoSettings.reserve}:autoNegSector!==null?{reserve:autoSettings.reserve}:{})},location.origin);
      paintOpenSectors();
    }
    window.addEventListener('message',event=>{
      if(event.source!==window||event.origin!==location.origin)return;
      const d=event.data;
      // Feedback wizualny w trakcie negocjacji.
      if(d?.channel==='foe-negotiate-started'&&d.token===negPending){
        const goodsStr=d.goods.join(', ');
        negPanel.innerHTML='<strong>Negocjacja w toku</strong><br>Towary: '+goodsStr+'<div id="neg-turns"></div>';
      }
      if(d?.channel==='foe-negotiate-turn'&&d.token===negPending){
        negStatus.textContent=d.turn+' tura';setBattleFeedback('🤝 '+(FoeModel.sector(negPendingSector,battle?.map?.id))+' — tura '+d.turn);
        let div=negPanel.querySelector('#neg-turns');if(!div){div=document.createElement('div');div.id='neg-turns';negPanel.append(div);}
        const row=document.createElement('div');row.style.cssText='border-top:1px solid #1e3540;padding:4px 0;margin-top:4px';
        row.innerHTML='<small style="color:#90a5ad">Tura '+d.turn+':</small> '+d.guess.join(' · ');
        div.append(row);
      }
      if(d?.channel==='foe-negotiate-feedback'&&d.token===negPending){
        const div=negPanel.querySelector('#neg-turns');
        const lastRow=div?.lastElementChild;
        if(lastRow){
          const icons={correct:'✅',wrong_person:'🟡',not_needed:'❌'};
          const fb=d.feedback.map(s=>(s.slotId!=null?'['+s.slotId+']':'')+icons[s.state]||s.state).join(' ');
          lastRow.innerHTML+=`<br><small style="color:#aebfc4">${fb}</small>`;
          if(d.state==='won')lastRow.innerHTML+='<br><strong style="color:#7fc97f">✓ Wygrana!</strong>';
          else if(d.state==='out_of_turns')lastRow.innerHTML+='<br><strong style="color:#e06c6c">✗ Koniec tur</strong>';
        }
      }
      if(d?.channel==='foe-negotiate-result'&&d.token===negPending){
        if(!negPanel.querySelector('#neg-turns')?.children.length)negPanel.replaceChildren();
        negLastSector=negPendingSector;negLastUntil=Date.now()+1800;negLastOK=d.ok===true;
        negPending=null;negPendingSector=null;
        clearTimeout(negClearTimer);negClearTimer=setTimeout(()=>{if(!negPending)negPanel.replaceChildren();},3000);
        negStatus.textContent=d.won===true?'wygrana':d.won===false?'przegrana':'ready';
        setBattleFeedback(d.message);
        if(typeof d.won==='boolean'){negDone++;if(d.won)negWins++;negStats.textContent='🤝 '+negWins+'/'+negDone;}
        if(d.ok&&d.refreshed){// progres odświeżony — model jest już zaktualizowany przez emit
        }
        if(bulkAutomation?.active?.kind==='negotiation')bulkAutomation.result(d);
        if(autoNegSector!==null){
          if(d.sectorClosed||d.stopAuto||(!(d.ok&&d.refreshed)&&!d.continueAuto)){stopAutoNeg(d.message);}
          else{
            const id=autoNegSector;
            const delay=(autoSettings.min+Math.random()*(autoSettings.max-autoSettings.min))*1000;
            autoNegTimer=setTimeout(()=>{if(autoNegSector===id)startNeg(id);},delay);
          }
        } else {
          // Jednorazowa negocjacja skończona — ukryj panel po chwili.
          // Zachowaj przebieg i jego stałą wysokość również po zakończeniu.
        }
        paintOpenSectors();
      }
    });
    function startFight(id,automatic=false,bulkPolicy=null){
      if(bulkAutomation?.engaged&&!bulkPolicy){if(autoSector!==null)stopAuto();setBattleFeedback('Najpierw zatrzymaj automatyzację otwartych sektorów.');return false;}
      if(negPending||autoNegSector!==null)return false;
      if(!actionVisible('attack')){stopAuto();return;}
      if(!automatic&&autoSector!==null)stopAuto();
      if(!battleReady||battlePending){if(autoSector!==null)stopAuto('Brak gotowego połączenia.');return;}
      const row=FoeModel.rows(battle,true).rows.find(r=>r.id===id&&r.until<=Date.now()/1000);
      if(!row){stopAuto('Sektor nie jest już dostępny.');return;}
      battlePending=crypto.randomUUID();battlePendingSector=id;selectedSector=id;
      setBattleFeedback((battleWaveSector===id?'Kolejna fala: ':'Pobieranie i wymiana armii: ')+row.sector+'…');
      window.postMessage({channel:'foe-quick-battle',token:battlePending,provinceId:id,automatic,...(bulkPolicy?{bulkPolicy}:{}),...(automatic?{reserve:autoSettings.reserve}:{})},location.origin);paintOpenSectors();
    }
    let battleReady=false,battlePending=null,battlePendingSector=null,battleLastSector=null,battleLastUntil=0,battleLastOK=false,battleWaveSector=null,battleReadyReason='Oczekiwanie na moduł połączenia. Przeładuj rozszerzenie i odśwież grę, jeśli komunikat nie znika.';
    window.addEventListener('message',event=>{
      if(event.source!==window||event.origin!==location.origin)return;
      const data=event.data;
      if(data?.channel==='foe-map-refresh-error')setBattleFeedback(data.message);
      if(data?.channel==='foe-battle-ready'){
        battleReady=data.ready===true;battleReadyReason=data.reason||'';
        paintOpenSectors();
      }
      if(data?.channel==='foe-quick-battle-result'&&data.token===battlePending){
        battleLastSector=battlePendingSector;battleLastUntil=Date.now()+1800;battleLastOK=data.ok===true;
        battlePending=null;battlePendingSector=null;if(data.uncertain)battleReady=false;
        if(data.invalidWave)battleWaveSector=null;
        else if(data.ok)battleWaveSector=data.nextWave?data.provinceId:null;
        setBattleFeedback(data.message);
        if(data.ok&&!data.nextWave&&typeof data.won==='boolean'){
          fights++;if(data.won)wins++;lossStreak=data.won?0:lossStreak+1;stats.textContent='🏆 '+wins+'/'+fights;
        }
        const bulkResult=bulkAutomation?.active?.kind==='attack'?bulkAutomation.result(data):false;
        if(bulkResult==='wave'){startFight(battleLastSector,true,bulkAutomation.active.policy);if(!battlePending)bulkAutomation.result({ok:false,message:'Nie udało się rozpocząć kolejnej fali — sprawdź walkę w grze.'});}
        if(autoSector!==null){
          if(!data.ok||(!data.nextWave&&(!data.refreshed||typeof data.won!=='boolean')))stopAuto(data.message);
          else if(autoStopRequested&&!data.nextWave)stopAuto('Autoatak zatrzymany po zakończeniu walki.');
          else if(lossStreak>=3)stopAuto('Autoatak zatrzymany po 3 kolejnych porażkach.');
          else{
            const id=autoSector;
            const delay=(autoSettings.min+Math.random()*(autoSettings.max-autoSettings.min))*1000;
            autoTimer=setTimeout(()=>{if(autoSector===id)startFight(id,true);},delay);
          }
        }else if(!bulkResult&&data.ok&&data.nextWave&&!data.uncertain&&!data.invalidWave&&battleWaveSector===battleLastSector){
          // A single click authorizes the whole battle, including its remaining waves.
          startFight(battleLastSector,false);
        }
        paintOpenSectors();
      }
    });
    window.postMessage({channel:'foe-battle-state-query'},location.origin);
    setInterval(()=>{if(!battleReady&&!battlePending)window.postMessage({channel:'foe-battle-state-query'},location.origin);},3000);
    function syncSectorSelections(){
      if(!battle?.map?.provinces)return;
      const key='foe-companion.sectorSelectionCycles.v1:'+location.host+':'+battle.endsAt+':'+battle.map.id;
      try{
        const cycles=JSON.parse(localStorage.getItem(key)||'{}');
        const guards=loadGuards(),ignored=new Set(JSON.parse(localStorage.getItem(localIgnoreKey())||'[]'));
        let changed=false;
        for(const p of battle.map.provinces){
          const id=p.id??0,previous=cycles[id],lock=Number(p.lockedUntil)||0;
          if(previous&&(previous.owner!==p.ownerId||(lock>0&&lock!==previous.lock))){
            delete guards[battle.map.id+':'+id];ignored.delete(id);cancelCloseAtHour(id);changed=true;
          }
          cycles[id]={owner:p.ownerId,lock:lock||previous?.lock||0};
        }
        if(changed){saveGuards(guards);localStorage.setItem(localIgnoreKey(),JSON.stringify([...ignored]));}
        const encoded=JSON.stringify(cycles);if(localStorage.getItem(key)!==encoded)localStorage.setItem(key,encoded);
      }catch{}
    }
    function paintOpenSectors(){
      syncSectorSelections();
      root.querySelector('#sector-guard-modal')?.refresh?.();
      root.querySelector('#own-sectors-modal')?.refresh?.();
      const list=$('open-sectors');
      const snapshot=JSON.stringify([FoeModel.displaySettings,actionVisible('attack'),actionVisible('negotiation'),battle?FoeModel.rows(battle,true).rows.filter(r=>r.color!=='⚪'&&r.until<=Date.now()/1000):null,battleReady,battlePending,battlePendingSector,battleWaveSector,autoSector,autoNegSector,negPending,negPendingSector,battleLastSector,Date.now()<battleLastUntil,battleLastOK,negLastSector,Date.now()<negLastUntil,negLastOK]);
      if(list.renderSnapshot===snapshot&&list.selectedSector===selectedSector)return;
      list.renderSnapshot=snapshot;list.selectedSector=selectedSector;list.replaceChildren();
      list.copyText='';
      if(!battle){list.textContent='Otwórz mapę Pól Chwały w grze.';return;}
      const open=FoeModel.rows(battle,true).rows.filter(r=>r.color!=='⚪'&&r.until<=Date.now()/1000).sort((a,b)=>Number(a.ignored)-Number(b.ignored)||(a.progress??0)-(b.progress??0)||a.id-b.id);
      if(!open.length){list.textContent='Brak otwartych sektorów sąsiadujących z naszymi polami.';return;}
      list.copyText=open.map(FoeModel.openSectorText).join('\n');
      for(const row of open){
        const guard=battle?getGuard(battle.map.id,row.id):{guard:false,closeAtHour:false,closeWhenThreatened:false};
        const anyGuard=guard.guard||guard.closeAtHour||guard.closeWhenThreatened;
        const line=document.createElement('div');line.style.cssText='display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #345058';
        if(row.ignored){line.style.background='rgba(190,45,45,0.16)';line.title='Prowincja oznaczona przez gildie jako ignorowana';}
        if(anyGuard&&!row.ignored){line.style.background='rgba(30,100,200,0.18)';}
        const activeBattle=autoSector===row.id||battlePendingSector===row.id||battleWaveSector===row.id;
        const activeNegotiation=autoNegSector===row.id||negPendingSector===row.id;
        if(activeBattle||activeNegotiation||selectedSector===row.id){
          line.style.background='rgba(45,180,170,0.22)';line.style.boxShadow='none';
          line.title=(activeNegotiation?'Negocjacja w toku':activeBattle?'Walka w toku':'Zaznaczony sektor')+(row.ignored?' · Prowincja oznaczona przez gildię jako ignorowana':'');
        }
        const name=document.createElement('span');name.textContent=(row.isAttackBattleType===true?'🟥 ':row.isAttackBattleType===false?'🟦 ':'')+FoeModel.guildColor(row)+row.sector+FoeModel.sectorMarker(row);name.style.flex='1';
        name.style.cursor=activeBattle||activeNegotiation?'default':'pointer';
        name.style.textDecoration='none';
        name.setAttribute('role','button');name.setAttribute('tabindex','0');
        name.setAttribute('aria-pressed',String(selectedSector===row.id));
        name.setAttribute('aria-disabled',String(activeBattle||activeNegotiation));
        name.onclick=()=>{if(activeBattle||activeNegotiation)return;selectedSector=selectedSector===row.id?null:row.id;paintOpenSectors();};
        name.onkeydown=event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();name.onclick();}};

        const progress=document.createElement('span');progress.textContent=FoeModel.progressText(row);progress.hidden=!FoeModel.displaySettings.ownProgress;progress.title='Postęp przejęcia naszej gildii';
        const chance=document.createElement('span');chance.textContent=(row.gainAttritionChance===null?'—':row.gainAttritionChance+'%');chance.title='Szansa na wzrost oporu';

        // isAttackBattleType wybiera atak lub obronę, nie walkę lub negocjacje.
        // Obie akcje są dostępne; serwer potwierdza możliwość ich wykonania.
        const isBattle = false;
        const isNegOnly = false;

        const action=document.createElement('button');
        action.className='action-start';
        if(!isNegOnly){
          action.textContent=battlePendingSector===row.id?'⏳':battleLastSector===row.id&&Date.now()<battleLastUntil?(battleLastOK?'✅':'⚠️'):'⚔️';
          action.title=battlePendingSector===row.id?'Przetwarzanie żądania…':battleWaveSector===row.id?'Szybka walka — kolejna fala':'Wymień jednostki i rozpocznij szybką walkę';
          action.setAttribute('aria-label',action.title+' '+row.sector);
          action.setAttribute('aria-busy',String(battlePendingSector===row.id));
          action.disabled=!battleReady||!!battlePending||(battleWaveSector!==null&&battleWaveSector!==row.id)||autoSector!==null||autoNegSector!==null||negPending!==null;
          if(!battleReady)action.title=battleReadyReason;
          action.onclick=()=>startFight(row.id);
        } else {
          action.textContent='⚔️';action.disabled=true;action.title='Ten sektor wymaga negocjacji';
          action.style.display='none';
        }
        action.style.cssText='padding:5px;background:transparent;border-color:transparent;outline:none;font-size:14px;line-height:1;border-radius:0;margin-right:0';

        const auto=document.createElement('button');
        if(!isNegOnly){
          auto.textContent=autoSector===row.id?'⏹':'▶';auto.title=autoSector===row.id?'Zatrzymaj autoatak':'Autoatak na tym sektorze';
          auto.disabled=autoSector!==row.id&&(!battleReady||!!battlePending||autoSector!==null||autoNegSector!==null||negPending!==null||(battleWaveSector!==null&&battleWaveSector!==row.id));
          auto.onclick=()=>{if(autoSector===row.id){requestStopAuto();return;}autoSector=row.id;lossStreak=0;stopButton.hidden=false;startFight(row.id,true);};
        } else {
          auto.style.display='none';
        }

        // --- Przyciski negocjacji (gdy isAttackBattleType !== true) ---
        const negBtn=document.createElement('button');
        negBtn.className='action-start';
        const autoNegBtn=document.createElement('button');
        if(!isBattle){
          negBtn.textContent=negPendingSector===row.id?'⏳':negLastSector===row.id&&Date.now()<negLastUntil?(negLastOK?'✅':'⚠️'):'🤝';
          negBtn.title=negPendingSector===row.id?'Negocjacja w toku…':'Rozpocznij negocjację';
          negBtn.setAttribute('aria-label',negBtn.title+' '+row.sector);
          negBtn.setAttribute('aria-busy',String(negPendingSector===row.id));
          negBtn.disabled=!battleReady||negPending!==null||battlePending!==null||autoSector!==null||autoNegSector!==null;
          negBtn.style.cssText='padding:5px;background:transparent;border-color:transparent;outline:none;font-size:14px;line-height:1;border-radius:0';
          negBtn.onclick=()=>startNeg(row.id);

          autoNegBtn.textContent=autoNegSector===row.id?'⏹':'▶';
          autoNegBtn.title=autoNegSector===row.id?'Zatrzymaj auto-negocjację':'Auto-negocjacja na tym sektorze';
          autoNegBtn.disabled=autoNegSector!==row.id&&(!battleReady||negPending!==null||battlePending!==null||autoSector!==null||autoNegSector!==null);
          autoNegBtn.onclick=()=>{
            if(autoNegSector===row.id){stopAutoNeg('Auto-negocjacja zatrzymana.');return;}
            autoNegSector=row.id;stopNegButton.hidden=false;startNeg(row.id);
          };
        } else {
          negBtn.style.display='none';
          autoNegBtn.style.display='none';
        }

        action.style.display=auto.style.display=actionVisible('attack')?'':'none';
        negBtn.style.display=autoNegBtn.style.display=actionVisible('negotiation')?'':'none';
        const copy=document.createElement('button');copy.textContent='📋';copy.title='Kopiuj sektor '+row.sector;copy.setAttribute('aria-label',copy.title);copy.onclick=async event=>{event.stopPropagation();try{await navigator.clipboard.writeText(FoeModel.openSectorText(row));}catch{setBattleFeedback('Nie udało się skopiować sektora.');}};copy.onkeydown=event=>event.stopPropagation();name.append(copy);
        line.append(name,progress,chance,action,auto,negBtn,autoNegBtn);list.append(line);
      }
    }
    setInterval(()=>paint(),1000);
    paint = () => {
      paintOpenSectors();
      checkSectorAlerts();
      $('export-battle').disabled=!battle;
      $('notice').textContent = notice;

      if (!battle) {
        output = '';
        if($('list').textContent!=='Otwórz mapę Pól Chwały w grze.')$('list').textContent='Otwórz mapę Pól Chwały w grze.';
        return;
      }

      const result = FoeModel.rows(
        battle,
        $('frontier').checked
      );

      output = result.rows
        .filter(row=>row.until>Date.now()/1000)
        .map(FoeModel.line)
        .join('\n');

      const scheduleText=output||'Brak sektorów do wyświetlenia.';
      if($('list').textContent!==scheduleText)$('list').textContent=scheduleText;

      if (!result.rows.length) {
        $('notice').textContent =
          result.warning;
      }
    };

    let contributionPending=null,contributionMessage='',contributionBlocked=false;
    function contributionButton(amount,icon,title,desiredTotal,lock){
      const button=document.createElement('button');button.textContent=icon;button.title=title;button.setAttribute('aria-label',title);button.dataset.pearlContribution='true';
      button.disabled=!!contributionPending||contributionBlocked||!battleReady||!Number.isSafeInteger(amount)||amount<=0||!Number.isSafeInteger(construction?.level);
      const targetKey=JSON.stringify([construction?.target,construction?.level]);
      button.onclick=()=>{
        if(contributionPending||contributionBlocked||targetKey!==JSON.stringify([construction?.target,construction?.level]))return;
        try{
          const request=FoePearls.contributionRequest(construction,amount,0);
          contributionPending='pearl-'+Date.now();contributionMessage='Wpłacanie '+amount+' PR…';
          window.postMessage({channel:'foe-contribute',token:contributionPending,request,desiredTotal,lock},location.origin);paintPearl();
        }catch(error){contributionMessage=error.message;$('pearl-feedback').textContent=contributionMessage;}
      };
      return button;
    }
    let contributionDismissTimer=null;
    window.addEventListener('message',event=>{
      if(event.source!==window||event.origin!==location.origin||event.data?.channel!=='foe-contribution-result'||event.data.token!==contributionPending)return;
      contributionPending=null;
      if(contributionDismissTimer){clearTimeout(contributionDismissTimer);contributionDismissTimer=null;}
      if(event.data.ok){
        // #7: komunikat ok z emoji, bez drugiego zdania (notka niżej)
        contributionMessage='✅ '+event.data.message;
        // #6: komunikat znika po 8 sekundach
        contributionDismissTimer=setTimeout(()=>{contributionMessage='';contributionDismissTimer=null;paintPearl();},8000);
      }else{
        contributionMessage=event.data.message;
      }
      if(!event.data.ok&&/odśwież/.test(contributionMessage))contributionBlocked=true;
      paintPearl();
    });
    paintPearl = () => {
      const type=pearlType();
      const target=JSON.stringify([construction?.target,construction?.cityentity_id,construction?.level]);
      if(target!==totalTarget){totalTarget=target;$('pearl-total').value=pearlTotals.get(target)||'';}
      $('pearl-name').textContent=type?FoeModel.buildingLabel(type):'';
      syncNotes();
      const result = FoeModel.pearlAmounts(
        construction,
        $('multiplier').value,
        false
      );

      // Uzupełniaj także po opóźnionym odczycie kosztu, bez nadpisywania ręcznej wartości.
      if(!pearlTotals.has(target)){
        const cost=construction?.forge_points_for_level_up;
        $('pearl-total').value=Number.isSafeInteger(cost)&&cost>0?String(cost):'';
      }

      $('pearl-rows').replaceChildren();
      $('pearl-refresh-note').hidden=true;

      $('pearl-status').textContent =
        !result
          ? 'Wpisz przelicznik większy od 0 i nie większy niż 10 (do 4 miejsc po przecinku).'
          : !construction
            ? 'Otwórz perłę w grze.'
            : result.totalCost !== null
              ? 'Koszt poziomu: ' + result.totalCost + ' PR'
              : '';

      $('pearl-feedback').textContent = contributionMessage;

      if (!result || !construction) return;

      const blockText=$('pearl-total').value.trim();
      const ownerPaid=FoePearls.ownerContribution(construction);
      const paidInfo=document.createElement('small');
      paidInfo.style.cssText='display:block;color:#a5b8bc;margin:6px 0';
      paidInfo.textContent='Wpłacono przez właściciela: '+(ownerPaid??0)+' PR';
      $('pearl-rows').append(paidInfo);
      const blocks=blockText!==''&&ownerPaid!==null?FoePearls.liveLocks(Number(blockText),result.rows,construction):null;
      let blockIndex=0;
      for (const row of result.rows) {
        const line = document.createElement('div');
        line.style.cssText =
          'display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #345058';

        const label = document.createElement('span');
        label.style.flex = '1';
        label.textContent =
          'P' + row.rank + ' · ' +
          (row.base === null ? 'Brak PR' : row.base + ' PR');

        const block=blocks?.[blockIndex++];
        if(block!=null){
          const small=document.createElement('small');
          small.style.cssText='display:flex;align-items:center;gap:4px;flex-wrap:wrap;font-size:11px;color:#a5b8bc;margin-top:3px';
          small.title='Dopłata od obecnego stanu perły: rzeczywiste wpłaty wszystkich graczy; dla wolnego miejsca planowana kwota inwestora. Remis zachowuje wcześniejsze miejsce.';
          const blockAmount=document.createElement('span');
          blockAmount.textContent=block.additional+' PR';
          blockAmount.style.cssText='flex:0 0 68px;width:68px;white-space:nowrap;font-variant-numeric:tabular-nums';
          const blockCopy=document.createElement('button');
          blockCopy.textContent='📋';blockCopy.title='Kopiuj dopłatę właściciela przed P'+row.rank;
          blockCopy.setAttribute('aria-label',blockCopy.title);
          blockCopy.style.cssText='padding:1px 3px;margin:0;min-width:0;font-size:10px;line-height:1.2';
          blockCopy.onclick=async()=>{
            try{await navigator.clipboard.writeText(String(block.additional));$('pearl-feedback').textContent='Skopiowano dopłatę przed P'+row.rank+': '+block.additional;}
            catch{$('pearl-feedback').textContent='Nie udało się skopiować.';}
          };
          const cumulative=document.createElement('span');cumulative.textContent='· łącznie '+block.cumulative+' PR';
          small.append(blockAmount,blockCopy);
          small.append(cumulative);
          label.append(small);
        }

        const amount = document.createElement('strong');
        amount.textContent = row.amount === null ? '—' : String(row.amount);
        const arc=FoePearls.arcProfit(row.base,row.amount,$('arc-bonus').value);
        amount.title=arc?`P${row.rank}: ${arc.profit>=0?'Zysk':'Strata'} ${Math.abs(arc.profit)} PR\nNagroda z Arką ×${arc.multiplier}: ${arc.reward} PR\nWpłata: ${row.amount} PR`:row.base===null?'Brak podstawowej nagrody PR.':'Ustaw poprawny bonus Arki (0–1000%).';
        amount.style.cursor='help';

        const copy = document.createElement('button');
        copy.textContent = '📋';
        copy.title = 'Kopiuj';
        copy.disabled = row.amount === null;
        copy.setAttribute('aria-label', 'Kopiuj kwotę P' + row.rank);
        copy.style.padding = '4px 8px';
        copy.onclick = async () => {
          try {
            await navigator.clipboard.writeText(String(row.amount));
            $('pearl-feedback').textContent = 'Skopiowano P' + row.rank + ': ' + row.amount;
          } catch {
            $('pearl-feedback').textContent = 'Nie udało się skopiować.';
          }
        };

        line.append(label, amount, copy);
        if(ownPlayerId&&construction.target?.playerId!==ownPlayerId){
          const paid=construction.rankings?.find(r=>r.player?.player_id===ownPlayerId)?.forge_points??0;
          const remaining=row.amount===null?null:Math.max(0,row.amount-paid);
        }
        $('pearl-rows').append(line);
      }

      // Wiersz wpłaty właściciela — tylko dla własnych perł
      const isOwnPearl =
        ownPlayerId &&
        construction.target?.playerId === ownPlayerId;

      const manualText=$('pearl-total').value.trim();
      if (isOwnPearl || manualText!=='') {
        const ownPearls = FoeModel.loadOwnPearls();
        const ownData = construction.cityentity_id
          ? ownPearls[construction.cityentity_id]
          : null;

        // Koszt poziomu: z ownPearls (bardziej aktualny) lub z construction
        const manualTotal=Number(manualText);
        const totalCost = manualText!=='' ? (Number.isSafeInteger(manualTotal)&&manualTotal>=0?manualTotal:null) : ownData?.forgePointsForLevelUp ?? result.totalCost;

        // Suma wpłat inwestorów = suma forge_points z rankings
        const investedSum = manualText!=='' ? result.rows.reduce((s,r)=>s+(r.amount??0),0) : construction.rankings
          ? construction.rankings.reduce((s, r) =>
              s + (Number.isSafeInteger(r.forge_points) ? r.forge_points : 0), 0)
          : 0;

        const ownerAmount = totalCost !== null
          ? Math.max(0, totalCost - investedSum)
          : null;

        const ownerLine = document.createElement('div');
        ownerLine.style.cssText =
          'display:flex;align-items:center;gap:10px;padding:10px 8px;background:#152d35;border-radius:6px;margin-top:8px';

        const ownerLabel = document.createElement('span');
        ownerLabel.style.flex = '1';
        ownerLabel.textContent = 'Wpłata właściciela';

        const ownerAmount_ = document.createElement('strong');
        ownerAmount_.textContent = ownerAmount !== null ? String(ownerAmount) : '—';

        const ownerCopy = document.createElement('button');
        ownerCopy.textContent = '📋';
        ownerCopy.title = 'Kopiuj';
        ownerCopy.disabled = ownerAmount === null;
        ownerCopy.setAttribute('aria-label', 'Kopiuj wpłatę właściciela');
        ownerCopy.style.padding = '4px 8px';
        ownerCopy.onclick = async () => {
          try {
            await navigator.clipboard.writeText(String(ownerAmount));
            $('pearl-feedback').textContent = 'Skopiowano wpłatę właściciela: ' + ownerAmount;
          } catch {
            $('pearl-feedback').textContent = 'Nie udało się skopiować.';
          }
        };

        ownerLine.append(ownerLabel, ownerAmount_, ownerCopy);
        $('pearl-rows').append(ownerLine);
      }
      $('pearl-refresh-note').hidden=!$('pearl-rows').querySelector('[data-pearl-contribution]:not(:disabled)');
    };

    let collectPending=null;const attemptedCollections=new Map();let collectFeedback='';
    const collectionBonusBar=document.createElement('div');collectionBonusBar.id='collection-bonuses';collectionBonusBar.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;font-size:11px;color:#f1d69a;margin:6px 0';
    $('city-list').before(collectionBonusBar);
    const favoritesKey=()=> 'foe-companion.favorites.'+(ownPlayerId??'unknown');
    function readFavorites(){try{const v=JSON.parse(localStorage.getItem(favoritesKey())||'[]');return new Set(Array.isArray(v)?v:[]);}catch{return new Set();}}
    const favoriteId=b=>b.id+':'+b.ceid;
    let cityCategory='favorites';
    const cityCategories=[['favorites','Ulubione','⭐'],['fp','+PR','🔬'],['pearls','Perły','🏛️'],['army','Wojsko','⚔️'],['other','Pozostałe','📦']];
    const inCityCategory=(b,key)=>key==='favorites'?readFavorites().has(favoriteId(b)):key==='pearls'?b.type==='greatbuilding':key==='army'?(b.producesUnits??b.productionUnits>0):key==='fp'?b.type!=='greatbuilding'&&(b.producesFP??b.productionFP>0):b.type!=='greatbuilding'&&!(b.producesFP??b.productionFP>0)&&!(b.producesUnits??b.productionUnits>0);
    const cityTabs=document.createElement('div');cityTabs.setAttribute('role','tablist');cityTabs.setAttribute('aria-label','Kategorie zbiorów');cityTabs.style.cssText='display:flex;gap:5px;margin:6px 0 10px';
    const cityTabButtons=new Map();
    for(const [key,label,emoji] of cityCategories){
      const button=document.createElement('button');button.type='button';button.textContent=emoji;button.dataset.tooltip=label;button.id='city-tab-'+key;button.setAttribute('role','tab');button.setAttribute('aria-controls','city-list');
      button.onclick=()=>{cityCategory=key;hideTip();paintCity();};cityTabButtons.set(key,button);cityTabs.append(button);
    }
    $('city-list').before(cityTabs);$('city-list').setAttribute('role','tabpanel');
    const collectAll=document.createElement('button');collectAll.textContent='🤲 Zbierz wszystkie';collectAll.style.cssText='display:block;font-size:11px;margin:0 0 6px auto';$('city-list').before(collectAll);
    const canCollect=b=>b.ready&&attemptedCollections.get(b.id)!==JSON.stringify(b.raw.state);
    function startCollection(buildings){
      if(!actionVisible('collection'))return;
      if(collectPending)return;
      const selected=buildings.filter(canCollect);if(!selected.length)return;
      const token=crypto.randomUUID();collectPending=token;
      for(const b of selected)attemptedCollections.set(b.id,JSON.stringify(b.raw.state));
      collectFeedback='Zbieranie: '+selected.length+'…';
      window.postMessage({channel:'foe-collect',token,entityIds:selected.map(b=>b.id)},location.origin);paintCity();
      setTimeout(()=>{if(collectPending!==token)return;collectPending=null;collectFeedback='Brak potwierdzenia zbiorów. Sprawdź stan w grze przed ponowieniem.';paintCity();},25000);
    }
    collectAll.onclick=()=>startCollection(FoeModel.cityRows().filter(b=>inCityCategory(b,cityCategory)));
    const cityNamesKey='foe-companion.customBuildingNames';
    const resetNames=document.createElement('button');resetNames.id='reset-building-names';resetNames.type='button';resetNames.textContent='Resetuj nazwy';resetNames.style.cssText='margin:10px 0 20px;font-size:11px;padding:3px 8px;cursor:pointer';
    $('city-list').after(resetNames);
    resetNames.onclick=()=>{
      hideTip();
      try{localStorage.removeItem(cityNamesKey);collectFeedback='Przywrócono nazwy automatyczne.';}catch{collectFeedback='Nie udało się zresetować nazw.';}
      paintCity();
    };
    function readCityNames(){try{const value=JSON.parse(localStorage.getItem(cityNamesKey)||'{}');return value&&typeof value==='object'&&!Array.isArray(value)?value:{};}catch{return {};}}
    window.addEventListener('message',event=>{if(event.source!==window||event.origin!==location.origin||event.data?.channel!=='foe-collect-result'||event.data.token!==collectPending)return;collectPending=null;for(const r of event.data.results||[])if(!r.ok&&r.retryable)attemptedCollections.delete(r.entityId);collectFeedback=event.data.message;paintCity();});
    setInterval(()=>paintCity(),1000);
    paintCity = () => {
      const bonuses=FoeModel.getCollectionBonuses();
      const bonusSnapshot=JSON.stringify(bonuses);
      if(collectionBonusBar.dataset.snapshot!==bonusSnapshot){
        collectionBonusBar.dataset.snapshot=bonusSnapshot;collectionBonusBar.replaceChildren();
        for(const bonus of bonuses||[]){
          const label=document.createElement('span');
          label.style.cssText='flex:0 0 calc((100% - 18px)/4);min-width:0;display:flex;align-items:center;justify-content:center;gap:5px;padding:4px 3px;background:#19352d;border:1px solid #365b48;white-space:nowrap';
          const uses=document.createElement('small');uses.textContent=bonus.amount+'x';uses.style.cssText='font-size:10px;color:#b7c8ce';
          const effect=document.createElement('strong');effect.textContent=bonus.type==='double_collection'?'x2':'🔨 '+bonus.value+'%';effect.style.cssText='font-size:11px;font-weight:700;color:#b5dbba';
          label.append(uses,effect);
          label.dataset.tooltip=bonus.type==='double_collection'?'Szansa podwojenia zbioru: '+bonus.value+'%.\nPozostało prób: '+bonus.amount+'. Wynik losowy.':'Premia do zbioru zaopatrzenia: +'+bonus.value+'%.\nPozostało użyć: '+bonus.amount+'.';
          collectionBonusBar.append(label);
        }
        collectionBonusBar.style.display=bonuses?.length?'flex':'none';
      }
      // Live timers and network updates must not replace an input being edited.
      if(root.activeElement?.matches('input[data-building-name]'))return;
      const customNames=readCityNames();
      const allRows = FoeModel.cityRows();
      for(const [key,label,emoji] of cityCategories){
        const button=cityTabButtons.get(key),selected=cityCategory===key;
        const ready=allRows.filter(b=>inCityCategory(b,key)&&b.ready&&attemptedCollections.get(b.id)!==JSON.stringify(b.raw.state)).length;
        const text=emoji+(ready?' ● '+ready:'');if(button.textContent!==text)button.textContent=text;
        button.dataset.tooltip=label+(ready?' — gotowe do zbioru: '+ready:'');
        button.setAttribute('aria-selected',String(selected));button.setAttribute('aria-label',label+(ready?': gotowe do zbioru '+ready:''));
        button.style.cssText='flex:1;padding:5px 4px;font-size:12px;border-bottom:2px solid '+(selected?'#f1d69a':'#2d454d')+';background:'+(selected?'#243d45':'transparent')+';color:'+(ready?'#ffd76a':'#dce8ec')+';font-weight:'+(ready?'bold':'normal');
      }
      const rows=allRows.filter(b=>inCityCategory(b,cityCategory));
      collectAll.style.display=actionVisible('collection')?'block':'none';
      collectAll.disabled=!!collectPending||!rows.some(canCollect);
      $('city-list').setAttribute('aria-labelledby','city-tab-'+cityCategory);
      const statusEl = $('city-status');
      const listEl = $('city-list');

      if (!rows.length) {
        statusEl.textContent = collectFeedback||(cityCategory==='favorites'?'Dodaj budynki przyciskiem 🤍 na pozostałych listach.':'Brak budynków z produkcją w tej kategorii.');
        listEl.replaceChildren();
        return;
      }

      statusEl.textContent = collectFeedback;
      listEl.replaceChildren();

      const fmt = ts => new Intl.DateTimeFormat('pl-PL', {
        timeZone: 'Europe/Warsaw',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      }).format(ts * 1000);

      for (const [index,b] of rows.entries()) {
        const row = document.createElement('div');
        row.style.cssText =
          'display:flex;align-items:baseline;gap:6px;padding:2px 0;border-bottom:1px solid #1a2d33';

        const time = document.createElement('span');
        time.style.cssText = 'font-size:10px;white-space:nowrap;color:#f1d69a;font-variant-numeric:tabular-nums';
        time.textContent = b.ready?'Gotowe':b.until?fmt(b.until):'—';
        const collectionTime=b.raw.state?.next_state_transition_at||b.until;
        const titleTime=collectionTime>0&&collectionTime!==2147483647?new Intl.DateTimeFormat('pl-PL',{timeZone:'Europe/Warsaw',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(collectionTime*1000):(b.ready?'Gotowe':'Brak godziny zbioru');
        row.title='⏰ '+titleTime+'\n'+b.tooltip;

        const name = document.createElement('span');
        name.style.cssText='flex:1;min-width:0;display:flex;align-items:baseline;gap:4px';
        const nameInput=document.createElement('input');
        nameInput.type='text';nameInput.dataset.buildingName=b.ceid;nameInput.maxLength=150;
        nameInput.value=typeof customNames[b.ceid]==='string'?customNames[b.ceid]:b.name;
        nameInput.placeholder=b.name;
        nameInput.setAttribute('aria-label','Własna nazwa budynku: '+b.name);
        nameInput.title=row.title;
        nameInput.style.cssText='background:transparent;border:1px solid transparent;outline:1px solid transparent;box-shadow:none;color:inherit;font:inherit;padding:0;min-width:0;width:100%;flex:1';
        nameInput.addEventListener('input',()=>{
          const names=readCityNames(),value=nameInput.value.trim();
          if(value)Object.defineProperty(names,b.ceid,{value,enumerable:true,configurable:true,writable:true});else delete names[b.ceid];
          try{
            localStorage.setItem(cityNamesKey,JSON.stringify(names));
            for(const other of $('city-list').querySelectorAll('input[data-building-name]'))if(other!==nameInput&&other.dataset.buildingName===b.ceid)other.value=value||other.placeholder;
          }catch{$('city-status').textContent='Nie udało się zapisać nazwy. Skopiuj ją przed zamknięciem.';}
        });
        nameInput.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Enter'){event.preventDefault();nameInput.blur();}});
        nameInput.addEventListener('blur',()=>setTimeout(paintCity,0));
        name.append(nameInput);

        if (b.level !== null) {
          const lvl = document.createElement('small');
          lvl.style.cssText = 'color:#90a5ad;font-size:11px;white-space:nowrap;flex-shrink:0';
          lvl.textContent = '';
          name.append(' ', lvl);
        }

        const controls=document.createElement('span');controls.style.cssText='margin-left:auto;display:flex;align-items:center;gap:8px;flex-shrink:0';
        const star=document.createElement('span');star.textContent='⭐';star.style.cssText=b.motivated?'':'filter:grayscale(1);opacity:.35';star.title=b.motivated?'Zmotywowany / odrestaurowany':'Niezmotywowany / nieodrestaurowany';
        const collect=document.createElement('button');collect.textContent='🤲';collect.title=b.ready?'Zbierz produkcję':'Produkcja jeszcze niegotowa';collect.setAttribute('aria-label','Zbierz: '+b.name);
        const stamp=JSON.stringify(b.raw.state);collect.disabled=!b.ready||!!collectPending||attemptedCollections.get(b.id)===stamp;
        collect.style.opacity=collect.disabled?'0.2':'1';
        collect.style.display=actionVisible('collection')?'':'none';
        collect.onclick=()=>startCollection([b]);
        const favorite=document.createElement('button'),isFavorite=readFavorites().has(favoriteId(b));favorite.textContent=isFavorite?'❤️':'🤍';favorite.dataset.tooltip=isFavorite?'Usuń z ulubionych':'Dodaj do ulubionych';favorite.setAttribute('aria-label',favorite.dataset.tooltip);favorite.style.cssText='border:0;background:transparent;padding:0;font-size:12px';
        favorite.onclick=()=>{const saved=readFavorites();if(saved.has(favoriteId(b)))saved.delete(favoriteId(b));else saved.add(favoriteId(b));try{localStorage.setItem(favoritesKey(),JSON.stringify([...saved]));}catch{collectFeedback='Nie udało się zapisać ulubionych.';}hideTip();paintCity();};
        if(cityCategory==='favorites'){const number=document.createElement('span');number.textContent=(index+1)+'.';number.style.cssText='flex:0 0 20px;font-size:9px;color:#71858b;text-align:right;font-variant-numeric:tabular-nums';row.append(number);}
        controls.append(time,star,favorite,collect);row.append(name,controls);
        listEl.append(row);
      }
    };

    $('multiplier').oninput = () => {
      localStorage.setItem(LS_MULTIPLIER, $('multiplier').value);
      paintPearl();
    };
    $('arc-bonus').oninput=()=>{
      const valid=FoePearls.arcProfit(100,0,$('arc-bonus').value)!==null;
      $('arc-bonus').setCustomValidity(valid?'':'Wpisz bonus od 0 do 1000%, do czterech miejsc po przecinku.');
      if(valid)localStorage.setItem(LS_ARC_BONUS,$('arc-bonus').value);
      paintPearl();
    };

    paintPearl();
    paintCity();

    $('frontier').onchange =
      paint;

    $('auto-open').onchange = () => {
      localStorage.setItem(LS_AUTO_OPEN, $('auto-open').checked ? '1' : '0');
    };

    $('auto-open-gbg').onchange = () => {
      localStorage.setItem(LS_AUTO_OPEN_GBG, $('auto-open-gbg').checked ? '1' : '0');
    };

    $('auto-copy').onchange = () => {
      localStorage.setItem(LS_AUTO_COPY, $('auto-copy').checked ? '1' : '0');
    };

    $('copy-open').onclick = async () => {
      paintOpenSectors();
      const text=$('open-sectors').copyText;
      if(!text){setBattleFeedback('Brak otwartych sektorów do skopiowania.');return;}
      try{
        await navigator.clipboard.writeText(text);
        setBattleFeedback('Skopiowano otwarte sektory.');
      }catch{
        setBattleFeedback('Nie udało się skopiować otwartych sektorów.');
      }
    };

    // --- Modal pilnowania sektorow ---
    function localIgnoreKey(){return 'foe-companion.localSectorIgnore.v1:'+location.host+':'+battle?.endsAt+':'+battle?.map?.id;}
    function localSectorIgnored(id){try{const ids=JSON.parse(localStorage.getItem(localIgnoreKey())||'[]');return !Array.isArray(ids)||ids.includes(id);}catch{return true;}}
    function setLocalSectorIgnored(id,ignored){
      try{const ids=JSON.parse(localStorage.getItem(localIgnoreKey())||'[]');if(!Array.isArray(ids))throw Error('invalid');const next=new Set(ids);if(ignored)next.add(id);else next.delete(id);localStorage.setItem(localIgnoreKey(),JSON.stringify([...next]));}
      catch{setBattleFeedback('Nie udało się zapisać lokalnego ignorowania.');}
      paintOpenSectors();
    }
    const bulkKey='foe-companion.openSectorSettings.v1';
    let bulkSettings=FoeSectorAutomation.settings();
    try{const savedBulk=JSON.parse(localStorage.getItem(bulkKey)||'{}');bulkSettings=FoeSectorAutomation.settings(savedBulk);}catch{}
    const automationInline=document.createElement('span');automationInline.id='automation-inline';automationInline.style.cssText='display:flex;gap:3px';$('open-sectors-heading').append(automationInline);
    const automationHandle=document.createElement('div');automationHandle.id='automation-handle';automationHandle.style.cssText='position:absolute;right:0;top:90%;transform:translateY(calc(-100% - 4px));display:flex;gap:3px;pointer-events:auto;z-index:3';root.append(automationHandle);
    for(const container of [automationInline,automationHandle])for(const [kind,emoji] of [['attack','⚔️'],['negotiation','🤝']]){
      const button=document.createElement('button');button.dataset.automationIndicator=kind;button.textContent=emoji;button.hidden=true;
      button.style.cssText='padding:3px 5px;margin:0;min-width:0;line-height:20px';
      button.onclick=()=>bulkAutomation.stop(kind);container.append(button);
    }
    bulkAutomation=FoeSectorAutomation.create({storage:localStorage,onChange:paintBulkControls});
    const bulkConfig=document.createElement('details');bulkConfig.id='settings-bulk-automation';
    const bulkSummary=document.createElement('summary');bulkSummary.textContent='Automatyzacja otwartych sektorów';bulkConfig.append(bulkSummary);
    for(const [key,label,max] of [['closeWithNegotiations','Zamykaj sektory negocjacjami'],['closeEnemyProgress','Autozamykanie ⚡: próg postępu wroga (%)',100],['attackProgress','Autoatak: limit progresu (%)',100],['attackChance','Autoatak: maks. szansa wzrostu oporu (%)',100],['negProgress','Negocjacje: limit progresu (%)',100],['negWins','Negocjacje: sukcesy na otwarcie',10000],['maxAttrition','Negocjacje: maksymalny opór',10000],['attack','Autoatak: 🟥 Atak'],['defense','Autoatak: 🟦 Obrona']]){
      const line=document.createElement('label'),input=document.createElement('input');line.textContent=label+' ';input.type=max?'number':'checkbox';
      line.dataset.automationSetting=['attackProgress','attackChance','attack','defense'].includes(key)?'attack':['negProgress','negWins','maxAttrition'].includes(key)?'negotiation':'shared';
      if(max){input.min=['maxAttrition','attackChance'].includes(key)?'0':'1';input.max=max;input.step='1';input.value=bulkSettings[key];}else input.checked=bulkSettings[key];
      input.onchange=()=>{const value=max?Number(input.value):input.checked;if(max&&(!Number.isInteger(value)||value<Number(input.min)||value>max)){input.value=bulkSettings[key];return;}
        bulkSettings={...bulkSettings,[key]:value};if(guardNegClosing)stopAutoNeg('Ustawienia zamykania zmienione.');bulkAutomation.stop(null,'Ustawienia zmienione — uruchom ponownie.');
        try{localStorage.setItem(bulkKey,JSON.stringify(bulkSettings));}catch{setBattleFeedback('Nie udało się zapisać ustawień.');}
      };line.append(input);bulkConfig.append(line);
    }
    const bulkHint=document.createElement('small');bulkHint.textContent='Negocjacje: szansa oporu 20%, bez limitu porażek. Autoatak: ustawiany limit szansy wzrostu oporu (domyślnie 20%), STOP po 3 porażkach z rzędu. Oba tryby respektują rezerwę walk i lokalne Ignoruj. Oba automaty domyślnie respektują łapkę gildii; opcja Ignoruj łapkę w oknie sektorów pozwala ją pominąć. Zamykanie z pilnowania jest wstrzymane; po STOP włącz ponownie jego checkbox, aby je wznowić.';bulkConfig.append(bulkHint);$('gbg-automation-settings').append(bulkConfig);
    // Keep controls for enabling actions reachable; hide only their dependent settings.
    $('auto-reserve').closest('label').before($('show-attack-buttons').closest('label'));
    $('nego-turn-min').closest('label').before($('show-negotiation-buttons').closest('label'));
    const attackGroup=document.createElement('details');attackGroup.id='settings-bulk-attack';attackGroup.innerHTML='<summary>Autoatak</summary>';
    const negGroup=document.createElement('details');negGroup.id='settings-bulk-negotiation';negGroup.innerHTML='<summary>Negocjacje</summary>';
    const sharedGroup=document.createElement('details');sharedGroup.id='settings-bulk-closing';sharedGroup.innerHTML='<summary>Zamykanie sektorów</summary>';
    for(const line of bulkConfig.querySelectorAll('[data-automation-setting]'))(line.dataset.automationSetting==='attack'?attackGroup:line.dataset.automationSetting==='negotiation'?negGroup:sharedGroup).append(line);
    const separator=document.createElement('hr');separator.dataset.automationSeparator='1';
    bulkConfig.append(attackGroup,separator,negGroup,sharedGroup,bulkHint);
    function refreshActionSettings(){
      const attack=actionVisible('attack'),negotiation=actionVisible('negotiation');
      attackGroup.hidden=!attack;negGroup.hidden=!negotiation;sharedGroup.hidden=!attack&&!negotiation;separator.hidden=!attack||!negotiation;
    }
    for(const section of [autoConfig,negTurnConfig,bulkConfig,$('settings-buildings')])section.hidden=!advancedSettings;
    refreshActionSettings();
    function paintAutomationIndicators(){
      if(!bulkAutomation)return;const state=bulkAutomation.state;
      for(const button of root.querySelectorAll('[data-automation-indicator]')){
        const kind=button.dataset.automationIndicator,enabled=state[kind],finishing=state.active?.kind===kind&&!enabled;
        const label=kind==='attack'?'Autoatak':'Autonegocjacje';
        button.hidden=!enabled&&!finishing;button.disabled=finishing;
        const tip=finishing?label+': dokańczanie rozpoczętej akcji — kolejka zatrzymana':label+(kind==='attack'?' włączony':' włączone')+' — kliknij, aby zatrzymać';
        button.setAttribute('data-tooltip',tip);button.setAttribute('aria-label',tip);button.setAttribute('aria-pressed',String(!!enabled));
      }
      for(const cell of root.querySelectorAll('[data-modal-counter]'))cell.textContent=[stats,negStats,attritionStats][Number(cell.dataset.modalCounter)].textContent;
    }
    function paintBulkControls(){
      if(!bulkAutomation)return;paintAutomationIndicators();const state=bulkAutomation.state;
      for(const [kind,label] of [['attack','⚔️ Autoatak otwartych sektorów'],['negotiation','🤝 Autonegocjacje otwartych sektorów']]){
        const button=root.querySelector('[data-bulk-mode="'+kind+'"]');if(!button)continue;
        button.textContent=(state[kind]?'⏹ ':'▶ ')+(kind==='attack'?'⚔️':'🤝');
        button.hidden=!state[kind]&&!(state.active?.kind===kind)&&(!actionVisible(kind)||(kind==='attack'&&!bulkSettings.attack&&!bulkSettings.defense));
        const negBlocked=kind==='negotiation'&&(!Number.isSafeInteger(playerAttrition)||playerAttrition>bulkSettings.maxAttrition);
        const reason=negBlocked?(Number.isSafeInteger(playerAttrition)?'Opór '+playerAttrition+' przekracza limit '+bulkSettings.maxAttrition+'. Zmień maksymalny opór w ustawieniach automatyzacji.':'Otwórz mapę Pól Chwały, aby odczytać aktualny opór.'):'';
        button.setAttribute('data-tooltip',label+(reason?' — '+reason:''));button.setAttribute('aria-label',label);
        const note=root.querySelector('[data-bulk-neg-reason]');if(kind==='negotiation'&&note){note.textContent=reason;note.hidden=!reason||!actionVisible(kind)||state.negotiation;}
        button.disabled=!state[kind]&&(negBlocked||!!state.active||!battleReady||kind==='attack'&&!bulkSettings.attack&&!bulkSettings.defense||autoSector!==null||autoNegSector!==null);
      }
      const showAttack=actionVisible('attack'),showNeg=actionVisible('negotiation');
      const ignore=root.querySelector('[data-ignore-guild]');if(ignore)ignore.hidden=!(showNeg||(showAttack&&(bulkSettings.attack||bulkSettings.defense)));
      stats.hidden=!showAttack;negStats.hidden=!showNeg;
      let firstCounter=true;
      for(const cell of root.querySelectorAll('[data-modal-counter]')){cell.hidden=cell.dataset.modalCounter==='0'?!showAttack:cell.dataset.modalCounter==='1'?!showNeg:false;cell.style.borderLeft=!cell.hidden&&!firstCounter?'1px solid #345058':'0';if(!cell.hidden)firstCounter=false;}
      const stop=root.querySelector('[data-bulk-stop]');if(stop)stop.hidden=!bulkAutomation.engaged&&autoSector===null&&autoNegSector===null;
      const status=root.querySelector('[data-bulk-status]');if(status){status.textContent=(battlePending||negPending)?modalActionStatus:(state.attack||state.negotiation)?state.status:modalActionStatus||state.status;status.hidden=(!showAttack&&!showNeg&&!battlePending&&!negPending)||/^Przyciski (negocjacji|ataku) wyłączone[.]$/.test(status.textContent);}
    }
    function tickBulk(){
      paintBulkControls();
      if(!battle||!ownPlayerId||!Number.isFinite(battle.endsAt))return;
      if(bulkAutomation.state.attack&&!actionVisible('attack'))bulkAutomation.stop('attack','Przyciski ataku wyłączone.');
      if(bulkAutomation.state.negotiation&&!actionVisible('negotiation'))bulkAutomation.stop('negotiation','Przyciski negocjacji wyłączone.');
      const enrich=r=>({...r,localIgnored:localSectorIgnored(r.id),ownerId:battle.map.provinces.find(p=>(p.id??0)===r.id)?.ownerId,mapId:battle.map.id,endsAt:battle.endsAt});
      bulkAutomation.tick({localIgnoreKey:localIgnoreKey(),scope:location.host+':'+ownPlayerId+':'+battle.endsAt+':'+battle.map.id,allRows:FoeModel.rows(battle,false).rows.map(enrich),rows:FoeModel.rows(battle,true).rows.map(enrich),config:bulkSettings,attrition:playerAttrition,ready:battleReady,busy:!!battlePending||!!negPending||autoSector!==null||autoNegSector!==null||battleWaveSector!==null,reserve:autoSettings.reserve,delay:(autoSettings.min+Math.random()*(autoSettings.max-autoSettings.min))*1000,send:(kind,id,policy)=>{
        if(kind==='attack')startFight(id,true,policy);else startNeg(id,policy);
        return kind==='attack'?!!battlePending:!!negPending;
      }});paintBulkControls();
    }
    setInterval(tickBulk,500);
    function mountSectorWindow(modal,box,header,closeButton){
      let drag=null;
      header.style.cursor='grab';header.style.touchAction='none';header.style.userSelect='none';
      function place(x,y){const rect=box.getBoundingClientRect();box.style.transform='none';box.style.left=Math.max(0,Math.min(x,window.innerWidth-rect.width*.2))+'px';box.style.top=Math.max(0,Math.min(y,window.innerHeight-48))+'px';}
      header.addEventListener('pointerdown',event=>{
        if(event.button!==0||event.target.closest('button,input'))return;
        const rect=box.getBoundingClientRect();drag={id:event.pointerId,x:event.clientX,y:event.clientY,left:rect.left,top:rect.top};
        header.setPointerCapture(event.pointerId);event.preventDefault();
      });
      header.addEventListener('pointermove',event=>{if(drag&&event.pointerId===drag.id)place(drag.left+event.clientX-drag.x,drag.top+event.clientY-drag.y);});
      const end=event=>{if(!drag||event.pointerId!==drag.id)return;if(header.hasPointerCapture(event.pointerId))header.releasePointerCapture(event.pointerId);drag=null;};
      header.addEventListener('pointerup',end);header.addEventListener('pointercancel',end);
      const resize=()=>{const rect=box.getBoundingClientRect();place(rect.left,rect.top);};
      const close=()=>{modal.remove();document.removeEventListener('keydown',onKey,true);window.removeEventListener('resize',resize);};
      const onKey=event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}};
      modal.close=close;closeButton.onclick=close;document.addEventListener('keydown',onKey,true);window.addEventListener('resize',resize);
    }
    function openSectorGuardModal(){
      if(!battle){setBattleFeedback('Brak danych mapy — otwórz Pola Chwały w grze.');return;}
      const existing=root.querySelector('#sector-guard-modal');if(existing){existing.querySelector('[aria-label="Zamknij"]')?.focus();return;}
      const modalMapId=battle.map.id;
      const modal=document.createElement('div');modal.id='sector-guard-modal';
      modal.style.cssText='position:fixed;inset:0;z-index:2147483646;pointer-events:none';
      const box=document.createElement('div');box.style.cssText='position:absolute;left:50%;top:8vh;transform:translateX(-50%);box-sizing:border-box;width:min(820px,96vw);min-width:min(380px,96vw);max-width:96vw;resize:horizontal;background:#102126;border:1px solid #345058;border-radius:6px;padding:14px 16px;max-height:85vh;overflow:auto;color:#e7eeee;font:12px/1.5 system-ui;box-shadow:0 8px 30px #000c;pointer-events:auto';
      modal.append(box);
      // Naglowek
      const hdr=document.createElement('div');hdr.style.cssText='display:flex;align-items:center;justify-content:space-between;margin-bottom:10px';
      const titleEl=document.createElement('strong');titleEl.textContent='Otwarte sektory';titleEl.style.cssText='font-size:13px;color:#f1d69a';
      const copyAll=document.createElement('button');copyAll.textContent='📋 Kopiuj wszystkie';copyAll.setAttribute('data-tooltip','Kopiuj otwarte i nadchodzące sektory z tabeli');copyAll.style.cssText='margin-left:auto;padding:3px 7px;font-size:11px;white-space:nowrap';
      let displayedRows=[];
      const openingTime=until=>new Intl.DateTimeFormat('pl-PL',{hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(until*1000));
      const closedSectorCopyText=(row,now)=>row.until>now?FoeModel.closedSectorText(row):null;
      copyAll.onclick=async()=>{const now=Date.now()/1000;try{await navigator.clipboard.writeText(displayedRows.map(row=>closedSectorCopyText(row,now)||FoeModel.openSectorText(row)).join('\n'));}catch{setBattleFeedback('Nie udało się skopiować sektorów.');}};
      const closeBtn=document.createElement('button');closeBtn.textContent='×';closeBtn.setAttribute('aria-label','Zamknij');
      closeBtn.style.cssText='background:transparent;border:0;color:#e7eeee;font-size:20px;line-height:1;cursor:pointer;padding:0 4px';
      closeBtn.onclick=()=>modal.remove();
      hdr.append(titleEl,copyAll,closeBtn);box.append(hdr);
      const bulkBar=document.createElement('div');bulkBar.style.cssText='display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px';
      for(const kind of ['negotiation','attack']){const button=document.createElement('button');button.dataset.bulkMode=kind;
        button.onclick=()=>{const enabled=bulkAutomation.state[kind];if(enabled)bulkAutomation.stop(kind);else if(actionVisible(kind)&&battleReady)bulkAutomation.enable(kind,true);paintBulkControls();};bulkBar.append(button);}
      const stopAll=document.createElement('button');stopAll.textContent='⏹ STOP';stopAll.dataset.bulkStop='1';stopAll.onclick=()=>{bulkAutomation.stop();if(autoSector!==null)requestStopAuto();if(autoNegSector!==null)stopAutoNeg('Auto-negocjacje zatrzymane.');paintBulkControls();};bulkBar.append(stopAll);
      const ignoreGuildLabel=document.createElement('label');ignoreGuildLabel.dataset.ignoreGuild='1';ignoreGuildLabel.style.cssText='display:flex;align-items:center;gap:4px;margin:0 0 0 4px;white-space:nowrap;color:#dce8ec';
      const ignoreGuildToggle=document.createElement('input');ignoreGuildToggle.type='checkbox';ignoreGuildToggle.checked=bulkSettings.attackIgnoreGuildSignal===true;ignoreGuildToggle.setAttribute('aria-label','Automaty ignorują łapkę gildii');
      const ignoreGuildText=document.createElement('span');ignoreGuildText.textContent='Ignoruj łapkę';ignoreGuildText.title='Pozwala globalnemu autoatakowi i autonegocjacjom działać na sektorach ignorowanych przez gildię. Lokalne Ignoruj nadal blokuje sektor.';
      ignoreGuildToggle.onchange=()=>{const previous=bulkSettings,next={...bulkSettings,attackIgnoreGuildSignal:ignoreGuildToggle.checked};try{localStorage.setItem(bulkKey,JSON.stringify(next));bulkSettings=next;bulkAutomation.stop(null,'Ustawienia zmienione — uruchom ponownie.');}catch{bulkSettings=previous;ignoreGuildToggle.checked=previous.attackIgnoreGuildSignal===true;setBattleFeedback('Nie udało się zapisać ustawień.');}paintBulkControls();};
      ignoreGuildLabel.append(ignoreGuildToggle,ignoreGuildText);bulkBar.append(ignoreGuildLabel);
      const bulkStatus=document.createElement('div');bulkStatus.dataset.bulkStatus='1';bulkStatus.style.cssText='font-size:11px;margin-top:8px;min-width:0;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';const negReason=document.createElement('div');negReason.dataset.bulkNegReason='1';negReason.style.cssText='font-size:11px;margin-bottom:8px';box.append(bulkBar,negReason);
      // Tabelka
      const table=document.createElement('table');table.style.cssText='width:100%;border-collapse:collapse;font-size:11px';
      const thead=document.createElement('thead');
      const hrow=document.createElement('tr');
      const thStyle='padding:3px 6px;border-bottom:1px solid #345058;color:#8fcfcf;font-weight:normal;white-space:nowrap';
      const cols=[
        ['Otwarcie','Czas do otwarcia sektora','center'],
        ['Sektor','','left'],
        ['Postęp','Postęp przejęcia naszej gildii','center'],
        ['%','Szansa na wzrost oporu','center'],
        ['⚔️','Jednorazowa walka','center'],
        ['','Autoatak','center'],
        ['🤝','Jednorazowa negocjacja','center'],
        ['','Auto-negocjacja','center'],
        ['🔔','Pilnuj — powiadomienie gdy wróg atakuje','center'],
        ['🕐','Zamknij o pełnej godzinie (30s przed)','center'],
        ['⚡','Zamknij po przekroczeniu ustawionego progu wroga','center'],
        ['Ignoruj','Lokalnie pomijaj sektor w autoataku i autonegocjacjach otwartych sektorów','center'],
      ];
      const guardColumns=new Map();
      for(const [txt,tip,align] of cols){
        const th=document.createElement('th');th.textContent=txt;
        const key={'🔔':'guard','🕐':'closeAtHour','⚡':'closeWhenThreatened'}[txt];
        if(key){const toggle=document.createElement('button');toggle.textContent=txt;toggle.style.cssText='padding:0 3px;border:0;background:transparent';guardColumns.set(key,{toggle,items:[]});toggle.onclick=()=>toggleGuardColumn(key);th.textContent='';th.append(toggle);}
        if(tip)th.setAttribute('data-tooltip',tip);
        th.style.cssText=thStyle+';text-align:'+align;
        hrow.append(th);
      }
      thead.append(hrow);table.append(thead);
      const tbody=document.createElement('tbody');
      const tdBase='padding:3px 6px;border-bottom:1px solid #1e3540';
      const btnStyle='padding:3px 5px;background:transparent;border-color:transparent;outline:none;font-size:13px;line-height:1;cursor:pointer';
      const empty=document.createElement('p');empty.textContent='Brak otwartych sektorów.';empty.style.color='#8a9fa5';
      let tableSnapshot='';const timeCells=[];
      const paintRow=tr=>{const id=Number(tr.dataset.sid),g=getGuard(battle.map.id,id);
        const activeBattle=autoSector===id||battlePendingSector===id||battleWaveSector===id,activeNegotiation=autoNegSector===id||negPendingSector===id;
        tr.style.background=activeBattle||activeNegotiation||selectedSector===id?'rgba(45,180,170,0.22)':tr.dataset.ignored==='1'?'rgba(190,45,45,0.16)':(g.guard||g.closeAtHour||g.closeWhenThreatened)?'rgba(30,100,200,0.18)':'';
        tr.title=activeNegotiation?'Negocjacja w toku':activeBattle?'Walka w toku':selectedSector===id?'Zaznaczony sektor':'';
      };
      function paintGuardColumns(){
        for(const [key,{toggle,items}] of guardColumns){
          const visible=items.filter(i=>!i.tr.hidden&&!i.cb.disabled),checked=visible.filter(i=>i.cb.checked).length,all=visible.length>0&&checked===visible.length;
          toggle.disabled=!visible.length;toggle.setAttribute('role','checkbox');toggle.setAttribute('aria-checked',all?'true':checked?'mixed':'false');
          toggle.style.opacity=checked?'1':'.55';toggle.style.boxShadow=checked?'inset 0 -2px '+(all?'#8fcfcf':'#e1be77'):'none';
          toggle.setAttribute('data-tooltip',{'guard':'Powiadom, gdy wróg atakuje sektor','closeAtHour':'Rozpocznij zamykanie 30 sekund przed pełną godziną','closeWhenThreatened':'Rozpocznij zamykanie, gdy postęp wroga przekroczy '+bulkSettings.closeEnemyProgress+'%'}[key]);
        }
      }
      function applyGuard(item,key,checked){
        if(battle?.map?.id!==modalMapId||item.cb.disabled)return;
        item.cb.checked=checked;setGuard(modalMapId,item.id,{[key]:checked});
        if(key==='closeAtHour'){if(checked&&item.tr.dataset?.locked!=='true')scheduleCloseAtHour(item.id);else cancelCloseAtHour(item.id);}
        if(checked&&key!=='guard')bulkAutomation.resumeGuards();paintRow(item.tr);
      }
      function toggleGuardColumn(key){
        const items=guardColumns.get(key).items.filter(i=>!i.tr.hidden&&!i.cb.disabled),checked=items.some(i=>!i.cb.checked);
        for(const item of items)applyGuard(item,key,checked);
        paintGuardColumns();paintOpenSectors();checkSectorAlerts();
      }
      modal.refresh=()=>{
        if(battle?.map?.id!==modalMapId){modal.close?.();return;}
        const now=Date.now()/1000;
        const showAttack=actionVisible('attack'),showNeg=actionVisible('negotiation');
        const hideColumn=i=>i===2?!FoeModel.displaySettings.ownProgress:i===4||i===5?!showAttack:i===6||i===7?!showNeg:i>=8?!showAttack&&!showNeg:false;
        Array.from(hrow.children).forEach((cell,i)=>{cell.hidden=hideColumn(i);});
        const canClose=bulkSettings.closeWithNegotiations?showNeg:showAttack;
        legend.hidden=!showAttack&&!showNeg;
        legend.textContent='🔔 Powiadomienie gdy wróg atakuje'+(canClose?' · 🕐 Zamykanie 30s przed pełną godziną · ⚡ Zamykanie gdy wróg >'+bulkSettings.closeEnemyProgress+'% · '+(bulkSettings.closeWithNegotiations?'🤝 negocjacjami':'⚔️ walkami'):'');
        const candidates=FoeModel.rows(battle,true).rows.filter(r=>r.color!=='⚪');
        const open=candidates.filter(r=>r.until<=now).sort((a,b)=>Number(a.ignored)-Number(b.ignored)||(a.progress??0)-(b.progress??0)||a.id-b.id);
        const upcoming=candidates.filter(r=>r.until>now).sort((a,b)=>a.until-b.until||a.id-b.id).slice(0,FoeModel.displaySettings.closedCount);
        const displayed=[...open,...upcoming];
        displayedRows=displayed;copyAll.disabled=!displayed.length;
        const clock=until=>{const seconds=Math.max(0,Math.ceil(until-now));return seconds?String(Math.floor(seconds/3600)).padStart(2,'0')+':'+String(Math.floor(seconds/60)%60).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0'):'Otwarte';};
        for(const cell of timeCells){const text=clock(cell.until);if(cell.node.textContent!==text)cell.node.textContent=text;}
        const snapshot=JSON.stringify([selectedSector,FoeModel.displaySettings,displayed,open.length,bulkSettings.closeEnemyProgress,displayed.map(r=>[getGuard(modalMapId,r.id),localSectorIgnored(r.id)]),battleReady,battlePending,battlePendingSector,battleWaveSector,autoSector,autoNegSector,negPending,negPendingSector,battleLastSector,Date.now()<battleLastUntil,battleLastOK,negLastSector,Date.now()<negLastUntil,negLastOK,actionVisible('attack'),actionVisible('negotiation')]);
        if(snapshot===tableSnapshot)return;tableSnapshot=snapshot;
        tbody.replaceChildren();timeCells.length=0;for(const column of guardColumns.values())column.items=[];empty.hidden=!!displayed.length;
      for(const row of displayed){
        const locked=row.until>now;
        const tr=document.createElement('tr');tr.dataset.sid=row.id;tr.dataset.ignored=row.ignored?'1':'0';tr.dataset.locked=String(locked);if(locked)tr.style.opacity='.55';paintRow(tr);
        const td=(content,extra='')=>{const t=document.createElement('td');t.style.cssText=tdBase+';text-align:center'+extra;t.append(content);tr.append(t);return t;};
        const time=document.createElement('td');time.style.cssText=tdBase+';text-align:center;white-space:nowrap;font-variant-numeric:tabular-nums';time.textContent=clock(row.until);tr.append(time);timeCells.push({node:time,until:row.until});
        // Sektor
        const nameSpan=document.createElement('span');
        nameSpan.textContent=(row.isAttackBattleType===true?'🟥 ':row.isAttackBattleType===false?'🟦 ':'')+FoeModel.guildColor(row)+row.sector+FoeModel.sectorMarker(row);
        const activeBattle=autoSector===row.id||battlePendingSector===row.id||battleWaveSector===row.id,activeNegotiation=autoNegSector===row.id||negPendingSector===row.id;
        nameSpan.style.cursor=activeBattle||activeNegotiation?'default':'pointer';nameSpan.setAttribute('role','button');nameSpan.setAttribute('tabindex','0');
        nameSpan.setAttribute('aria-pressed',String(selectedSector===row.id));nameSpan.setAttribute('aria-disabled',String(activeBattle||activeNegotiation));
        nameSpan.onclick=()=>{if(activeBattle||activeNegotiation)return;selectedSector=selectedSector===row.id?null:row.id;paintOpenSectors();};
        nameSpan.onkeydown=event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();nameSpan.onclick();}};
        const copy=document.createElement('button');copy.textContent='📋';copy.setAttribute('data-tooltip','Kopiuj sektor '+row.sector);copy.style.cssText=btnStyle;copy.onclick=async()=>{try{const closedText=closedSectorCopyText(row,Date.now()/1000);await navigator.clipboard.writeText(closedText||FoeModel.openSectorText(row));}catch{setBattleFeedback('Nie udało się skopiować sektora.');}};
        const tdN=document.createElement('td');tdN.style.cssText=tdBase+';text-align:left;white-space:nowrap';tdN.append(nameSpan,copy);tr.append(tdN);
        // Postep
        const tdP=document.createElement('td');tdP.textContent=FoeModel.progressText(row);tdP.style.cssText=tdBase+';text-align:center;color:#a5b8bc';tr.append(tdP);
        // Szansa oporu
        const tdC=document.createElement('td');tdC.textContent=locked&&!FoeModel.displaySettings.closedAttrition?'':(row.gainAttritionChance===null?'—':row.gainAttritionChance+'%');tdC.style.cssText=tdBase+';text-align:center;color:#a5b8bc';tr.append(tdC);
        // ⚔️ jednorazowa walka
        const actBtn=document.createElement('button');actBtn.style.cssText=btnStyle;
        actBtn.textContent=battlePendingSector===row.id?'⏳':battleLastSector===row.id&&Date.now()<battleLastUntil?(battleLastOK?'✅':'⚠️'):'⚔️';
        actBtn.disabled=!battleReady||!!battlePending||(battleWaveSector!==null&&battleWaveSector!==row.id)||autoSector!==null||autoNegSector!==null||negPending!==null;
        actBtn.setAttribute('data-tooltip',battleWaveSector===row.id?'Kolejna fala':'Walka jednorazowa');
        actBtn.onclick=()=>{startFight(row.id);};
        if(!actionVisible('attack'))actBtn.style.display='none';
        td(actBtn);
        // ▶ autoatak
        const autoBtn=document.createElement('button');autoBtn.style.cssText=btnStyle;
        autoBtn.textContent=autoSector===row.id?'⏹':'▶';
        autoBtn.disabled=autoSector!==row.id&&(!battleReady||!!battlePending||autoSector!==null||autoNegSector!==null||negPending!==null);
        autoBtn.setAttribute('data-tooltip',autoSector===row.id?'Zatrzymaj autoatak':'Autoatak');
        autoBtn.onclick=()=>{if(autoSector===row.id){requestStopAuto();return;}autoSector=row.id;lossStreak=0;stopButton.hidden=false;startFight(row.id,true);};
        if(!actionVisible('attack'))autoBtn.style.display='none';
        td(autoBtn);
        // 🤝 jednorazowa nego
        const negBtnM=document.createElement('button');negBtnM.style.cssText=btnStyle;
        negBtnM.textContent=negPendingSector===row.id?'⏳':negLastSector===row.id&&Date.now()<negLastUntil?(negLastOK?'✅':'⚠️'):'🤝';
        negBtnM.disabled=!battleReady||negPending!==null||battlePending!==null||autoSector!==null||autoNegSector!==null;
        negBtnM.setAttribute('data-tooltip','Negocjacja jednorazowa');
        negBtnM.onclick=()=>{startNeg(row.id);};
        if(!actionVisible('negotiation'))negBtnM.style.display='none';
        td(negBtnM);
        // ▶▶ autoneg
        const autoNegBtnM=document.createElement('button');autoNegBtnM.style.cssText=btnStyle;
        autoNegBtnM.textContent=autoNegSector===row.id?'⏹':'▶';
        autoNegBtnM.disabled=autoNegSector!==row.id&&(!battleReady||negPending!==null||battlePending!==null||autoSector!==null||autoNegSector!==null);
        autoNegBtnM.setAttribute('data-tooltip',autoNegSector===row.id?'Zatrzymaj auto-negocjację':'Auto-negocjacja');
        autoNegBtnM.onclick=()=>{if(autoNegSector===row.id){stopAutoNeg('Auto-negocjacja zatrzymana.');return;}autoNegSector=row.id;stopNegButton.hidden=false;startNeg(row.id);};
        if(!actionVisible('negotiation'))autoNegBtnM.style.display='none';
        td(autoNegBtnM);
        // 3 checkboxy pilnowania
        const g=getGuard(battle.map.id,row.id);
        for(const key of ['guard','closeAtHour','closeWhenThreatened']){
          const cb=document.createElement('input');cb.type='checkbox';cb.checked=g[key];cb.disabled=false;cb.style.cursor='pointer';
          const item={cb,id:row.id,tr};guardColumns.get(key).items.push(item);
          cb.onchange=()=>{applyGuard(item,key,cb.checked);paintGuardColumns();paintOpenSectors();checkSectorAlerts();};
          td(cb);
        }
        const ignore=document.createElement('input');ignore.type='checkbox';ignore.checked=localSectorIgnored(row.id);ignore.disabled=false;ignore.setAttribute('aria-label','Ignoruj lokalnie sektor '+row.sector);ignore.onchange=()=>setLocalSectorIgnored(row.id,ignore.checked);td(ignore);
        if(locked)for(const button of [actBtn,autoBtn,negBtnM,autoNegBtnM]){button.disabled=true;button.style.cursor='default';}
        Array.from(tr.children).forEach((cell,i)=>{cell.hidden=hideColumn(i);});
        tbody.append(tr);
      }
        paintGuardColumns();convertTitles(tbody);
      };
      table.append(tbody);box.append(empty,table);
      const legend=document.createElement('p');legend.style.cssText='margin:8px 0 0;font-size:10px;color:#56727b';
      legend.textContent='';
      box.append(legend);modal.refresh();
      const modalCounters=document.createElement('table');modalCounters.style.cssText='width:auto;margin:10px auto 0;border-collapse:collapse;font-variant-numeric:tabular-nums';
      const countRow=document.createElement('tr');
      for(const [index,source] of [stats,negStats,attritionStats].entries()){const cell=document.createElement('td');cell.dataset.modalCounter=String(index);cell.textContent=source.textContent;cell.style.cssText='padding:0 8px'+(index?';border-left:1px solid #345058':'');cell.setAttribute('data-tooltip',source.title||source.getAttribute('data-tooltip')||'');countRow.append(cell);}
      modalCounters.append(countRow);box.append(bulkStatus,modalCounters);
      convertTitles(modal);
      root.append(modal);mountSectorWindow(modal,box,hdr,closeBtn);paintBulkControls();
    }
    $('sector-guard-open').onclick=()=>openSectorGuardModal();

    function openOwnSectorsModal(){
      if(!battle){setBattleFeedback('Brak danych mapy — otwórz Pola Chwały w grze.');return;}
      const existing=root.querySelector('#own-sectors-modal');if(existing){existing.querySelector('[aria-label="Zamknij"]')?.focus();return;}
      const modalMapId=battle.map.id;
      const modal=document.createElement('div');modal.id='own-sectors-modal';modal.style.cssText='position:fixed;inset:0;z-index:2147483646;pointer-events:none';
      const box=document.createElement('div');box.style.cssText='position:absolute;left:50%;top:8vh;transform:translateX(-50%);box-sizing:border-box;width:min(900px,96vw);min-width:0;background:#102126;border:1px solid #345058;border-radius:6px;padding:14px 16px;max-height:85vh;overflow:auto;color:#e7eeee;font:12px/1.5 system-ui;box-shadow:0 8px 30px #000c;pointer-events:auto';
      const hdr=document.createElement('div');hdr.style.cssText='display:flex;align-items:center;justify-content:space-between;margin-bottom:10px';
      const title=document.createElement('strong');title.textContent='Nasze sektory';title.style.cssText='font-size:13px;color:#f1d69a';
      const close=document.createElement('button');close.textContent='×';close.setAttribute('aria-label','Zamknij');close.style.cssText='background:transparent;border:0;color:#e7eeee;font-size:20px;line-height:1;cursor:pointer;padding:0 4px';hdr.append(title,close);box.append(hdr);
      const empty=document.createElement('p');empty.style.cssText='margin:8px 0;color:#8a9fa5';
      const table=document.createElement('table');table.style.cssText='width:100%;border-collapse:collapse;font-size:11px';
      const thead=document.createElement('thead'),hrow=document.createElement('tr');
      const headers=[['🏰','Sektor należący do naszej gildii'],['👾','Atak przeciwnika i jego postęp'],['🏗️','Zajęte i wolne sloty budynków'],['🛡️','Sąsiednie sektory oraz ich szansa na wzrost oporu'],['','Gildyjne oznaczenia: ✋ ignorowana, 🎯 wskazana do ataku']];
      for(const [label,tip] of headers){const th=document.createElement('th');th.textContent=label;th.style.cssText='padding:4px 6px;border-bottom:1px solid #345058;color:#8fcfcf;font-weight:normal;text-align:center;white-space:nowrap';if(tip)th.setAttribute('data-tooltip',tip);hrow.append(th);}thead.append(hrow);table.append(thead);
      const tbody=document.createElement('tbody');table.append(tbody);box.append(empty,table);
      const legend=document.createElement('p');legend.style.cssText='margin:8px 0 0;font-size:10px;color:#8a9fa5';legend.textContent='✋ Ignorowana przez gildię · 🎯 Oznaczona przez gildię do ataku';box.append(legend);modal.append(box);
      let tableSnapshot='';
      modal.refresh=()=>{
        if(battle?.map?.id!==modalMapId){modal.close?.();return;}
        const rows=FoeModel.rows(battle,false).rows,byId=new Map(rows.map(row=>[row.id,row]));
        const owned=rows.filter(row=>row.ownerId===battle.currentParticipantId).sort((a,b)=>a.sector.localeCompare(b.sector));
        const data=owned.map(row=>({row,neighbors:FoeModel.neighbors(battle,row.id).map(n=>byId.get(n.id)).filter(n=>n&&n.ownerId!==battle.currentParticipantId).map(n=>({sector:n.sector,chance:n.gainAttritionChance})).sort((a,b)=>a.sector.localeCompare(b.sector))}));
        const snapshot=JSON.stringify([FoeModel.displaySettings,data]);if(snapshot===tableSnapshot)return;tableSnapshot=snapshot;tbody.replaceChildren();empty.hidden=!!data.length;empty.textContent='Brak sektorów należących do naszej gildii.';
        for(const {row,neighbors} of data){const tr=document.createElement('tr');
          const td=(text,align='center')=>{const cell=document.createElement('td');cell.textContent=text;cell.style.cssText='padding:5px 6px;border-bottom:1px solid #1e3540;text-align:'+align+';color:#c6d4d6;vertical-align:top';tr.append(cell);return cell;};
          td((row.isAttackBattleType===true?'🟥 ':row.isAttackBattleType===false?'🟦 ':'')+FoeModel.guildColor(row)+row.sector,'left');
          td(row.enemyProgress>0?'👾 '+row.enemyProgress+'/'+row.enemyMaxProgress:'—');
          const slots=td('');
          const validSlots=Number.isSafeInteger(row.usedBuildingSlots)&&Number.isSafeInteger(row.totalBuildingSlots)&&row.totalBuildingSlots>0;
          const total=validSlots?Math.min(3,row.totalBuildingSlots):0,used=validSlots?Math.max(0,Math.min(row.usedBuildingSlots,total)):0;
          slots.setAttribute('aria-label',validSlots?'Zajęte sloty budynków: '+used+' z '+total:'Brak danych o slotach budynków');
          slots.setAttribute('data-tooltip',validSlots?used+' z '+total+' zajętych slotów budynków':'Brak danych o slotach budynków');
          const slotSquares=document.createElement('span');slotSquares.style.cssText='display:inline-flex;align-items:center;justify-content:center;gap:2px;width:28px;height:10px;vertical-align:middle';
          for(let i=0;i<3;i++){const exists=i<total,occupied=exists&&i<used,square=document.createElement('span');square.style.cssText='box-sizing:border-box;display:block;flex:0 0 8px;width:8px;height:8px;border:1px solid #f1d69a;background:'+(occupied?'#f1d69a':'transparent')+';opacity:'+(exists?(occupied?'1':'.5'):'0');slotSquares.append(square);}
          slots.append(slotSquares);
          td(neighbors.length?neighbors.map(n=>n.sector+' '+(n.chance===null?'—':n.chance+'%')).join(' · '):'—','left');
          const marks=[...(row.ignored?['✋']:[]),...(row.focused?['🎯']:[])];const marker=td(marks.join(' ')||'');if(row.ignored)marker.title='Prowincja ignorowana przez gildię';if(row.focused)marker.title+=(marker.title?' · ':'')+'Prowincja oznaczona przez gildię do ataku';if(marks.length)marker.setAttribute('data-tooltip',marker.title);
          tbody.append(tr);
        }
        convertTitles(modal);
      };
      modal.refresh();root.append(modal);mountSectorWindow(modal,box,hdr,close);
    }
    $('own-sectors-open').onclick=()=>openOwnSectorsModal();


    $('copy').onclick = async () => {
      paint();
      try {
        if (!output) return;

        await navigator.clipboard.writeText(
          output
        );

        $('feedback').textContent =
          'Skopiowano.';
      } catch {
        $('feedback').textContent =
          'Zaznacz i skopiuj listę ręcznie.';
      }
    };

    $('export-battle').onclick = () => {
      if(!battle)return;
      const blob=new Blob([JSON.stringify({requestClass:'GuildBattlegroundStateService',requestMethod:'getState',responseData:battle},null,2)],{type:'application/json'});
      const url=URL.createObjectURL(blob),link=document.createElement('a');
      link.href=url;link.download='foe-pola-'+String(battle.map?.id||'mapa').replace(/[^a-z0-9_-]/gi,'_')+'.json';
      root.append(link);link.click();link.remove();
      setTimeout(()=>URL.revokeObjectURL(url),10000);
      $('feedback').textContent='Wyeksportowano ostatnio odebrany stan mapy.';
    };

    globalThis.FoeDiscord?.mount({root,getRows:()=>{if(!battle)return null;const all=FoeModel.rows(battle,false).rows;const frontier=new Set(FoeModel.rows(battle,true).rows.map(row=>row.id));return all.map(row=>({...row,frontier:frontier.has(row.id)}));},formatOpen:FoeModel.openSectorText,isFrontierOnly:()=>$('frontier').checked});
    registerSettingsFolds();
    paint();
  }

  const startPanel=()=>Promise.resolve(globalThis.FoeMode?.ready).then(mount);
  if (
    document.readyState === 'loading'
  ) {
    document.addEventListener(
      'DOMContentLoaded',
      startPanel,
      { once: true }
    );
  } else {
    startPanel();
  }
})();
// sshdsd

//oks
